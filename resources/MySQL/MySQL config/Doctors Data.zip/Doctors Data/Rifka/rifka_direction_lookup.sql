CREATE DATABASE  IF NOT EXISTS `rifka` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `rifka`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: rifka
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `direction_lookup`
--

DROP TABLE IF EXISTS `direction_lookup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `direction_lookup` (
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `direction_lookup`
--

LOCK TABLES `direction_lookup` WRITE;
/*!40000 ALTER TABLE `direction_lookup` DISABLE KEYS */;
INSERT INTO `direction_lookup` VALUES ('02 càs le soir'),('05ml 2 fois / jour'),('06/10/08'),('1 ampoule/21jours'),('1 app/j'),('1 application/2j'),('1 chaque 2/j'),('1 cp 2/j'),('1 cp j5_j25'),('1 fois'),('1 inj'),('1 inj/10j'),('1 ovu/j'),('1 patch/2j'),('1 sachet/j'),('1+1/2'),('1.8'),('1/ semaine'),('1/15j'),('1/2 cp 2/j'),('1/2 par semaine'),('1/21 jours'),('1/2sem'),('1/5'),('1/cp 2/j'),('1/j 1/2'),('1/J 1/2cp'),('1/j après repas'),('1/J et 1/2 le soir'),('1/J le matin'),('1/j sur deux'),('1/J+1/4'),('1/MOIS'),('10 unités'),('10/12/12'),('10ml/j'),('14/j'),('15/30/30'),('15/j'),('16/16/12 UI'),('16/16/14'),('1càs 2/j'),('1càs le soir'),('1cp 3/j'),('1cp après repas'),('1cp x2j'),('1cp x2j 1/2h avant repas'),('1cp. 2/j'),('1cp/j'),('1gel/j'),('1gélule 2/j'),('1gélule/semaine'),('1sachet/j'),('2 sachet'),('2/j 2 fois j'),('2/J apres repas'),('2/j du 05au 25 j'),('2/J une 1/2h avant repas'),('20 UI 3/J'),('20/20/30UI'),('21/j'),('22 UI'),('26/j'),('26UI'),('2càc'),('2càc le soir'),('2cp 1/j'),('2cp 2/j'),('30UI 2/J'),('38 UI'),('4/8/8'),('40/40/40'),('4UI/6UI/6UI'),('5 gouttes/j'),('56 UI'),('5gouttes'),('60UI'),('8UI'),('des fois'),('j3/j7'),('le weekend');
/*!40000 ALTER TABLE `direction_lookup` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-06 20:48:17
