CREATE DATABASE  IF NOT EXISTS `rifka` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `rifka`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: rifka
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `allergy`
--

DROP TABLE IF EXISTS `allergy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `allergy` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_by` varchar(255) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `last_modified_date` timestamp NULL DEFAULT NULL,
  `version` int DEFAULT NULL,
  `designation` varchar(255) NOT NULL,
  `reaction` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `date` date DEFAULT NULL,
  `note` text,
  `doctor` varchar(255) DEFAULT NULL,
  `patient_id` bigint NOT NULL,
  `visit_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_allergy_patient` (`patient_id`),
  KEY `FK_allergy_visit` (`visit_id`),
  CONSTRAINT `FK_allergy_patient` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`id`),
  CONSTRAINT `FK_allergy_visit` FOREIGN KEY (`visit_id`) REFERENCES `visit` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `allergy`
--

LOCK TABLES `allergy` WRITE;
/*!40000 ALTER TABLE `allergy` DISABLE KEYS */;
INSERT INTO `allergy` VALUES (1,'rifka','2022-07-19 13:19:20','rifka','2022-07-19 13:19:20',0,'Penicilline G','Angio-œdème','ACTIVE',NULL,'','Tourab Rifka',33,33),(2,'rifka','2022-09-27 13:14:40','rifka','2022-09-27 13:14:40',0,'Penicilline G','','ACTIVE',NULL,'','Tourab Rifka',88,99),(3,'rifka','2022-10-26 12:10:16','rifka','2022-10-26 12:10:16',0,'Ibuprofène','oedeme','ACTIVE',NULL,'','Tourab Rifka',160,154),(4,'rifka','2022-10-27 09:15:49','rifka','2022-10-27 09:15:49',0,'Penicilline G','','ACTIVE',NULL,'','Tourab Rifka',163,157),(5,'rifka','2022-10-27 10:37:36','rifka','2022-10-27 10:37:36',0,'Penicilline G','','ACTIVE',NULL,'','Tourab Rifka',164,159),(6,'rifka','2022-11-05 08:55:20','rifka','2022-11-05 08:55:20',0,'Penicilline G','','ACTIVE',NULL,'','Tourab Rifka',181,182),(7,'rifka','2022-12-14 08:33:44','rifka','2022-12-14 08:33:44',0,'Ampicilline','','ACTIVE',NULL,'','Tourab Rifka',230,247),(8,'rifka','2022-12-14 10:45:49','rifka','2022-12-14 10:45:49',0,'Amoxicilline','fiévre ','ACTIVE',NULL,'','Tourab Rifka',20,249),(9,'rifka','2022-12-14 14:07:12','rifka','2022-12-14 14:07:12',0,'crustacés','oeudème','ACTIVE',NULL,'','Tourab Rifka',232,250),(10,'rifka','2023-01-08 09:29:09','rifka','2023-01-08 09:29:09',0,'anti coagulant','','ACTIVE',NULL,'','Tourab Rifka',270,304),(11,'rifka','2023-01-31 13:35:09','rifka','2023-01-31 13:35:09',0,'anti inflammatoire','Rougeur','ACTIVE',NULL,'','Tourab Rifka',296,345),(12,'rifka','2023-02-20 11:13:30','rifka','2023-02-20 11:13:30',0,'Penicilline G','','ACTIVE',NULL,'','Tourab Rifka',319,390),(13,'rifka','2023-03-29 10:30:03','rifka','2023-03-29 10:30:03',0,'beta lactamine','','ACTIVE',NULL,'','Tourab Rifka',353,472),(14,'rifka','2023-06-11 09:27:36','rifka','2023-06-11 09:27:36',0,'fève','Congestion nasale','ACTIVE',NULL,'','Tourab Rifka',427,600),(15,'rifka','2023-06-11 09:27:51','rifka','2023-06-11 09:27:51',0,'pollen','Congestion nasale','ACTIVE',NULL,'','Tourab Rifka',427,600),(16,'rifka','2023-07-07 20:47:59','rifka','2023-07-07 20:50:33',1,'Amoxicilline','Angio-œdème','RESOLVED',NULL,'note','Tourab Rifka',20,676),(17,'rifka','2023-07-09 21:13:23','rifka','2023-07-09 21:13:23',0,'Acide clavulanique','Angio-œdème','ACTIVE',NULL,'','Tourab Rifka',5,687),(18,'rifka','2023-09-11 12:17:14','rifka','2023-09-11 12:17:14',0,'Penicilline G','','ACTIVE',NULL,'','Tourab Rifka',561,845),(19,'rifka','2023-11-04 12:37:51','rifka','2023-11-04 12:37:51',0,'rougeure','cacahuète','ACTIVE',NULL,'','Tourab Rifka',629,971),(20,'rifka','2023-11-04 12:46:47','rifka','2023-11-04 12:46:47',0,'chocolat','Rougeur','ACTIVE',NULL,'','Tourab Rifka',629,971),(21,'rifka','2024-01-30 12:32:20','rifka','2024-01-30 12:32:20',0,'anti inflammatoire','Bronchospasme','ACTIVE',NULL,'','Tourab Rifka',675,1167),(22,'rifka','2024-01-30 12:33:02','rifka','2024-01-30 12:33:02',0,'Penicilline G','Bronchospasme','ACTIVE',NULL,'','Tourab Rifka',675,1167);
/*!40000 ALTER TABLE `allergy` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-06 20:48:15
