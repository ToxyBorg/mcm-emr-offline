CREATE DATABASE  IF NOT EXISTS `rifka` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `rifka`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: rifka
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `office`
--

DROP TABLE IF EXISTS `office`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `office` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_by` varchar(255) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `last_modified_date` timestamp NULL DEFAULT NULL,
  `version` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `logo` mediumtext,
  `fax` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `include_header_image` bit(1) NOT NULL DEFAULT b'0',
  `header_include_office_logo` bit(1) NOT NULL DEFAULT b'0',
  `header_image` mediumtext,
  `header_include_office_name` bit(1) NOT NULL DEFAULT b'0',
  `header_include_office_address` bit(1) NOT NULL DEFAULT b'0',
  `header_include_office_email` bit(1) NOT NULL DEFAULT b'0',
  `header_include_office_phone` bit(1) NOT NULL DEFAULT b'0',
  `header_include_office_fax` bit(1) NOT NULL DEFAULT b'0',
  `header_customize_text` bit(1) NOT NULL DEFAULT b'0',
  `include_footer_image` bit(1) NOT NULL DEFAULT b'0',
  `footer_include_office_logo` bit(1) NOT NULL DEFAULT b'0',
  `footer_image` mediumtext,
  `footer_include_office_name` bit(1) NOT NULL DEFAULT b'0',
  `footer_include_office_address` bit(1) NOT NULL DEFAULT b'0',
  `footer_include_office_email` bit(1) NOT NULL DEFAULT b'0',
  `footer_include_office_phone` bit(1) NOT NULL DEFAULT b'0',
  `footer_include_office_fax` bit(1) NOT NULL DEFAULT b'0',
  `footer_customize_text` bit(1) NOT NULL DEFAULT b'0',
  `enable_digital_signature` bit(1) NOT NULL DEFAULT b'0',
  `generate_barcode` bit(1) NOT NULL DEFAULT b'0',
  `use_initial_checkup` bit(1) NOT NULL DEFAULT b'0',
  `use_cat` bit(1) NOT NULL DEFAULT b'1',
  `use_exam` bit(1) NOT NULL DEFAULT b'0',
  `auto_add_exam_as_article` bit(1) NOT NULL DEFAULT b'0',
  `date_format` varchar(255) DEFAULT NULL,
  `time_format` varchar(255) DEFAULT NULL,
  `file_extensions` varchar(255) DEFAULT NULL,
  `file_path` varchar(255) DEFAULT 'c:/MCM/',
  `pin_authentication_activated` bit(1) NOT NULL DEFAULT b'0',
  `db_export_ability` bit(1) NOT NULL DEFAULT b'0',
  `session_expiration_duration` bit(1) NOT NULL DEFAULT b'0',
  `start_time` varchar(255) DEFAULT NULL,
  `appointment_period` bigint NOT NULL DEFAULT '0',
  `end_time` varchar(255) DEFAULT NULL,
  `last_update` datetime NOT NULL,
  `updated_by` varchar(255) NOT NULL,
  `use_fever` bit(1) NOT NULL DEFAULT b'0',
  `use_pulse` bit(1) NOT NULL DEFAULT b'0',
  `use_blood_pressure` bit(1) NOT NULL DEFAULT b'1',
  `use_respiratory_rate` bit(1) NOT NULL DEFAULT b'0',
  `use_oxygen_saturation` bit(1) NOT NULL DEFAULT b'0',
  `use_weight` bit(1) NOT NULL DEFAULT b'1',
  `use_height` bit(1) NOT NULL DEFAULT b'1',
  `use_bmi` bit(1) NOT NULL DEFAULT b'1',
  `use_pain` bit(1) NOT NULL DEFAULT b'0',
  `use_pregnancy_month` bit(1) NOT NULL DEFAULT b'0',
  `use_other` bit(1) NOT NULL DEFAULT b'0',
  `use_rth` bit(1) NOT NULL DEFAULT b'0',
  `use_cranial_circumference` bit(1) NOT NULL DEFAULT b'0',
  `use_shoe_size` bit(1) NOT NULL DEFAULT b'0',
  `display_title` bit(1) NOT NULL DEFAULT b'0',
  `display_patient_infos` bit(1) NOT NULL DEFAULT b'0',
  `header_height` int DEFAULT NULL,
  `footer_height` int DEFAULT NULL,
  `use_payment` bit(1) NOT NULL DEFAULT b'1',
  `speciality` varchar(255) DEFAULT NULL,
  `commune` varchar(255) DEFAULT NULL,
  `wilaya` varchar(255) DEFAULT NULL,
  `show_divider` bit(1) NOT NULL DEFAULT b'1',
  `use_auto_terminate_visits` bit(1) NOT NULL DEFAULT b'0',
  `use_appointment_time` bit(1) NOT NULL DEFAULT b'1',
  `use_lite_mode` bit(1) NOT NULL DEFAULT b'0',
  `use_glycemia` bit(1) NOT NULL DEFAULT b'0',
  `only_lite_mode` bit(1) NOT NULL DEFAULT b'0',
  `use_growth_charts` bit(1) NOT NULL DEFAULT b'0',
  `use_flexible_payment` bit(1) NOT NULL DEFAULT b'0',
  `dynamic_vital_signs` longtext,
  `display_date` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `office`
--

LOCK TABLES `office` WRITE;
/*!40000 ALTER TABLE `office` DISABLE KEYS */;
INSERT INTO `office` VALUES (1,NULL,NULL,'rifka','2024-01-29 11:59:02',73,'Dr Tourab Rifka\nCabinet de Rééducation Nutritionnelle\nOmnipraticienne\nMédecine Nutritionnelle et Diététique\nN° d\'ordre 3477/23','dr.tourab@gmail.com','0558 69 59 94','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMEAAAC/CAYAAABHargtAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAClESURBVHhe7Z0/zzxbctd5NYiXAQkxcgiInCUisBCxkaUlYBE42MBCCG2AkO+VCdYCZAskgg3QGozxyk68wZVsaQNILK2QkS79OTuf2XrqV6f7zEx3T888/ZVKPdN9/tSpqm/VOT3P796/8u2JT4G//H9/cfl0IuMkwYvBYI5BXX3mWn0+8SVOErwYfv5/f9YC2mv8/Oc//+mH57ENArye+CVOErwYCOxv/uKPmvz4m9+7XpH/+Kf/9vrZNpEU4CTBlzhJcFCYvcnuyB/82Y++/d0//vrb3/6T73/7m//r15r8+n/9B9frP/vP/+h6RX7wP77X5D/80Q+uwhiM5djKZ8dJgidgKfB4bsYnuyME9j/84a98+/f/098sxWdceyI5rBTMYYX4zDhJ8ARUJDArI25xCFgzvIGcg/8W+cf//u81yWT47DhJ8GQY+Gb+GPwEbAz8R0lA/5MEX+IkwZMRCRC3PZkAjwjjIFQUgp95mI95mf+z4yTBk2AFQMz+bnsM3BzMSxL7GPgcnD0Ym/nj4fjESYKngOAz+yNm/xjQt4gB7xhcIRVixjfrn4H/JU4S7AiDUAIYqI8QAPHASyUx85vxz+BfxkmCHZEJELP3PUJf9/lud2LgO+eJeZwk2AExIAlQDqZk7iqwR0TyEPzVIXc08E+C/AInCSaQPRF+UY2yVpAYoFzJ2LeeAWybM79bHsa+R9eTBL/ApycBgUA2JbAIToKMK0KQVegFz9x9CMB4BPKtVYA+CDr5hocxe/OduA2fngQEJ8EV38t70Pzv/+e/XFp9xC0kMFh9DWpA50DvCaRE3PM73on18KlJQDBBAoPewIskeDTgyNoEL0QbJYDteNNDX8Qt1Yn1cZIgVAKDkM8EISTgecYtwcgYEiAGehafc6U9AoGY/yTAtji3Q1OA5bc1BCLC/XtI4HOubIHi2JUwF208j+TsfxJgW3w6EuSAItDM1jkwf/Djf97NwnOBaR8CWULFsaNIgBz8vXlPrI9PTwK+s+0g4HNwEpgGZEYVoNxD7JOJlUUCUC1i8CPV+Ce2wacnAeAeW58qQA3KEUgAD8NL26D4vj8Gf48AvfsnHsOnIkEvwLhHIMYAfYQEbK+oLHMkYP8fgx+ZC3LHPrE+Ph0JKnAfITANUklgoEbYPo9nMJPhGYsxYuDzHfHVp+2rsTJG2py4D59uOzQHtkQxcPlcvSGKwRvBPUiTg9+xOCO4/TGo1wzskyT34SRBQPWWiG0NQRtBsGViANrls4XCuBJqq2A9SXAfThIEGMRkbbM5wQs5coBVAUffTCLGYWvE9scK8ApQz3jN994FJwkC3M5wFvBQSxBXW6IMAiMfht0C2X9pjGciB7sVK17zvSj2ra5Hx0mCAB1K4EYS8F3HZ9iH57SjPUJfvuf/4NXecE7nrwT9ID+6UrEQzi4jYnv6MgZj9cgyh6XnW+IkQQGcSgBLAgQH49QM7iFWENpydQu0NwwmAy8GJDoiOch5m8UbK9aM3pHMc+I67cM4/vYhOZxTPaJE5O974iRBARyWzwacC7ifYXDRnqBACIiRLdRaMIC4Gmxc1c3ARyeCFP3UFXGN+boksX0W5pAYzBvJoBwFJwkKGDwGC47WkTlj0da3ShKAgHMLtAfQIQe+2d7sbMY26KPEwL5HqjHi+MyrHugkIfayzxJOEhQwmDzo4kiCO1YDHch3qwBtliqA/dYKAMZBmNPgQgd0iYGI9AJ2D8E+Cvppp7Xs8AhOEhQwsAxuhUym4xS+WwVov5ThfDbXRsQ2VXvuMb8HWvRjb0/mzcE+F/ySZE5sV11HxHEQzxCeSZ754gCcJJgBAY2zDHKEe5EIkoAA9NlaiEHhZ+clcNzyuNXJQen3HIAKhEHiVqV3tV3vAB3nHZGoE2Myx1IC2QonCQKyA/hOdndbFLO9wc7nWAHWJIGIejG+c0rOKgi55zPaKfRDIBDjRHHs3lWhL8I4EINxJaGS9VkS+jAec8X1Zp/0MNquwkmCgGxIvuN0nCMJDCSdxTnBQLHPPaBfr6/PyP5mZ4LOIDfo/MwzMzhCwLJl8jcLBH0Vxx8V+2RSqBs2Uhd1WxL1Vt841whoey9OEiREY+oEHI1jIxEMIJ7psEfQG8P7Zt4YWJEECHoRhLSLejmuV5Cf3YI4XhTsAcGYH120mfrOSV4H62UNjOl8W+EkQUI2uM7FKQSYRNBBazkpjsFnxQxLlnTLYdAY9DHjoxeBWOlU3VsTjs/86KLN0FO956Ram3YGW+l/kmAABjsOMbvhIJy8JgkU5yKwnc9A4bvbHYM+9kWejaiLhEBfDsAjZEBoh9APOzBWtLXXNXCSoINoZB2AWOobEaYDs45ZwynOQ2Azj1XHgEC4H4Of9keDtvDqmhBs51qq4M9CO2xAX8ZxvWvYW5wk6CAHF0ZHcAZBiDORqhr4+RZHxfHJfm59CAAPjIiH2nvmELHPLf1vnTO2R9DbqiAZqsDPQrv8GnVUhxG8NAmiIUY+j4I+Sgb3cCYZWWdmx/g5E6kH2xogZn+DPxPNawXnnkN8vtQ2wra39ImgH+uIiYR1jpCBNtgF+zDGqG1HsBsJ7jWcoH8WA+Mvf/KTX3yerh/uh88R+XuGfXvtGBNHIjgSx8RAReLnHmJbgwJHc0W4Z5u5cSJuafsMqJ9rjqSvgl+RLAj91qwIu5OgUjrec2FNCOpJvvnqt7796b/7N01+9r3vfinf+c7HaxL6MQbSCPOH/+3DPHlev/dguxi8nA90jgSwbQX7I2T7SADGQXp93wGuH3tZUavgr6TZe+qjrR/F7tuhyrHeuwbGFKTIT//JrzX5n3/9b1zlT//qX7tZYn+I0sadiOE813kvoi5LsD0B27ZHExG4mqVENZZz0pbgt9TTn/sj8786WCPCD46se6kaKLTDXr0/b78VT6sEGqBJyPYte5PRJ3kk8OekIkQkBRgxLrrTzmCWDAiffV+fx3LdtDELmtkygT4DXDd2GCWCScOK+YjNnkICxIAz6EcD3jYG8QcJW6AvJLRzriw+h5BWCNEz8nU9gQzxTxS8L2yL83A6wmeDP7bN6Onw6sg24YVAFfhRPB9oP/rfa5/NSaBiXBUCjAxMwOUg74mBar8P25nL2QFDdOXSts1N5qcCXMZy7DgXz9rY6jyNwbUHn9smXuNn9cF5ZjLv2aaHuWevDm2DPdhWGug5+KO4LcKWJJHKhiM225QEKKAYgGblGHRZDEraNZn6xINtkzC2iPcWReJMOuWtGHP/6O/87evcV8JNRrZ/Rr7Xa4OzOAi7/ZEAVfvPBmwgEagGBPgcEawGbo2wJ4hkGLHrZiRQgbawKYBGM79Z+JqJQ8BvAcdtehKQ6HqpFBIVQqiPQWufUbgG/ynmSYAa+oFzFXZaIgIiGeijnR1nBNuS4JJpza454KPkrJuD3+tWcK5rYE7zWx0ggES46ndpP6qX43pobnPc0P8d0Vs790kS2AkSIFXwR4EEJhf632LfTUjQJp+CqAX2QvY3+BthkuJcvef3R65g6TPX+Jn5r9VhEsnAlkadR9DGmcTfE+K6MuL8+RrFe6+KuI6Mq72mbQ7BbaDn4Fd4BllIMlbZufEjViOBk3FtATMFShX0int+M759I/iu+P2RK+h97oE2UVzbv/71v9uuVTDH7362v2XeTMcbpPg8fm5jQ7RLZeQaJT6zjyLi54zc9hnoza9u2skgrwig8BzbYmNJNIKbSZCV9ntTenIGQUKA97Y/Bj/taP9qiOu8bo8uxo62EPkzmQ1ncaUqcEbgvoHtC4B2SEcu1XRRLltJpRFjkoqkgvv5Wa/ts9BsM61h5HzAM8Qk0yNBXuOqJCAo2C5UwY9AgJY9yV5T+zzW0RH1xcCsg/WSqeJ6euvCMTrSrPXN7/9OC1qDeS6BLIl9tbO2zvaO+mVde7o/E9ia7I7NkIoAUWhjNajWk+/dtR3KRkRwZM+B3MPBtGlOuTA0K5O/Hw1Rv0aCScjaGLydES7Pq3Wx7aGdmQxHsaUy8LPNtJvXLLltFttJrmuFmHTR/iDrekQ0O08JxCqagz6L1cCz1xJuIkHlZIJaAvScQUayNCPVOODIDql01cAE+O/+8ddfGJw2tvPVqE5CqCI5WK/boMv25n//i3953SIhBnNsZ1/H6vmhzXMZt22XLvotYaTNltCGEAEbar8c/FEgC21jvPXwEAm4EuBzhrck2z4qFD8fHVnXvBaQ14bgBNYfs5hOdMtyDcoQmEpGfNbGvozfktFlvJ4/lOgX+juuyPPm78+Aax3dFmFf2sydDUSXBL2Fc7/J5DCcN2dwnmPoUSMewdijWLIPhtdGBJyOwzn+K6kc+LH/CGxrgDgec1ol8E/lI+65TaJP6x90iBjVZ0u4TqvBCAkQSEOfuTXcTAKNhWN7h2ANbNs5BSJG2x0FWV++s2ZFG33/n/6tKwlwoG+EIvhufz97P14r2D62RdQB6SUr7vPcquAYII53BLgm3qqNkICr9qZfDzdvhxgMg2G8yrDNqKECKO+IvC7t07L/JBCAw6+lGTEzRUQ7OWbvWqHXhu+5OvR8ZlXAb2JuzmcB+2JDgjsHfhbtzlZ0NRLoYAyWDakxW1aBKJdJK0P2nPZMPKoL/Q02gl8C4ARLM59zaeYztqrmz/f83rsfke/pk/YbxOUQXfmPZ6zjqGhrmGzomzakIgCizbnObYmGSGBnK0A2nmJZpX1vQuCzuTZbQx0VAzHKKOzP+gn+H/7GrzbRATrEtxURc3Pl+37vtY+o+l77Q9aZLZJEiGOMzLkH0EMiRPv2xOduiap1LJKATgqGq4yGYDgJcGS4FgyC8C6ZQ6riu2VkDo4DWDcVAPtwZc9KwEcH4TCy11Hsc90idaq6a1HfSu9nrUX/ZBvPCbanT6XzIgnsuFQFfv71V93AeZaxMto6LgYkkyAYkgBV+D7yI4t2QawA2Ij7kCA7h3GZ70iY8yv3XJPrzKju7YGm92RnAhufRTv3BPv3fDpEgpbpOlUAY1kFepM8y1gRGo4AR9rf7lze3ROwSCbCnN6u1QrAXrvZahL6Rwcwtpno2WBNrsvPvYqAb60IR9BdqHf8AbKSmIj43DsXzJKADiweA/WqQDPQTLY4AtALAxDY/IslxMDPhlLmMgfgGVsK9v7un7nHPHlMiMX9IwSSflKu96Y1VH7mO6KPjwD1yH+KkiX7oZeIZklABxYfjRKlGYdgOIhxekBHDEBg9wyWhcCdC1qrI8QC2IBAZ548joQ6kp2iLn52TZWvrfbA9tV69lwjc2FzbBxtXgl+Z5tK+6xjlwQ0nDMKBODZnou+FwQggYixViPBdAZym4ANEIkWx+E7921zRKgXV3xebY0Q7lv1euup7m0FbK9vR/xKu+qHsy4JaEiQ5/KoEAAY5BXAWgjqkYyhRBJUjiVYeI6QXdxq4QwdwhUCmH3yOHsGzCjQSSJUvjfxaZu9UNlKPbDxSIKjDW2z7n0STIboEYD7Sw5cer4nLJm3kACDaqyeA6IT4n8rR2cwH3PTpjfGEZD1aOuaKh1vhyrfmwD21L9nP/Qgu4/4l+dUA/0qShIw+NI2qEJUdE8DLeFRElRgfQi/LVgBYl/En+uPZIsKlX5Ued549aqBRNgLlY7Mj/iWaMm/+IQ2We8PJHCiuSrgu+MKR3U2i76VBJWxAGtEeMYWyOCPV/riFLdBr4Csp+uskqGJMNrH/luttxpXHbHz6B/V6dc43hckQHpVAGlngUu7VwGLHskUUXok4B4CARiz6kcF4HnV/6jI/kR37pHwqoNy2xZd2gBj4hlrZk62pCainvAccYsqviABD3tVwIXb9lWArhipCtqeVCRgHAwoAbLR+W4FoG/uf1RUvuQe0tbR2RnkH9HsszeYky3RCAm45jdEVxLEBefFKpbAZyz0URCYECEbpieQgD7A9bJ2yVRVFe7xXBu9ip16eroG1lMdkue2xnsCHfFV5ZMoPtdH4gsSzG2FWLCGsc+rgLVhqKVsgdAGwVjahSv9JUA1Dtsg2rySXcSczjwj6+dqwHfixTZ7oJoH/yCjJOD8QHvxYTtEkFeMV2JH8ErO1lBxG9MjhPfj1oYrpMCQlbHpY9tXA35c8iXrqhIk8TLSfy1U8+jbJRJEv0Y/fawEX381dB54RbT1TfqznydjYxCM1iMCwjP/PTB9JFDuw3cNu1cwrIkRnZv9iq1yi4vLDuFZ0Lf4IPqlJ/j9CxI4SG8rZNlzoc9c8CNgjQgZeymwFZ/NtWEMyPWqdhmBMVIlybk/o18blY3VjW1O5Z8skIAYEB9I0NsKtQPQtFDxas5WX9epYAgrQy+L9AI/in+Y9W6IftZ2VaLkngfkrWOD8fMc3ruFBLwhEh9I0NsK9d4CZGWOiqgn63S9Xglg9vuVwUYEAnmIFq9imwrqntfQ7DUlwzI+pvs832PdlV5g1IeRBPRtJCAQqv2e0pg+tcnYY8FrQ529trVP8ggJMCpEgEyMq7wq5nTvnQvidnkvOJ9XArvyTxb8hb8Bvv8lCQqGK3vu+faChmNd/vhVGWxEPC+wrWKsd7OVwGasrYoRqsHeeIQEbJ1czxgJJva/i2Nj8PMvkyQAhqkMdotABP6YzorwbmBNSLVthgR7r9n51Au7V37JIgla3EcSVAcexcbvANahwSiJEMBMXhnsHmHcd7FXBrYj4HOMQIy917wqCXoLU2z8qtBIGiq+EVoz+JG2LXrTt0WAOOglzL1jBH8C532IBKBHAhm+9wLXhPojBj+GWJsACGMyPvtTnfROYE29rXP1BnFLaF+v95CAvouV4F1IQPbnBzKCVKkMtIZIgle2WQ+SoDoXcP+ZyCTo+bgkAV/emQQefrcOfuUzVIIqXp5BAm3c9JpiNPrhJEGABMAAe5LgXXFEEhijlT+yfBoSsDiE16AsujLGVvLOlQDMkeBZa2beW84EvsFDhklwRIf2dNIgnAH4K9DR7L9WlWAcDuCvljhGMUeCPdbc8zuJp/JHFkhgkkIWSYAc1ZnZGH6HADB9qQIQrFHWrBiMdZJgG1Qk4N6tJBCNBAywRIJq4iMAvRSC/w/+7EctC+f/DIpiwPOcdlQL/6wa41R9bhXnOEmwPqo41P8kvsofWfAzsSLGSPCHx/mPsUagE0ZHWJS/AVSB7D0MQBveGNFntP8tYv+tA+JZmCPB1nFSjc89hMNu9kUl+Dj6ZowEOyzuVqCPwRv3/j0CEPxkf9pCAPpqPIWx4uvUPM6oqAfjvSPmSLA18FMG9/DnKAl8MyQaCcDs3w5Ni4ud9kYMVMQ/fHMb0wtYg9FtTw7+DO7xnHZz4y6J88Z957ug2eigJCB5Vf7IUpLAheVFKc8mAXMrZFf/8M09fBWs3HPrQx/7V0aM0KD0ubci2OddSUDCLH8x3vnPJoQ+w9/ZF1H0S/4DxyESsOjYaS+gVwxKMjTbHoPTRcUrEg+99HEcZATMh/iGyfFHxfbvSoLe1nnrGOn5T3+NkADBL1HX63ZojgQs+hksN3AhgIdWF1Mt0MxP8NLH/iOI7fiMkTDWIyRAh3cDtjkiCbD1CAloU5KgOX0K8qrEIY0EO+z3BPog7P155Un2nwtG7hP8Zn769QyW4VzZgZEE1Zxzgj7I1kGxN7RVRQJ/VN0SPZ/qq158KPgSgTBR11+SYLrZYzgLZEtUoadYhgacg21Q0sMpWxsWkBfId5753wWCLCNzCNvZJ/fDHlSUJcNWQh+MvXVQ7A1sxJqqZEnsZBuujd746AQJKl9EwSckS9rHsa4kQHokQKpF2m8Evbbe40rwI259CKYq+BGeQxTa98aeQ6+9Y2Eo5ohzj8q7kgCwpl58PAvEAAmr8kUUfJLfDIEPJOid+l1k7twLpB5s73wIC/CVJ8Hv1gcx4BGyvu/5zfzog8TxHkHUCX2YtzLmktDPjPNuYNucYyPuFB71wT2gCoz8RkBMQZas4/VgzAP2/b1qUO35RhdsO65tnmkcAk0Gu+0x6CSAVwKKdgSmY8TxojwCCcVc91YBBL2rjPMOqF6gtAR5OTM+Y82QYMRf+IW2OU4+kmBieY8ESH5DNBp0BhfZ20xOxkcM/igsyL0+QvBTLSoDq8OoLj209U/jQ0x0wmCVIUeEvhDpHUlAxs9x0UhwiY2914zfCOwRfxFX+Dfr+JEE08NqkQrPbgk22zIxwWxwEehROQOfikA7yKKy6gWquUf1WWrHHG7J1CnqeIv0Ms6rg/VUSZK4mPPRVmAu5iXhjPjLxJR1vJIA0KDa8ymN8YOL5bnC5DK1RwDaEPiOa18/R+TvI+j1cR7WhR6PBL/COJDgnaCNqjMjW6EquLZAnCP6rfJDFPyKT4zfiA8kmFso0s4Fg2WPsRACmwDPilIV3PK43YkLnMNoOzHXnnUg6DlSUkeE8wDjvROwYZUgjQme3+qXexDnaDpNvhvxG21iko1oJMgDz54LJtY7eTVghMGFRBLASjP/yDgZa7bnGXqgzxpVAPFQfKueRwZr6R6Kp7U+A8bXCAmIv56eH0jgdelcsMR87zOpgqIEGRXA7UJvjN64Yun5KJy/qlSPCOO57ncBa6niIpNgLd+MgHmx9RIJiLu5t3VfbIfa9Sc/6W6JWDTGmIPjMCmfrQQISrP94V4PexmSedARvdaqAozj3nOvdWwJ1tDsNCW+HBN8z/9L3z3XbFwt+Q6SEHdRz4gPJIjoVQMWDhFG4KRuNxA+HyVA0AFdRsrpqDBW7wD2Csh+0UZLVWBvfzIfdh7xHW2IO/pUenZJUDFf4T7VYg5OxhVDcfBVkWcZLoP5kbVIQEbS4O9GgioW2tb4Sb5k3tGtENWC9j1d+ySYOrDIHhF4JhEqA3iPaxTvxeuzoE4YqTLgrSIJsN2z13Yvst4teBbeCoE918tc6HXvVijrOksC3gZQ8rIBkFYKL2+K8qAgT1i12RM9HVknh6YlY45IJMGrItpJ+xxtK9Ric5KRKkAbKvMc5kkwMb0yAEImsBxqhGxAsbeRKvR0QH9IsGTQEWEMS++rA3shxEBOhPpem+7p36bTZF9eriwlLp7zFwDZH1nfLglo2CYs3g0rrSQmEuQJQHXvKEC3NUkw9yru6Ih+0pcEe94StyowkeMZwLZk9pEtLCSozmc5HrskECw2GyGK+0IHzhPM4Za2WwEd1iQB+893IAFgHdV2OO8A9gRz3nogznrm77OVwGuVDT4Y5EKEUdjWYLml7yOo5uHeiFFHBKO/8uvRCOxSJcBW/af7zyQBdl7yF216CSnrPUQCFl1lBI3i/jAP3oPtjkKC0ffNS0JFeRcSsAb8mv3tgfgZa8RXzIuvlvyFL0ZfVS9uh5yYXwazQRSzQy+Yb71/C+IYebzqWdWGwB3ZYy4JmQfD5zleDeiPv6sq4FYI2XudzMmBGALMHYp5ZhUY0XGRBMBFZ6NEsRpU2NJYcew8T/WsagMJyByVQUcFw796FdA2rKGq/B6IaYfsuVbnGzm/8Xy0CoAhErjoqjwqrRpMk9LulYC+a5AAw78NCYqzAGIVAMbEXmBe3wotVQHa3BKLQ9shrz3jKJRQ2jwKDZzFZ/H6KBgH4z5CAgxv9llLr2eiSnY/+853PlQBZQ8wD7YdeYHB7wJsmW7Rbehg7BV2zVWDVi5nfkUeBQtGmC+KOsQreGQux36EBDgGYZxXB7asEh1+dX35ei9G/cc8EGCkChg3t2CRBBEMTjYgK2QjIRjPknmvgZiXBfvvjXvin2P7D/Dp1xMRPwvuMc6jJEDfavxXgbbCv5VfrQKxrd/vxdI43se/SwRAbt0GiaEzgWDwFuBLvyJPBruXBPSTBCzKLBvFfR9tLH+SoumXBGjsykCPkgBdOA+8KrQLfsuV3sSW7VbZ8R7MjYPveI5/8Htle4R4QPDh3Hi9ZzeRALTAulSDqmwicf94K1w0QmCT9TMhWLifEZ5Jit/+k+9/qBQIY2pQrxHcg3jZuKNCX+bJuGf9zwB6IgR79mmr7JMvt0LPRtzHL9gV+85VAeMAn/fgGisMnwmEylVZI8ojxlNhJRMi/qdbKuGZ/5A//mN+xmm6TxLBdzJ5ZeAlYb7eWyF0fwWgJ77KBLCqb7mO3tj6CQKQ4CrbKybAygdi7lmXBHaKSvpZBRe3RSsckgH9nVNCsHACMBtEIsTvVgu3ToyhXo59LwkYW3K9Ilx/ldD8dXhvqBN2xW/YuLI9gn/ZBvV8wFjxWuGmg3EcECFLzG2LMKz/BjWjujcH51T8r9mR6WPgRwL4PYoVgm2TYoWJ/UaE8XCSOon4+VkY0YE2jQDFr8P4NfpurzUxD0JQuw1CevaHICQ2+2WM6H3zmSCCCcj21a+LCIblWaXIGhnGbEEAWxnmskZP6HNvPxyVMWL4rbGkA8+b/yYbVknMKh7bboE8Lvpwj8qMT7FzjwTYnzaPxtJDJAD8E8sqkyjc57mIhn0UGsz/qjUZ3epAxo9ZpGdIJLa7RXAAJFxjLVug0st72g7fVD6L/4Z8y/XlsdELIbEt+Q77k4Qe1e9hEgCUnjska1SUXdOgcSw+a0ACM5IiH6Qrg94qjIkDmG/NNa2JSi/uaasqeeWkJfZYI3Pou7nKrB893z2K1UhQvV2IEt8W9Qz6qKHpnwXdMBZZA5EMlXFHhf4expjjqKh00yZI5a+4fY3991gnOrkN6vmI+3EbhDyq2yokQAmEQO8RoWWY6TntULzCFoZ2PoiAxPPDvWTACYzVW8dRUNnTwKm2QR6GRey/hW8EYyMkFfwzVwV4Rhvtb99HsBoJAJm+KrFKI8L0fKt3z70xNRRGi+cH950jZLAN2yD6OearINqgqtp8z37pfV4bEnPpbRBCAoMsEmANrEoCrihHSZ0lAlujFRcR5++BZz7X6BhzdItkGxzlPjTPNzf/M+Ha27pJVOn8pk+i/vbZA9EXle0V7b9m7IBVSBCBcmT7bOgo7UeYyRksZg2MGCS24bOGjFukyvAIxocEMQs5TgTflSNBndAbv+QE1ZLS5A/bAu2z5VocG5talXv2R2hD27V1Wo0EKsYVA1YlV4nV4FlQX3TgMDb3B3QSwCzU05sxlaMgrrPyCd+5bzv1d51brsXxsSs2rmyPVAmowr26bkICpco60fg/+953r69OnwXmniOBVYCK4f9IpKfvM9eRoS7qS3Xm4Bt9kH8VFvbJ99cGAY1dCfC5KsBz/z/VhyZBRjPiwg9pSFWK9wRzzpEAAlCG54x/RGhLriMVYC8wn8LLiRECQBSxhb7bkmASgodAjw6IwvmA57bfYpFzQL/4E30WSMDzVyBBtl2z/xTolf21+RaYGxc7ImxtsO0cAXjuFhRspe8qJOgpx32kykQK9xHL8t7Bxnxze9JMgq0c8QjUKeqm3fMfOPKZezzbCj0bNZ0mO/oyokcAhKTkQfilSSB4TubpEQHpvTHaauGC8dkK9UiAMyIJsn5HQLYR39GzVwEqO+8B9CKol7ZACInJN0F5fWtjs+1Qxsgf2lUHta0NwPhzJOAZJFCPrfUZQU8H77cK8L3vflEBEAmw1zqi3ZBbKsBeOu5SCYBGIMjzW4ooOsr2ju11bTBujwQ4i2c4xLZHQKUH9wzuXAGwKXbfe8sZdWILxEF4rgLwazzt9iQA2J0ECEEes1SWWLJ12FpGyePwvUcC7u1xMHsU6IU0eyXbNgJgz2BLr1viqs8kI1ugaOu97bzqdkjle4uIz3FMryLgOA9vaxslj8X3ORLkN0Nr6rIWtFGuslcCXCqr64hr2Go9zrd0COb+M7ZAEatWgnyNiPf43AI8Za0s0YFbgbHfgQTZlnz2ZQM6KxHVvbXAuKMVwC1QtLPYSr+IXbdDgs/KSEWIvyrHcdYA41GGcVblpJ5zjoCrDasKEM4ASkZ1bw69cYTP/UvdpQrAc84J9qvGru6tjVW3Q/eAACdb9YiA8CxmtNbvDuP0jEygUw0qR7Use0ASoDc2IdCtAFwlAM9db7XuexDHjPA+dmq2nILbf95a2dQ/R/fPUJ6NXUnQW3Az4NdfXZ1ZSd4a3WO8qk+be3Ie1SA7jFJ9RBKoMzaJNvPX96jvqJ3usafQRhAAO8atpUTwSsWlDW2PgqeSwO9c/R1haWvUslzYHi2hN2eEDtRxiiQYGWMvMHdVAbRNTBRgVNd71kQfBNux/Yn/gQNtyGeE4PcV6FEqgNiNBNWivee1BdwU4HMVoR32pqpB2xHkeeP3OC8SCYDjJEFGHnNPEOS5arbsf7HJqF0eBTZgrpHtD3Yk+yP0e6b9KjyVBMJnXq0IFRli1qsOzHPzgPjczwZPdh7ZqwqqpTnuRTUu965CtQwvErRFy/7TM3Tt6da7P4qoB5mc4I//RFWbRfshPEdojzjWkfD0gzHIRmnGTg7P8iEApvYGQBwrjwt6Qc396ESEw/IzSBCvzI9A+ngGiImA57St+mcZRe7HHG57CGq2PmT4TIAY/JDE4HecI+IQJMjQWK30T1JVBKVtBWh3CYSIyug9Z9A/H+gs3xFV37XhHOjU5GKDKJI/C1laW9jfZ3yeA2282hcxkAls3/v3BBua+e3vuEfF00gQDZONlJ3xzVe/1SUC9yFCy4oDxqZN1Y57mQT8UJbR678G4rh8JtDdGl7XOn3HHraN+hiwZGvFLGwwxvYZtonjuOWZy/weemP2n5urd/9Z2JUEceG9zxk+i1uBLNxHzI5z4HmvjSTQwRUJwNIc94LgA4zPZ9bMiwDX16peaCP8bD8qGIGJ8FkyWCUQ2kZxny95YtY3+KNoJyTO4XhzUIej4GkkuBXsfcmAZMUeGXiW/91yNWdPD0mg03HqVsg68N3gbPv/SVin7/5bpVtYF+A+AU1GRghQzjYEtZlaif9lbjK9rziRnPX9DjGsDI7DfMzb0ynjlrZ74JBngohoLD7HLcIcGQyakYzjHJEEyFbZKgaB15YdL2sj8BHXwX0JMgra0sfsbsCa4c3yvtrMwnMJQcBLIDM+ok636HVEvBQJWqAoBMzCFqltH6Z2GdlpOhPHSwI+c38LOD9X53Y9EkDdYxv7jcI+joFIilYhpsD2msUtTg76LM7zyjg8CSKiU5tjAxEqMnCPbBq3EcDP8YpD2TaQBSFB7/XoI4jzOWdbw5TtJQDXmP1t/yjinFzZwigGueJ9+8zJO+ClSJDRHDEFeAuiSXpVwbNCfKsC8mcC360QmXAtEjhP03eSHPwGPvqZ/ZW1UY0Z59tizqPjpUkgcByBZVWoiIDwrAXZRJwKBL4kyP+O4BHEAGsEuOgatz3OtdacJ8ZxWBLckpGuATYFk2+QkIoIPmtbpEAG+hP4EIDzAJ9v0aEHdWv6EfyXqmX2lwDOtcac9+KZcz8ThyfBXHDkZ9dsSmBNQuaf2yIRiHEMScC2iL1xD5UuPdC2yUQ43q6Y/RsJp/sS4JYxb8HSuPH5VjocHYffDukYA3zOaX7nilAVyLa9qgBBrr8rTELgUwU8D+TxRe9+BQ6Y/Hc0v/n932kkaOeSCwGAus6NGdveiqU+94z5bniZM8G9gUB7qgLBDhmqyuAWCcL8+Pf+VSNDRYJ7AkYS+LZF9D5X8Pk9859YxlscjJdA8DSZMjBbkd4Wifv5oBoD7zpOuNfDaLsTz8enIEFEI8Jli1RVhrZF4tllm5QrwkmC98OnqQTC4PTwbGWoqsO1KkwS4XhnkL8HPhUJJAAgwzeBCFNlqMhwrQqTxAOt4pbpxGvjU22HJACIwdxkCnACvfc7A6823SbRplWIy1YJccwTr4dPdyYYgVsggt7KEK/5l95IhpMIr4eTBAExo8etUny9GsXKIGnsJxnieCeOi5MEATFYDWIzfSPElP2r6sD9eIi2z0mC18CnJUEVmAZ+hPeacDC+nB2oAPEwfa0Mk1A9WmW4HKRPHBsnCQIM9oxu20CIuGW6/rsAZCKEZIgi8vcT++PcDg1gKUh5ft0yXV63QgQEUkiGvFXKcuI5OEmwEghiA5xgp0J4qJYUkgHhny3SVpwkeB5OEqyISIQPn6ftkBXih7/xq40QXLkXt0onnoOTBCvCYM5yfTYFfPuz6qlKWCnaFumyTTrxHJwkWBEG/CiuRLlUgxPPwUmCE58eJwlOfHJ8++3/B+2PHcBmDHQtAAAAAElFTkSuQmCC','038451133',' Boulevard 1er Novembre bloc 13,Le Majestic, Annaba.',NULL,_binary '\0',_binary '\0',NULL,_binary '\0',_binary '\0',_binary '\0',_binary '\0',_binary '\0',_binary '\0',_binary '\0',_binary '\0',NULL,_binary '\0',_binary '\0',_binary '\0',_binary '\0',_binary '\0',_binary '\0',_binary '\0',_binary '\0',_binary '\0',_binary '',_binary '\0',_binary '\0',NULL,NULL,NULL,'c:/MCM/',_binary '\0',_binary '\0',_binary '\0','2024-01-29T00:10:00.369Z',1,'2024-01-29T22:59:00.369Z','2024-01-29 11:59:00','Rifka Tourab',_binary '\0',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '',_binary '',_binary '',_binary '\0',_binary '\0',_binary '\0',_binary '',_binary '',_binary '\0',_binary '\0',_binary '\0',200,NULL,_binary '\0','Physiologie clinique et exploration fonctionnelle métabolique et nutrition','23001','23',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0',_binary '\0',_binary '',_binary '\0','{}',_binary '\0');
/*!40000 ALTER TABLE `office` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-06 20:48:13
