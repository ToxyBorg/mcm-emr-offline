CREATE DATABASE  IF NOT EXISTS `mecheret` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `mecheret`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: mcm-prod.chwkfp078t9a.eu-west-3.rds.amazonaws.com    Database: mecheret
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `prescription`
--

DROP TABLE IF EXISTS `prescription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prescription` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `last_modified_date` timestamp NULL DEFAULT NULL,
  `version` int DEFAULT NULL,
  `active` bit(1) NOT NULL,
  `general_note` varchar(255) DEFAULT NULL,
  `template` bit(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prescription`
--

LOCK TABLES `prescription` WRITE;
/*!40000 ALTER TABLE `prescription` DISABLE KEYS */;
INSERT INTO `prescription` VALUES (1,'OR0078-000001','doctor','2023-05-23 14:34:42','doctor','2023-05-23 14:34:42',1,_binary '',NULL,_binary '\0'),(2,'OR0078-000002','doctor','2023-05-23 16:06:45','doctor','2023-05-23 16:06:45',1,_binary '',NULL,_binary '\0'),(3,'OR0078-000003','doctor','2023-05-23 16:17:00','doctor','2023-05-23 16:17:00',1,_binary '',NULL,_binary '\0'),(4,'OR0078-000004','doctor','2023-05-29 18:47:52','doctor','2023-05-29 18:47:52',1,_binary '',NULL,_binary '\0'),(5,'OR0078-000005','doctor','2023-05-30 07:52:26','doctor','2023-05-30 07:52:26',1,_binary '',NULL,_binary '\0'),(6,'OR0078-000006','doctor','2023-05-30 07:53:43','doctor','2023-05-30 07:53:43',1,_binary '',NULL,_binary '\0'),(7,NULL,'doctor','2023-05-30 08:09:09','doctor','2023-05-30 08:09:09',0,_binary '',NULL,_binary ''),(8,NULL,'doctor','2023-05-30 08:51:21','doctor','2023-05-30 08:51:21',0,_binary '',NULL,_binary ''),(9,'OR0078-000009','doctor','2023-05-30 11:21:16','doctor','2023-05-30 11:21:16',1,_binary '',NULL,_binary '\0'),(10,NULL,'doctor','2023-05-30 11:58:59','doctor','2023-05-30 11:58:59',0,_binary '',NULL,_binary ''),(11,'OR0078-000011','doctor','2023-06-04 14:32:35','doctor','2023-06-04 14:32:35',1,_binary '',NULL,_binary '\0'),(12,'OR0078-000012','doctor','2023-06-04 15:14:32','doctor','2023-06-04 15:14:32',1,_binary '',NULL,_binary '\0'),(13,'OR0078-000013','doctor','2023-06-04 15:59:19','doctor','2023-06-04 15:59:19',1,_binary '',NULL,_binary '\0'),(14,'OR0078-000014','doctor','2023-06-05 10:21:45','doctor','2023-06-05 10:21:45',1,_binary '',NULL,_binary '\0'),(15,'OR0078-000015','doctor','2023-11-27 16:51:30','doctor','2023-11-27 16:51:30',1,_binary '',NULL,_binary '\0');
/*!40000 ALTER TABLE `prescription` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-03 18:30:43
