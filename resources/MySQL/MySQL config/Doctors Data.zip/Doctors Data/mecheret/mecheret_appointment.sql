CREATE DATABASE  IF NOT EXISTS `mecheret` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `mecheret`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: mcm-prod.chwkfp078t9a.eu-west-3.rds.amazonaws.com    Database: mecheret
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `appointment`
--

DROP TABLE IF EXISTS `appointment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `appointment` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_by` varchar(255) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `last_modified_date` timestamp NULL DEFAULT NULL,
  `version` int DEFAULT NULL,
  `cancelation_reason` varchar(255) DEFAULT NULL,
  `appointment_date` datetime DEFAULT NULL,
  `appointment_period` varchar(255) NOT NULL,
  `note` text,
  `status` int DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `type_id` bigint DEFAULT NULL,
  `patient_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_appointment_patient` (`patient_id`),
  KEY `FK_appointment_type` (`type_id`),
  KEY `FK_appointment_user` (`user_id`),
  CONSTRAINT `FK_appointment_patient` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`id`),
  CONSTRAINT `FK_appointment_type` FOREIGN KEY (`type_id`) REFERENCES `appointment_type` (`id`),
  CONSTRAINT `FK_appointment_user` FOREIGN KEY (`user_id`) REFERENCES `app_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointment`
--

LOCK TABLES `appointment` WRITE;
/*!40000 ALTER TABLE `appointment` DISABLE KEYS */;
INSERT INTO `appointment` VALUES (1,'doctor','2023-05-23 14:34:42','doctor','2023-05-23 14:34:42',1,NULL,'2023-05-23 14:34:42','15:34','',3,NULL,1,1,1),(2,'doctor','2023-05-23 16:06:45','doctor','2023-05-23 16:06:45',1,NULL,'2023-05-23 16:06:45','17:6','',3,NULL,1,3,1),(3,'doctor','2023-05-23 16:17:00','doctor','2023-05-23 16:17:00',1,NULL,'2023-05-23 16:17:00','17:17','',3,NULL,1,4,1),(4,'doctor','2023-05-29 18:47:52','doctor','2023-05-29 18:47:52',1,NULL,'2023-05-29 18:47:52','19:47','',3,NULL,1,5,1),(5,'doctor','2023-05-30 07:52:26','doctor','2023-05-30 07:52:26',1,NULL,'2023-05-30 07:52:26','8:52','',3,NULL,1,3,1),(6,'doctor','2023-05-30 07:53:43','doctor','2023-05-30 07:53:43',1,NULL,'2023-05-30 07:53:43','8:53','',3,NULL,1,5,1),(7,'doctor','2023-05-30 11:21:16','doctor','2023-05-30 11:21:16',1,NULL,'2023-05-30 11:21:16','12:21','',3,NULL,1,1,1),(8,'doctor','2023-06-04 14:32:35','doctor','2023-06-04 14:32:35',1,NULL,'2023-06-04 14:32:35','15:32','',3,NULL,1,2,1),(9,'doctor','2023-06-04 15:14:32','doctor','2023-06-04 15:14:32',1,NULL,'2023-06-04 15:14:32','16:14','',3,NULL,1,6,1),(10,'doctor','2023-06-04 15:59:19','doctor','2023-06-04 15:59:19',1,NULL,'2023-06-04 15:59:19','16:59','',3,NULL,1,7,1),(11,'doctor','2023-06-05 10:21:45','doctor','2023-06-05 10:21:45',1,NULL,'2023-06-05 10:21:45','11:21','',3,NULL,1,7,1),(12,'doctor','2023-11-27 16:51:30','doctor','2023-11-27 16:51:30',1,NULL,'2023-11-27 16:51:30','17:51','',3,NULL,1,10,1);
/*!40000 ALTER TABLE `appointment` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-03 18:26:49
