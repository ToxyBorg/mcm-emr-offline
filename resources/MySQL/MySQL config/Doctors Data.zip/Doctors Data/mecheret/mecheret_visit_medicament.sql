CREATE DATABASE  IF NOT EXISTS `mecheret` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `mecheret`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: mcm-prod.chwkfp078t9a.eu-west-3.rds.amazonaws.com    Database: mecheret
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `visit_medicament`
--

DROP TABLE IF EXISTS `visit_medicament`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `visit_medicament` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_by` varchar(255) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `last_modified_date` timestamp NULL DEFAULT NULL,
  `version` int DEFAULT NULL,
  `medicament` varchar(255) NOT NULL,
  `quantity` int DEFAULT NULL,
  `dosage` varchar(255) DEFAULT NULL,
  `note` text,
  `date` date DEFAULT NULL,
  `form` varchar(255) NOT NULL,
  `compact` varchar(255) NOT NULL,
  `direction` varchar(255) NOT NULL,
  `duration` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `doctor` varchar(255) DEFAULT NULL,
  `patient_id` bigint DEFAULT NULL,
  `visit_id` bigint DEFAULT NULL,
  `prescription_id` bigint DEFAULT NULL,
  `sponsored` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`),
  KEY `FK_visit_medicament_patient` (`patient_id`),
  KEY `FK_visit_medicament_visit` (`visit_id`),
  KEY `FK_visit_medicament_prescription` (`prescription_id`),
  CONSTRAINT `FK_visit_medicament_patient` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`id`),
  CONSTRAINT `FK_visit_medicament_prescription` FOREIGN KEY (`prescription_id`) REFERENCES `prescription` (`id`),
  CONSTRAINT `FK_visit_medicament_visit` FOREIGN KEY (`visit_id`) REFERENCES `visit` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visit_medicament`
--

LOCK TABLES `visit_medicament` WRITE;
/*!40000 ALTER TABLE `visit_medicament` DISABLE KEYS */;
INSERT INTO `visit_medicament` VALUES (1,'doctor','2023-05-23 14:36:32','doctor','2023-05-23 15:19:41',1,'DIOSMECTA',1,'3 G','','2023-05-24','Pdre. Susp. Buv.','','a la demande','','ACTIVE','Mecheret mohammed',1,1,1,_binary '\0'),(3,'doctor','2023-05-23 14:39:38','doctor','2023-05-23 14:39:38',0,'ABILIZOLE',1,'15 MG','','2023-05-23','Cp.','','1/2 /J','','ACTIVE','Mecheret mohammed',1,1,1,_binary '\0'),(4,'doctor','2023-05-23 15:11:38','doctor','2023-05-23 15:11:38',0,'LANTUS',NULL,'&16','','2023-05-23','Inj.','','1/J','02 Mois','ACTIVE','Mecheret mohammed',1,1,1,_binary '\0'),(5,'doctor','2023-05-23 15:11:38','doctor','2023-05-23 15:11:38',0,'LANTUS',NULL,'&16','','2023-05-23','Inj.','','1/J','02 Mois','ACTIVE','Mecheret mohammed',1,1,1,_binary '\0'),(6,'doctor','2023-05-23 15:17:14','doctor','2023-05-23 15:17:14',0,'ABUFENE',2,'400 MG','','2023-05-23','Cp.','','1/J','01 Mois','ACTIVE','Mecheret mohammed',1,1,1,_binary '\0'),(25,'doctor','2023-05-30 12:03:23','doctor','2023-05-30 12:03:23',0,'CEFACIDAL',7,'1G','','2023-05-29','Injectable','','1/J','07 J','ACTIVE','Mecheret mohammed',5,6,4,_binary '\0'),(26,'doctor','2023-05-30 12:03:23','doctor','2023-05-30 12:03:23',0,'RAPIDUS',1,'50 mg','','2023-05-29','cp','','1/J','07','ACTIVE','Mecheret mohammed',5,6,4,_binary '\0'),(27,'doctor','2023-06-04 14:32:49','doctor','2023-06-04 14:32:49',0,'ABASAGLAR',2,'100 UI/ ML','','2023-06-04','Inj.','','1/2 /J','','ACTIVE','Mecheret mohammed',2,8,11,_binary '\0'),(28,'doctor','2023-06-04 15:30:00','doctor','2023-06-04 15:30:00',0,'PENICILLINE',8,'1M','','2023-06-04','injectable','','1/J','08 J','ACTIVE','Mecheret mohammed',6,9,12,_binary '\0'),(29,'doctor','2023-06-04 15:32:40','doctor','2023-06-04 15:32:40',0,'SOLUMEDROL',2,'40 mg','','2023-06-04','cp40 mg','','1/2 /J','02 J','ACTIVE','Mecheret mohammed',6,9,12,_binary '\0'),(30,'doctor','2023-06-04 15:34:16','doctor','2023-06-04 15:34:16',0,'ZOPRA',1,'30 mg','','2023-06-04','cp','','1/J','01 Mois','ACTIVE','Mecheret mohammed',6,9,12,_binary '\0'),(31,'doctor','2023-06-04 15:35:50','doctor','2023-06-04 15:35:50',0,'ABUFENE',1,'','','2023-06-04','CP','','1/J','02 J','ACTIVE','Mecheret mohammed',6,9,12,_binary '\0'),(32,'doctor','2023-06-04 15:42:55','doctor','2023-06-04 15:42:55',0,'SPASFON',1,'160 mg','','2023-06-04','cp','','3/J','05 J','ACTIVE','Mecheret mohammed',6,9,12,_binary '\0'),(33,'doctor','2023-06-04 15:53:30','doctor','2023-06-04 15:53:30',0,'ACTICAL',1,'10%','','2023-06-04','Sirop','Flacon(s)','1/2J','01 Mois','ACTIVE','Mecheret mohammed',6,9,12,_binary '\0'),(34,'doctor','2023-06-04 16:01:09','doctor','2023-06-04 16:01:09',0,'ABASAGLAR',1,'100 UI/ ML','','2023-06-04','Inj.','Boîte(s)','1/J','01 Mois','ACTIVE','Mecheret mohammed',7,10,13,_binary '\0'),(35,'doctor','2023-06-04 16:02:46','doctor','2023-06-04 16:02:46',0,'LANZOPRAZOLE',1,'30 mg','','2023-06-04','cp','Boîte(s)','1/J','01 Mois','ACTIVE','Mecheret mohammed',7,10,13,_binary '\0'),(36,'doctor','2023-06-04 16:04:18','doctor','2023-06-04 16:04:18',0,'AMLOR',2,'5 MG','','2023-06-04','Gélules.','Boîte(s)','1/J','02 Mois','ACTIVE','Mecheret mohammed',7,10,13,_binary '\0'),(37,'doctor','2023-06-04 16:05:59','doctor','2023-06-04 16:05:59',0,'ASPIGAL',1,'500 MG','','2023-06-04','Pdre. Inj.','Boîte(s)','1/J','02 J','ACTIVE','Mecheret mohammed',7,10,13,_binary '\0'),(38,'doctor','2023-06-04 16:05:59','doctor','2023-06-04 16:05:59',0,'ASPIGAL',1,'500 MG','','2023-06-04','Pdre. Inj.','Boîte(s)','1/J','02 J','ACTIVE','Mecheret mohammed',7,10,13,_binary '\0'),(39,'doctor','2023-06-05 10:23:00','doctor','2023-06-05 10:23:00',0,'PENIICILLINE',5,'1M','','2023-06-05','ampoule','','1/J','05 J','ACTIVE','Mecheret mohammed',7,11,14,_binary '\0'),(40,'doctor','2023-06-05 10:23:50','doctor','2023-06-05 10:23:50',0,'AMLOR',1,'5 MG','','2023-06-05','Gélules.','Boîte(s)','1/J','01 Mois','ACTIVE','Mecheret mohammed',7,11,14,_binary '\0'),(41,'doctor','2023-06-05 11:08:24','doctor','2023-06-05 11:08:24',0,'SOLUMEDROL',7,'40 MG/ 2 ML','','2023-06-05','Pdre. Inj.','Boîte(s)','1/J','07 J','ACTIVE','Mecheret mohammed',7,11,14,_binary '\0'),(42,'doctor','2023-06-05 11:09:45','doctor','2023-06-05 11:09:45',0,'TANAKAN',1,'40 MG/ ML','','2023-06-05','Sol. Buv.','Flacon(s)','1/J','01 Mois','ACTIVE','Mecheret mohammed',7,11,14,_binary '\0'),(43,'doctor','2023-06-05 11:10:59','doctor','2023-06-05 11:10:59',0,'HISTAGAN',1,'2 MG','','2023-06-05','Cp.','Boîte(s)','1/J','01 Mois','ACTIVE','Mecheret mohammed',7,11,14,_binary '\0'),(44,'doctor','2023-11-27 16:43:24','doctor','2023-11-27 16:43:24',0,'CEFACIDAL',7,'1G','','2023-05-29','Injectable','','1/J','07 J','ACTIVE',NULL,NULL,NULL,8,_binary '\0'),(45,'doctor','2023-11-27 16:43:24','doctor','2023-11-27 16:43:24',0,'RAPIDUS',1,'50 mg','','2023-05-29','cp','','1/J','07','ACTIVE',NULL,NULL,NULL,8,_binary '\0'),(57,'doctor','2023-11-27 16:54:06','doctor','2023-11-27 16:54:06',0,'CEFACIDAL',7,'1G','','2023-05-29','Injectable','','1/J','07 J','ACTIVE',NULL,NULL,NULL,7,_binary '\0'),(58,'doctor','2023-11-27 16:54:06','doctor','2023-11-27 16:54:06',0,'RAPIDUS',1,'50 mg','','2023-05-29','cp','','1/J','07','ACTIVE',NULL,NULL,NULL,7,_binary '\0'),(59,'doctor','2023-11-27 16:54:06','doctor','2023-11-27 16:54:06',0,'PYLERA',1,'140/125/125','',NULL,'GELULE','','4CP3F/','10 JOURS','ACTIVE',NULL,NULL,NULL,7,_binary '\0'),(60,'doctor','2023-11-27 17:27:05','doctor','2023-11-27 17:27:05',0,'CEFACIDAL',7,'1G','','2023-05-29','Injectable','','1/J','07 J','ACTIVE',NULL,NULL,NULL,10,_binary '\0'),(61,'doctor','2023-11-27 17:27:05','doctor','2023-11-27 17:27:05',0,'RAPIDUS',1,'50 mg','','2023-05-29','cp','','1/J','07','ACTIVE',NULL,NULL,NULL,10,_binary '\0');
/*!40000 ALTER TABLE `visit_medicament` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-03 18:24:24
