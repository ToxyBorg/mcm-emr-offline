CREATE DATABASE  IF NOT EXISTS `mahrous` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `mahrous`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: mcm-prod.chwkfp078t9a.eu-west-3.rds.amazonaws.com    Database: mahrous
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `app_user`
--

DROP TABLE IF EXISTS `app_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_by` varchar(255) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `last_modified_date` timestamp NULL DEFAULT NULL,
  `version` int DEFAULT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT '0',
  `photo` mediumtext,
  `role` varchar(255) NOT NULL,
  `theme` varchar(255) NOT NULL DEFAULT 'DEFAULT',
  `language` varchar(255) NOT NULL DEFAULT 'fr',
  `layout` varchar(255) NOT NULL DEFAULT 'SIDE_MENU',
  `welcome_page` varchar(255) NOT NULL DEFAULT 'DASHBOARD',
  `provider` bit(1) NOT NULL DEFAULT b'0',
  `immutable` bit(1) NOT NULL DEFAULT b'0',
  `patient_tabs_config` text,
  `office_id` bigint DEFAULT NULL,
  `points` int DEFAULT '0',
  `lab_id` bigint DEFAULT NULL,
  `accordions_config` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ct_username_unique` (`username`),
  KEY `FK_user_office` (`office_id`),
  CONSTRAINT `FK_user_office` FOREIGN KEY (`office_id`) REFERENCES `office` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_user`
--

LOCK TABLES `app_user` WRITE;
/*!40000 ALTER TABLE `app_user` DISABLE KEYS */;
INSERT INTO `app_user` VALUES (1,'system','2023-06-25 09:23:08','doctor','2024-02-20 13:01:33',6,'FOUAD','SAMY MAHROUS','$2a$10$cet1n0fd8j6QLH21rjmJq.mGkvaQfXXh0uI4wNV2PNpeFlVsgVQGO','doctor','0','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABLCAYAAACGGCK3AAAAAXNSR0IArs4c6QAADN1JREFUeF7tnHlsHPd1xz8zO3uSy+WxWp6iVpZkUVYskYoOO7JkN46jOoAL2EgRpY1dBLYLNLXRpg0Q94+iLYq2aJumiHPWjZsiaFKgtWO7bu0YTdWqga/YcmSLtm4yknjvIXKXe8/sFL/ZneWSIiVKu4Jm61lAEsX9/d68ed/fu9+MNPTJb+uapnF1Hx2QLrtFR0e6wpoSgSvTWulCq7/GyhSsdB+KIiHdvO8buloUQrE/N1oCTkWuAuTyB/5G8/qhuL4NiMVgtgGxAbGYBCzGjq0hNiAWk4DF2LE1xAbEYhKwGDu2htiAWEwCFmPH1hAbEItJwGLs2BpiA2IxCViMHVtDbEAsJgGLsfP/QkN0XTTXdNxODa0oo2pyqU8pNV6Dp2EBESAIcYsWrvjcGp4h3JkimXHxsxMh0nlnuXlcBqVBwGk8QPQSCB3+FJ+7+xjjET8nxoJ8avcZ/unY7Wxtn2BktAm1AHfvGAfJwavDIU5OtCMhW8xAXcpOQwGi62IQQzJ04uEDxzg72cuW/gg+V4JEm58/mnuQA+obbI8f56a1af7m+V1IGjzxmSP88fcH0RFaY20z1jCACBO1LpjgM3ef4PR4G83uPF9N3oeSKtCXjREPtjK1tpf9+WF2Os7wdHwfiWAQz/hFvhz6N178n15iicCVBkxuuAY1ACDCVxRRZI1f3X+at8a6kDeHSI7neS28B90pIxU0Y+AIRUZJZoypokKL13DqoUyEL/me57v/sgVVd9qA1HrkhGbcvmWcjw9NkMq6+cqrexj/2FYktUjR66oI2Ai0TGskHL5eZEfgHAecRzn2YxfDI0Ek2drmSsjK8hoiALlze5R4UyuH1JvJdvhR/d5lI1oDFHTC7ml+P/gSE0fdHPp5HzOzbiQ7yqpVN0r7hZAHt7SxdaiLr806mW8Wpmh52mKtW8/zWMt/8NNnAkTmfOV8xEhK6sPQdaZieQ0R97++z8/de/v5xvkME31rVsz3BCBtaoIH8y/xyst9FIrO6yy++pNvCEA2rAtw1+4+nryQZro/tOJZF4CEnRqfLozy4o8iFDTr5x1LIW0AQHQ2hQPs29nH18fzzPR1LLI+AoRSxg4KRQ72+WgfvsBLPzlLUW8MM1UNSkMAsq7HzyfvCPPN0RRj4ZBhskoOvARCu8vB2mYXu9e42BBP8vy/HmNiJlXyG2W0KkGYxTFqAECgI+Dm4H2beeroDCe3rDNk7EDn1zcHuL+/hWw0ydj5ixz7+QTvH48Qn8uhU6TgUFCdDmS9iDOnIQtUZGvn6g0BiOKA3/n8R/nef45wZNcmhCV6dEsrdyYSfPXpt7mYyOOQZcQ6XZfI6TqxgIdkiwccJXWSVZ2OWJqmdAFJ5CkWDYMbAhAh0MceGuLQ2xd4+eYwOB383f4e/vp3nyOvQV9nM7cNdeH1OFF1nQngcDSL2u4nGGziwmyW2HQSeXqOwMw8gWTOspX5hgBEJIef//RHuDA1x/daOig2uXjqzl6+8sXncDgc/MYDH2EqkuKt4UkKAS99O3q5Z2cfc5JMLK3S7lV48miUidEoyi8idI/P4Shas13SMIA89MBWovF5vuNvR/O4+NJQB7EX3mXk/Bz3H9jID144wcxcjmi7l9xAF//7+G38dGyOz93SxXePTdDhdfPYK+dgdJKuMxG8uaIltaQhABEm6zd/bRvvnI7wbP9aNIfMYIeTP+ty8+fffI0H79/KD1/4gHMzKSJBH4Vb+jj8hV28F0nxwMYQf//eOBvafBx8cQRGp1hzegZ/RrVk8t4QgMiSzhcf3sU/v3mBVwfChiAVdN64fwO//YUfcc++9XQGfTz97DBnJYnkxk4evXeAPd1e2txOopk8Pzw1y+FTcRiZonskhqdQTmDqn2zXRLEhAPE3KTx6cBtffz/OybWdlTzk2/s7OfzUmxw/G+OX94e5Y/da/va5YQ4nVdwbu9g+ECLgkphMawxHMhRHp/GMxwlNp3DUJLbrt7khAFnb3cS9+9fztekCk6HWSunk8a1tqP91gh8f/oXR1h3c3M7jj+zmD58Z5tWpeeRgANp86JqGPj2LksgQjKTx5jQ77K3lTG25qY3bdnTzrdMJJjf1VMKjL29rI/rvw/z3G2MVf7B7W4j77tnIE//wDjFFRhN5CODKF/Ens8a/IgexasLeEBqyrreZT921nn98eYRz60PkOppxZXI8+9kB/vJPf8K5ibQBiAiPm30O/uoPPs4Tf3GI2UyRokMyEkFZK02pCHtnVTAaokFlMOmARw5uY24uzQ9ePoOuKPzKL4V57LODPPDIM6TzpUqVMFtdQR+/9/BO/uTJ10hlSm+nMIuPFk3OFxmPhtAQcfKbPA5+66EhhrZ0ksmpjE8lOX02xtCtXXz/2WGmIhkcisS9d64nlSnwzEsn0exqb7nFt1yDzhTOZe2F+XqPJYt0cfaNgSyafQoORSaZKqAXYdO6AHuGevC6FaNwODaZ4PCbY6SNPKNMp/qtIZW+e3UPfnFDcXkuVuBt0fm+9ne2mGRq1pDSFGcppjfYWcSTEKI5OVhqWuhS2ZYbG0R5vDR7aOwTS8o/GJa+ila5XV6uqC/9AsRLW4QmaZrgZQHQ0oRjFcCXHIgqhKrYXXSmLr2xMrNVfJg3IK5Wg22sCyDhnibC3U3Mzedp8buZiWbFwCDNHpm2gJeCpnJ+cp4mr5NkSqN3jZvEvIrbo/D+qTi7bg1ycT6HmMgVpfaR80nW9wc4dirG9oEO4rN5Ihezxp+9gyEi8SyJdIFwt4+ZWBavV0GWJd49FWdooANZlnEqEu+dijM40I6qQiqdp73VzeiFpHHdrg4fuZzKiZGLdHb5aG1yMz9fILTGw9EP4vibXcxE0+zd0U0qXTA01O12cPxUjL6eFlqaFN75IE54rZ/4bIZoPMftg10cH40xGcldc6GsZkBEFj2wvo2pWIZwbzP9XT5UVaMl4OaVw+fZ+9FevB6J8ekUuVwRHZnR87PsGQyRy2u8fjTKgTt6mEsK0JIkklk+NtTLVCxLe6uT19+ZINDsYfOGVrI5OH4mQqvfzU39zbx3YpadW4O4XApTkXmOnIhz165ORsaS5As686kCIgz2uR2MnJ/F4VTI5lQGbwlyZDhGKq0hoXHzxlbcikw6laej1cuhn02xfaDN0LhN61qZnMkwl8xy8lyS7ZtacHncvD0cJZPJs29nN+Ku3no3wif29nLo9Qkmo5kbB4gwV6F2Dz6X6N3peNwykViGWza3c2Q4Sk/Qh9MpkcmqFNSSeRJRk/ADwtKNT2dZ1+NlKpql1e/C5XSgqbpx6i8mc4YwC2oRj1shl9MMWvm8hiTLyJJk+I6iXiSTLTAVy9Hf7WM2WaCoFckWdPw+hZYmJ+l0AX+Li7lEnuYmFw5ZIplScTkl3C4HqqZR1HSD3rmplOGrWvwuiqqO4pAQr69StaJxiFqa3AZPul5EURy4XTKJRJ5Ai5tzE/PMV/uvq0zAatYQs5cqTEbRnEg3bW5VlFPKARbcguF2qlqx5RTB8CumnxGv8BJCX+R7ymZbfOeQoVgsOSBht4WTX0rT7OIa/sn8q+S6ysmkmIsUfqb0CzFLJ2hXu43qOMDs4Yt14ueKqzdbxTXG2LUDcpUnwF5+eQnYgFjshNiArAYQc8SlhnB2NZepb+lEJG/mxLM5fWMYWGFUF/qlpu0up3qGETbidnO+Siww95UdT6koUvqYJvqy780s+wep7I8qwtBFjrDw1NXCNUv1roqLqUqmxNCE4aNMDgRNk6DBn+mMFuaNjLxH0LgGAOurIeZJWuVxuHzuW+1Kqwmavzc9+MJ3Zdktufqi07GATRleE+wK0JdMAS/DR9XihdTQBMpMfK/tGcf6ArJKIOxlK0vABsRip+O6ALLwhOyNvdtqM3StnNSFxlX4kroDYj4zbjhU0wsvK41KNXGhslhdBKzO4ip0ytW/pWa98v+lgwuLC5QlNspWv6qiaZQflxZFKzybFWMzUjBpVN1U9Y1eku2Wg5ZVnojrBEhVNLQCI8udvOUc64KLrMQ2q7y1hajM3HBtFBZf7soas7CiUli+kRpyVdKyxOJFqrECR5ePB+t5G3XXkKogtGEeI6unQGuldV0AKTn10slbnNAtVvgrq3/Vg7XL3Olq9pvbLl270u7L87i0v7XUDFa7t0UmeJVm67oBIpxntWM3mDNLvGUpXSqSS82HyKD1FW5mVYBUsvaF5mW1b1853ihl2qXEcWlwUCJqFBWqEap6mstM1itFhxsJSK1q+2Hef1005MMs0Frv3QakVgnWeb8NSJ0FWis5G5BaJVjn/TYgdRZoreRsQGqVYJ3324DUWaC1krMBqVWCdd6/GJA6E7fJXb0ExCCgtO0T39ELmpg4sz83WgJOp8z/Ae+xRk9wGggvAAAAAElFTkSuQmCC','DOCTOR','DEFAULT','fr','SIDE_MENU','DASHBOARD',_binary '',_binary '','{\"GENERAL\":true,\"VISITS\":true,\"ORDONNANCES\":true,\"VITAL_SIGNS\":true,\"VISIT_MEDICAMENTS\":true,\"COMPLEMENTARY_EXAMS\":true,\"ALLERGIES\":true,\"CLINICAL_INFORMATIONS\":true,\"PATHOLOGICAL_ANTECEDENTS\":true,\"IMMUNISATIONS\":true,\"DISEASES\":true,\"CERTIFICATES\":true,\"PAYMENTS\":true}',1,0,NULL,'[{\"title\":\"vitalSigns\",\"template\":\"vitalSignsNgTemplate\"},{\"title\":\"allergies\",\"template\":\"allergiesNgTemplate\"},{\"title\":\"pathologicalAntecedents\",\"template\":\"pathologicalAntecedentsNgTemplate\"},{\"title\":\"medicaments\",\"template\":\"medicamentsNgTemplate\"},{\"title\":\"physicalExams\",\"template\":\"physicalExamsNgTemplate\"},{\"title\":\"diseases\",\"template\":\"diseasesNgTemplate\"},{\"title\":\"complementaryExams\",\"template\":\"complementaryExamsNgTemplate\"},{\"title\":\"immunizations\",\"template\":\"immunizationsNgTemplate\"},{\"title\":\"certificates\",\"template\":\"certificatesNgTemplate\"},{\"title\":\"remarks\",\"template\":\"remarksNgTemplate\"}]'),(2,'system','2023-06-25 09:23:08',NULL,NULL,0,'Assistant','Assistant','$2a$10$cet1n0fd8j6QLH21rjmJq.mGkvaQfXXh0uI4wNV2PNpeFlVsgVQGO','assistant','0',NULL,'ASSISTANT','DEFAULT','fr','SIDE_MENU','DIGITAL_ASSISTANT',_binary '\0',_binary '\0','{\"GENERAL\":true,\"VISITS\":true,\"ORDONNANCES\":true,\"VITAL_SIGNS\":true,\"VISIT_MEDICAMENTS\":true,\"COMPLEMENTARY_EXAMS\":true,\"ALLERGIES\":true,\"CLINICAL_INFORMATIONS\":true,\"PATHOLOGICAL_ANTECEDENTS\":true,\"IMMUNISATIONS\":true,\"DISEASES\":true,\"CERTIFICATES\":true,\"PAYMENTS\":true}',1,0,NULL,NULL);
/*!40000 ALTER TABLE `app_user` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-03 17:40:52
