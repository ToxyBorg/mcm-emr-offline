CREATE DATABASE  IF NOT EXISTS `mahrous` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `mahrous`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: mcm-prod.chwkfp078t9a.eu-west-3.rds.amazonaws.com    Database: mahrous
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `prescription`
--

DROP TABLE IF EXISTS `prescription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prescription` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `last_modified_date` timestamp NULL DEFAULT NULL,
  `version` int DEFAULT NULL,
  `active` bit(1) NOT NULL,
  `general_note` varchar(255) DEFAULT NULL,
  `template` bit(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prescription`
--

LOCK TABLES `prescription` WRITE;
/*!40000 ALTER TABLE `prescription` DISABLE KEYS */;
INSERT INTO `prescription` VALUES (1,'OR0167-000001','doctor','2023-06-25 12:26:48','doctor','2023-06-25 12:26:48',1,_binary '',NULL,_binary '\0'),(2,NULL,'doctor','2023-06-25 12:35:39','doctor','2023-06-25 12:35:39',0,_binary '',NULL,_binary ''),(3,'OR0167-000003','doctor','2023-06-26 09:19:09','doctor','2023-06-26 09:19:09',1,_binary '',NULL,_binary '\0'),(4,'OR0167-000004','doctor','2023-06-26 12:44:22','doctor','2023-06-26 12:44:22',1,_binary '',NULL,_binary '\0'),(5,'OR0167-000005','doctor','2023-07-01 08:40:41','doctor','2023-07-01 08:40:41',1,_binary '',NULL,_binary '\0'),(6,'OR0167-000006','doctor','2023-07-01 09:01:12','doctor','2023-07-01 09:01:12',1,_binary '',NULL,_binary '\0'),(7,'OR0167-000007','doctor','2023-07-01 09:39:47','doctor','2023-07-01 09:39:47',1,_binary '',NULL,_binary '\0'),(8,'OR0167-000008','doctor','2023-07-01 10:19:04','doctor','2023-07-01 10:19:04',1,_binary '',NULL,_binary '\0'),(9,'OR0167-000009','doctor','2023-07-01 10:25:59','doctor','2023-07-01 10:25:59',1,_binary '',NULL,_binary '\0'),(10,'OR0167-000010','doctor','2023-07-02 08:50:28','doctor','2023-07-02 08:50:28',1,_binary '',NULL,_binary '\0'),(11,'OR0167-000011','doctor','2023-07-02 12:12:39','doctor','2023-07-02 12:12:39',1,_binary '',NULL,_binary '\0'),(12,'OR0167-000012','doctor','2023-07-03 09:56:42','doctor','2023-07-03 09:56:42',1,_binary '',NULL,_binary '\0'),(13,'OR0167-000013','doctor','2023-07-03 11:42:30','doctor','2023-07-03 11:42:30',1,_binary '',NULL,_binary '\0'),(14,'OR0167-000014','doctor','2023-07-04 10:20:21','doctor','2023-07-04 10:20:21',1,_binary '',NULL,_binary '\0'),(15,'OR0167-000015','doctor','2023-07-04 12:08:47','doctor','2023-07-04 12:08:47',1,_binary '',NULL,_binary '\0'),(16,'OR0167-000016','doctor','2023-07-04 12:12:59','doctor','2023-07-04 12:12:59',1,_binary '',NULL,_binary '\0'),(17,'OR0167-000017','doctor','2023-07-04 12:35:47','doctor','2023-07-04 12:35:48',1,_binary '',NULL,_binary '\0'),(18,'OR0167-000018','doctor','2023-07-04 13:14:27','doctor','2023-07-04 13:14:27',1,_binary '',NULL,_binary '\0'),(19,'OR0167-000019','doctor','2023-07-04 14:09:26','doctor','2023-07-04 14:09:26',1,_binary '',NULL,_binary '\0'),(20,'OR0167-000020','doctor','2023-07-05 09:27:52','doctor','2023-07-05 09:27:52',1,_binary '',NULL,_binary '\0'),(21,'OR0167-000021','doctor','2023-07-05 11:12:59','doctor','2023-07-05 11:12:59',1,_binary '',NULL,_binary '\0'),(22,'OR0167-000022','doctor','2023-07-06 10:37:34','doctor','2023-07-06 10:37:34',1,_binary '',NULL,_binary '\0'),(23,'OR0167-000023','doctor','2023-07-06 10:38:01','doctor','2023-07-06 10:38:01',1,_binary '',NULL,_binary '\0'),(24,'OR0167-000024','doctor','2023-07-06 11:07:25','doctor','2023-07-06 11:07:25',1,_binary '',NULL,_binary '\0'),(25,'OR0167-000025','doctor','2023-07-08 08:48:41','doctor','2023-07-08 08:48:41',1,_binary '',NULL,_binary '\0'),(26,'OR0167-000026','doctor','2023-07-08 09:47:34','doctor','2023-07-08 09:47:34',1,_binary '',NULL,_binary '\0'),(27,'OR0167-000027','doctor','2023-07-08 10:17:27','doctor','2023-07-08 10:17:27',1,_binary '',NULL,_binary '\0'),(28,'OR0167-000028','doctor','2023-07-08 10:56:31','doctor','2023-07-08 10:56:31',1,_binary '',NULL,_binary '\0'),(29,'OR0167-000029','doctor','2023-07-08 11:14:58','doctor','2023-07-08 11:14:58',1,_binary '',NULL,_binary '\0'),(30,'OR0167-000030','doctor','2023-07-08 12:35:10','doctor','2023-07-08 12:35:10',1,_binary '',NULL,_binary '\0'),(31,'OR0167-000031','doctor','2023-07-08 12:35:58','doctor','2023-07-08 12:35:58',1,_binary '',NULL,_binary '\0'),(32,'OR0167-000032','doctor','2023-07-08 13:36:51','doctor','2023-07-08 13:36:51',1,_binary '',NULL,_binary '\0'),(33,'OR0167-000033','doctor','2023-07-09 08:59:13','doctor','2023-07-09 08:59:13',1,_binary '',NULL,_binary '\0'),(34,'OR0167-000034','doctor','2023-07-09 10:45:18','doctor','2023-07-09 10:45:18',1,_binary '',NULL,_binary '\0'),(35,'OR0167-000035','doctor','2023-07-09 13:17:40','doctor','2023-07-09 13:17:40',1,_binary '',NULL,_binary '\0'),(36,'OR0167-000036','doctor','2023-07-10 09:14:44','doctor','2023-07-10 09:14:44',1,_binary '',NULL,_binary '\0'),(37,'OR0167-000037','doctor','2023-07-11 10:33:31','doctor','2023-07-11 10:33:31',1,_binary '',NULL,_binary '\0'),(38,'OR0167-000038','doctor','2023-07-11 12:52:15','doctor','2023-07-11 12:52:15',1,_binary '',NULL,_binary '\0'),(39,'OR0167-000039','doctor','2023-07-11 14:00:52','doctor','2023-07-11 14:00:52',1,_binary '',NULL,_binary '\0'),(40,'OR0167-000040','doctor','2023-07-12 08:36:35','doctor','2023-07-12 08:36:35',1,_binary '',NULL,_binary '\0'),(41,'OR0167-000041','doctor','2023-07-12 12:51:34','doctor','2023-07-12 12:51:34',1,_binary '',NULL,_binary '\0'),(42,'OR0167-000042','doctor','2023-07-12 12:52:29','doctor','2023-07-12 12:52:29',1,_binary '',NULL,_binary '\0'),(43,'OR0167-000043','doctor','2023-07-12 12:53:34','doctor','2023-07-12 12:53:34',1,_binary '',NULL,_binary '\0'),(44,'OR0167-000044','doctor','2023-07-12 12:54:40','doctor','2023-07-12 12:54:40',1,_binary '',NULL,_binary '\0'),(45,'OR0167-000045','doctor','2023-07-12 12:55:31','doctor','2023-07-12 12:55:31',1,_binary '',NULL,_binary '\0'),(46,'OR0167-000046','doctor','2023-07-12 13:15:18','doctor','2023-07-12 13:15:18',1,_binary '',NULL,_binary '\0'),(47,'OR0167-000047','doctor','2023-07-17 11:09:20','doctor','2023-07-17 11:09:20',1,_binary '',NULL,_binary '\0'),(48,'OR0167-000048','doctor','2023-07-18 09:06:19','doctor','2023-07-18 09:06:19',1,_binary '',NULL,_binary '\0'),(49,'OR0167-000049','doctor','2023-07-18 10:14:08','doctor','2023-07-18 10:14:08',1,_binary '',NULL,_binary '\0'),(50,'OR0167-000050','doctor','2023-07-18 10:15:13','doctor','2023-07-18 10:15:13',1,_binary '',NULL,_binary '\0'),(51,'OR0167-000051','doctor','2023-07-18 12:00:50','doctor','2023-07-18 12:00:50',1,_binary '',NULL,_binary '\0'),(52,'OR0167-000052','doctor','2023-07-18 12:01:38','doctor','2023-07-18 12:01:38',1,_binary '',NULL,_binary '\0'),(53,'OR0167-000053','doctor','2023-07-18 12:02:24','doctor','2023-07-18 12:02:24',1,_binary '',NULL,_binary '\0'),(54,'OR0167-000054','doctor','2023-07-22 12:12:53','doctor','2023-07-22 12:12:53',1,_binary '',NULL,_binary '\0'),(55,'OR0167-000055','doctor','2023-07-24 08:38:00','doctor','2023-07-24 08:38:00',1,_binary '',NULL,_binary '\0'),(56,'OR0167-000056','doctor','2023-07-24 09:20:58','doctor','2023-07-24 09:20:58',1,_binary '',NULL,_binary '\0'),(57,'OR0167-000057','doctor','2023-07-24 10:11:32','doctor','2023-07-24 10:11:32',1,_binary '',NULL,_binary '\0'),(58,'OR0167-000058','doctor','2023-08-15 09:55:21','doctor','2023-08-15 09:55:21',1,_binary '',NULL,_binary '\0'),(59,'OR0167-000059','doctor','2023-08-15 13:18:32','doctor','2023-08-15 13:18:32',1,_binary '',NULL,_binary '\0'),(60,'OR0167-000060','doctor','2023-08-17 07:35:17','doctor','2023-08-17 07:35:17',1,_binary '',NULL,_binary '\0'),(61,'OR0167-000061','doctor','2023-08-19 08:20:30','doctor','2023-08-19 08:20:30',1,_binary '',NULL,_binary '\0'),(62,'OR0167-000062','doctor','2023-08-19 08:58:14','doctor','2023-08-19 08:58:14',1,_binary '',NULL,_binary '\0'),(63,'OR0167-000063','doctor','2023-08-19 10:23:29','doctor','2023-08-19 10:23:29',1,_binary '',NULL,_binary '\0'),(64,'OR0167-000064','doctor','2023-08-19 14:03:24','doctor','2023-08-19 14:03:24',1,_binary '',NULL,_binary '\0'),(65,'OR0167-000065','doctor','2023-08-20 08:36:19','doctor','2023-08-20 08:36:19',1,_binary '',NULL,_binary '\0'),(66,'OR0167-000066','doctor','2023-08-20 12:53:46','doctor','2023-08-20 12:53:46',1,_binary '',NULL,_binary '\0'),(67,'OR0167-000067','doctor','2023-08-20 12:57:07','doctor','2023-08-20 12:57:07',1,_binary '',NULL,_binary '\0'),(68,'OR0167-000068','doctor','2023-08-21 09:04:54','doctor','2023-08-21 09:04:54',1,_binary '',NULL,_binary '\0'),(69,'OR0167-000069','doctor','2023-08-21 10:47:04','doctor','2023-08-21 10:47:04',1,_binary '',NULL,_binary '\0'),(70,'OR0167-000070','doctor','2023-08-22 11:18:27','doctor','2023-08-22 11:18:27',1,_binary '',NULL,_binary '\0'),(71,'OR0167-000071','doctor','2023-08-22 11:21:55','doctor','2023-08-22 11:21:55',1,_binary '',NULL,_binary '\0'),(72,'OR0167-000072','doctor','2023-08-26 08:25:18','doctor','2023-08-26 08:25:18',1,_binary '',NULL,_binary '\0'),(73,'OR0167-000073','doctor','2023-08-26 09:44:59','doctor','2023-08-26 09:44:59',1,_binary '',NULL,_binary '\0'),(74,'OR0167-000074','doctor','2023-08-27 09:11:00','doctor','2023-08-27 09:11:00',1,_binary '',NULL,_binary '\0'),(75,'OR0167-000075','doctor','2023-09-11 08:07:46','doctor','2023-09-11 08:07:46',1,_binary '',NULL,_binary '\0'),(76,'OR0167-000076','doctor','2023-11-28 07:55:21','doctor','2023-11-28 07:55:21',1,_binary '',NULL,_binary '\0');
/*!40000 ALTER TABLE `prescription` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-03 17:41:19
