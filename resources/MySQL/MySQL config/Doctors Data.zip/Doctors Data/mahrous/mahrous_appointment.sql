CREATE DATABASE  IF NOT EXISTS `mahrous` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `mahrous`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: mcm-prod.chwkfp078t9a.eu-west-3.rds.amazonaws.com    Database: mahrous
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `appointment`
--

DROP TABLE IF EXISTS `appointment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `appointment` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_by` varchar(255) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `last_modified_date` timestamp NULL DEFAULT NULL,
  `version` int DEFAULT NULL,
  `cancelation_reason` varchar(255) DEFAULT NULL,
  `appointment_date` datetime DEFAULT NULL,
  `appointment_period` varchar(255) NOT NULL,
  `note` text,
  `status` int DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `type_id` bigint DEFAULT NULL,
  `patient_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_appointment_patient` (`patient_id`),
  KEY `FK_appointment_type` (`type_id`),
  KEY `FK_appointment_user` (`user_id`),
  CONSTRAINT `FK_appointment_patient` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`id`),
  CONSTRAINT `FK_appointment_type` FOREIGN KEY (`type_id`) REFERENCES `appointment_type` (`id`),
  CONSTRAINT `FK_appointment_user` FOREIGN KEY (`user_id`) REFERENCES `app_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointment`
--

LOCK TABLES `appointment` WRITE;
/*!40000 ALTER TABLE `appointment` DISABLE KEYS */;
INSERT INTO `appointment` VALUES (1,'doctor','2023-06-25 12:26:48','doctor','2023-06-25 12:26:48',1,NULL,'2023-06-25 12:26:48','13:26','',3,NULL,1,1,1),(2,'doctor','2023-06-26 09:19:09','doctor','2023-06-26 09:19:09',1,NULL,'2023-06-26 09:19:09','10:19','',3,NULL,1,3,1),(3,'doctor','2023-06-26 12:44:22','doctor','2023-06-26 12:44:22',1,NULL,'2023-06-26 12:44:22','13:44','',3,NULL,1,5,1),(4,'doctor','2023-07-01 08:40:41','doctor','2023-07-01 08:40:41',1,NULL,'2023-07-01 08:40:41','9:40','',3,NULL,1,8,1),(5,'doctor','2023-07-01 09:01:12','doctor','2023-07-01 09:01:12',1,NULL,'2023-07-01 09:01:12','10:1','',3,NULL,1,9,1),(6,'doctor','2023-07-01 09:39:47','doctor','2023-07-01 09:39:47',1,NULL,'2023-07-01 09:39:47','10:39','',3,NULL,1,11,1),(7,'doctor','2023-07-01 10:19:04','doctor','2023-07-01 10:19:04',1,NULL,'2023-07-01 10:19:04','11:19','',3,NULL,1,10,1),(8,'doctor','2023-07-01 10:25:59','doctor','2023-07-01 10:25:59',1,NULL,'2023-07-01 10:25:59','11:26','',3,NULL,1,13,1),(9,'doctor','2023-07-02 08:50:28','doctor','2023-07-02 08:50:28',1,NULL,'2023-07-02 08:50:28','9:50','',3,NULL,1,17,1),(10,'doctor','2023-07-02 12:12:39','doctor','2023-07-02 12:12:39',1,NULL,'2023-07-02 12:12:39','13:12','',3,NULL,1,22,1),(11,'doctor','2023-07-03 09:56:42','doctor','2023-07-03 09:56:42',1,NULL,'2023-07-03 09:56:42','10:56','',3,NULL,1,29,1),(12,'doctor','2023-07-03 11:42:30','doctor','2023-07-03 11:42:30',1,NULL,'2023-07-03 11:42:30','12:42','',3,NULL,1,35,1),(13,'doctor','2023-07-04 10:20:21','doctor','2023-07-04 10:20:21',1,NULL,'2023-07-04 10:20:21','11:20','',3,NULL,1,40,1),(14,'doctor','2023-07-04 12:08:47','doctor','2023-07-04 12:08:47',1,NULL,'2023-07-04 12:08:47','13:8','',3,NULL,1,42,1),(15,'doctor','2023-07-04 12:12:59','doctor','2023-07-04 12:12:59',1,NULL,'2023-07-04 12:12:59','13:12','',3,NULL,1,43,1),(16,'doctor','2023-07-04 12:35:47','doctor','2023-07-04 12:35:48',1,NULL,'2023-07-04 12:35:47','13:35','',3,NULL,1,44,1),(17,'doctor','2023-07-04 13:14:27','doctor','2023-07-04 13:14:27',1,NULL,'2023-07-04 13:14:27','14:14','',3,NULL,1,45,1),(18,'doctor','2023-07-04 14:09:26','doctor','2023-07-04 14:09:26',1,NULL,'2023-07-04 14:09:26','15:9','',3,NULL,1,46,1),(19,'doctor','2023-07-05 09:27:52','doctor','2023-07-05 09:27:52',1,NULL,'2023-07-05 09:27:52','10:27','',3,NULL,1,50,1),(20,'doctor','2023-07-05 11:12:59','doctor','2023-07-05 11:12:59',1,NULL,'2023-07-05 11:12:59','12:12','',3,NULL,1,52,1),(21,'doctor','2023-07-06 10:37:34','doctor','2023-07-06 10:37:34',1,NULL,'2023-07-06 10:37:34','11:37','',3,NULL,1,54,1),(22,'doctor','2023-07-06 10:38:01','doctor','2023-07-06 10:38:01',1,NULL,'2023-07-06 10:38:01','11:38','',3,NULL,1,55,1),(23,'doctor','2023-07-06 11:07:25','doctor','2023-07-06 11:07:25',1,NULL,'2023-07-06 11:07:25','12:7','',3,NULL,1,57,1),(24,'doctor','2023-07-08 08:48:41','doctor','2023-07-08 08:48:41',1,NULL,'2023-07-08 08:48:41','9:48','',3,NULL,1,60,1),(25,'doctor','2023-07-08 09:47:34','doctor','2023-07-08 09:47:34',1,NULL,'2023-07-08 09:47:34','10:47','',3,NULL,1,61,1),(26,'doctor','2023-07-08 10:17:27','doctor','2023-07-08 10:17:27',1,NULL,'2023-07-08 10:17:27','11:17','',3,NULL,1,62,1),(27,'doctor','2023-07-08 10:56:31','doctor','2023-07-08 10:56:31',1,NULL,'2023-07-08 10:56:31','11:56','',3,NULL,1,64,1),(28,'doctor','2023-07-08 11:14:58','doctor','2023-07-08 11:14:58',1,NULL,'2023-07-08 11:14:58','12:15','',3,NULL,1,65,1),(29,'doctor','2023-07-08 12:35:10','doctor','2023-07-08 12:35:10',1,NULL,'2023-07-08 12:35:10','13:35','',3,NULL,1,68,1),(30,'doctor','2023-07-08 12:35:58','doctor','2023-07-08 12:35:58',1,NULL,'2023-07-08 12:35:58','13:36','',3,NULL,1,67,1),(31,'doctor','2023-07-08 13:36:51','doctor','2023-07-08 13:36:51',1,NULL,'2023-07-08 13:36:51','14:36','',3,NULL,1,70,1),(32,'doctor','2023-07-09 08:59:13','doctor','2023-07-09 08:59:13',1,NULL,'2023-07-09 08:59:13','9:59','',3,NULL,1,73,1),(33,'doctor','2023-07-09 10:45:18','doctor','2023-07-09 10:45:18',1,NULL,'2023-07-09 10:45:18','11:45','',3,NULL,1,76,1),(34,'doctor','2023-07-09 13:17:40','doctor','2023-07-09 13:17:40',1,NULL,'2023-07-09 13:17:40','14:17','',3,NULL,1,80,1),(35,'doctor','2023-07-10 09:14:43','doctor','2023-07-10 09:14:44',1,NULL,'2023-07-10 09:14:43','10:14','',3,NULL,1,81,1),(36,'doctor','2023-07-11 10:33:31','doctor','2023-07-11 10:33:31',1,NULL,'2023-07-11 10:33:31','11:33','',3,NULL,1,87,1),(37,'doctor','2023-07-11 12:52:15','doctor','2023-07-11 12:52:15',1,NULL,'2023-07-11 12:52:15','13:52','',3,NULL,1,88,1),(38,'doctor','2023-07-11 14:00:52','doctor','2023-07-11 14:00:52',1,NULL,'2023-07-11 14:00:52','15:0','',3,NULL,1,89,1),(39,'doctor','2023-07-12 08:36:35','doctor','2023-07-12 08:36:35',1,NULL,'2023-07-12 08:36:35','9:36','',3,NULL,1,91,1),(40,'doctor','2023-07-12 12:51:34','doctor','2023-07-12 12:51:34',1,NULL,'2023-07-12 12:51:34','13:51','',3,NULL,1,94,1),(41,'doctor','2023-07-12 12:52:29','doctor','2023-07-12 12:52:29',1,NULL,'2023-07-12 12:52:29','13:52','',3,NULL,1,93,1),(42,'doctor','2023-07-12 12:53:34','doctor','2023-07-12 12:53:34',1,NULL,'2023-07-12 12:53:34','13:53','',3,NULL,1,92,1),(43,'doctor','2023-07-12 12:54:40','doctor','2023-07-12 12:54:40',1,NULL,'2023-07-12 12:54:40','13:54','',3,NULL,1,90,1),(44,'doctor','2023-07-12 12:55:31','doctor','2023-07-12 12:55:31',1,NULL,'2023-07-12 12:55:31','13:55','',3,NULL,1,86,1),(45,'doctor','2023-07-12 13:15:18','doctor','2023-07-12 13:15:18',1,NULL,'2023-07-12 13:15:18','14:15','',3,NULL,1,95,1),(46,'doctor','2023-07-17 11:09:20','doctor','2023-07-17 11:09:20',1,NULL,'2023-07-17 11:09:20','12:9','',3,NULL,1,114,1),(47,'doctor','2023-07-18 09:06:19','doctor','2023-07-18 09:06:19',1,NULL,'2023-07-18 09:06:19','10:6','',3,NULL,1,116,1),(48,'doctor','2023-07-18 10:14:08','doctor','2023-07-18 10:14:08',1,NULL,'2023-07-18 10:14:08','11:14','',3,NULL,1,118,1),(49,'doctor','2023-07-18 10:15:13','doctor','2023-07-18 10:15:13',1,NULL,'2023-07-18 10:15:13','11:15','',3,NULL,1,119,1),(50,'doctor','2023-07-18 12:00:50','doctor','2023-07-18 12:00:50',1,NULL,'2023-07-18 12:00:50','13:0','',3,NULL,1,122,1),(51,'doctor','2023-07-18 12:01:38','doctor','2023-07-18 12:01:38',1,NULL,'2023-07-18 12:01:38','13:1','',3,NULL,1,120,1),(52,'doctor','2023-07-18 12:02:24','doctor','2023-07-18 12:02:24',1,NULL,'2023-07-18 12:02:24','13:2','',3,NULL,1,117,1),(53,'doctor','2023-07-22 12:12:53','doctor','2023-07-22 12:12:53',1,NULL,'2023-07-22 12:12:53','13:12','',3,NULL,1,131,1),(54,'doctor','2023-07-24 08:38:00','doctor','2023-07-24 08:38:00',1,NULL,'2023-07-24 08:38:00','9:38','',3,NULL,1,140,1),(55,'doctor','2023-07-24 09:20:58','doctor','2023-07-24 09:20:58',1,NULL,'2023-07-24 09:20:58','10:20','',3,NULL,1,142,1),(56,'doctor','2023-07-24 10:11:32','doctor','2023-07-24 10:11:32',1,NULL,'2023-07-24 10:11:32','11:11','',3,NULL,1,141,1),(57,'doctor','2023-08-15 09:55:21','doctor','2023-08-15 09:55:21',1,NULL,'2023-08-15 09:55:21','10:55','',3,NULL,1,151,1),(58,'doctor','2023-08-15 13:18:32','doctor','2023-08-15 13:18:32',1,NULL,'2023-08-15 13:18:32','14:18','',3,NULL,1,154,1),(59,'doctor','2023-08-17 07:35:17','doctor','2023-08-17 07:35:17',1,NULL,'2023-08-17 07:35:17','8:35','',3,NULL,1,169,1),(60,'doctor','2023-08-19 08:20:30','doctor','2023-08-19 08:20:30',1,NULL,'2023-08-19 08:20:30','9:20','',3,NULL,1,175,1),(61,'doctor','2023-08-19 08:58:14','doctor','2023-08-19 08:58:14',1,NULL,'2023-08-19 08:58:14','9:58','',3,NULL,1,176,1),(62,'doctor','2023-08-19 10:23:29','doctor','2023-08-19 10:23:29',1,NULL,'2023-08-19 10:23:29','11:23','',3,NULL,1,178,1),(63,'doctor','2023-08-19 14:03:24','doctor','2023-08-19 14:03:24',1,NULL,'2023-08-19 14:03:24','15:3','',3,NULL,1,183,1),(64,'doctor','2023-08-20 08:36:18','doctor','2023-08-20 08:36:19',1,NULL,'2023-08-20 08:36:18','9:36','',3,NULL,1,184,1),(65,'doctor','2023-08-20 12:53:46','doctor','2023-08-20 12:53:46',1,NULL,'2023-08-20 12:53:46','13:53','',3,NULL,1,188,1),(66,'doctor','2023-08-20 12:57:07','doctor','2023-08-20 12:57:07',1,NULL,'2023-08-20 12:57:07','13:57','',3,NULL,1,189,1),(67,'doctor','2023-08-21 09:04:54','doctor','2023-08-21 09:04:54',1,NULL,'2023-08-21 09:04:54','10:4','',3,NULL,1,190,1),(68,'doctor','2023-08-21 10:47:04','doctor','2023-08-21 10:47:04',1,NULL,'2023-08-21 10:47:04','11:47','',3,NULL,1,193,1),(69,'doctor','2023-08-22 11:18:27','doctor','2023-08-22 11:18:27',1,NULL,'2023-08-22 11:18:27','12:18','',3,NULL,1,205,1),(70,'doctor','2023-08-22 11:21:55','doctor','2023-08-22 11:21:55',1,NULL,'2023-08-22 11:21:55','12:21','',3,NULL,1,207,1),(71,'doctor','2023-08-26 08:25:18','doctor','2023-08-26 08:25:18',1,NULL,'2023-08-26 08:25:18','9:25','',3,NULL,1,220,1),(72,'doctor','2023-08-26 09:44:59','doctor','2023-08-26 09:44:59',1,NULL,'2023-08-26 09:44:59','10:45','',3,NULL,1,221,1),(73,'doctor','2023-08-27 09:11:00','doctor','2023-08-27 09:11:00',1,NULL,'2023-08-27 09:11:00','10:11','',3,NULL,1,229,1),(74,'doctor','2023-09-11 08:07:46','doctor','2023-09-11 08:07:46',1,NULL,'2023-09-11 08:07:46','9:7','',3,NULL,1,293,1),(75,'doctor','2023-11-28 07:55:21','doctor','2023-11-28 07:55:21',1,NULL,'2023-11-28 07:55:21','8:55','',3,NULL,1,509,1);
/*!40000 ALTER TABLE `appointment` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-03 17:37:41
