CREATE DATABASE  IF NOT EXISTS `mahrous` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `mahrous`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: mcm-prod.chwkfp078t9a.eu-west-3.rds.amazonaws.com    Database: mahrous
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `certificate_template`
--

DROP TABLE IF EXISTS `certificate_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `certificate_template` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_by` varchar(255) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `last_modified_date` timestamp NULL DEFAULT NULL,
  `version` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `content` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `crt_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `certificate_template`
--

LOCK TABLES `certificate_template` WRITE;
/*!40000 ALTER TABLE `certificate_template` DISABLE KEYS */;
INSERT INTO `certificate_template` VALUES (6,'system','2023-06-25 09:23:12',NULL,NULL,0,'CERTIFICAT MEDICAL D\'INAPTITUDE SPORTIVE','\n            <p class=\"MsoNormal\" align=\"center\" style=\"text-align:center\">\n                <b>\n                    <span style=\"line-height: 107%;\">\n                        <font size=\"4\">\n                            <br>\n                        </font>\n                    </span>\n                </b>\n            </p>\n            <p class=\"MsoNormal\" style=\"text-align: justify;\">\n                <span style=\"line-height: 107%;\"><font size=\"2\">&nbsp; &nbsp; &nbsp;&nbsp;Je soussigné, Dr ______ ,\n                    certifie avoir examiné&nbsp;</font>______&nbsp;<font size=\"2\">&nbsp;âgé de&nbsp;</font>______&nbsp;&nbsp;<font\n                        size=\"2\">, en date du&nbsp;</font>______&nbsp;<font size=\"2\">&nbsp;et déclare que son état de\n                    santé est incompatible avec la pratique d\'une activité physique.\n                </font>\n                </span>\n            </p>\n            <p class=\"MsoNormal\" style=\"text-align: justify;\">\n                <span style=\"line-height: 107%;\">\n                    <font size=\"2\">Ce certificat est remis en mains propres de l\'intéressé pour servir et faire valoir\n                        ce que de droit.\n                    </font>\n                </span>\n            </p>\n            <p class=\"MsoNormal\">\n                <span style=\"background-color: transparent; font-size: 16pt; text-align: center;\">&nbsp;&nbsp;</span>\n            </p>'),(7,'system','2023-06-25 09:23:12',NULL,NULL,0,'CERTIFICAT D’ARRET DE TRAVAIL','\n            <p class=\"MsoNormal\" align=\"center\" style=\"text-align:center\">\n                <span style=\"background-color: transparent;\">\n                    <b>\n                        <br>\n                    </b>\n                </span>\n            </p>\n            <p class=\"MsoNormal\" style=\"text-align: justify;\">\n                <span style=\"line-height: 107%;\"><font size=\"2\">&nbsp; &nbsp; &nbsp;&nbsp;Je soussigné, Dr ______ ,\n                    certifie avoir examiné&nbsp;</font>______&nbsp;<font size=\"2\">&nbsp;âgé de&nbsp;</font>______&nbsp;&nbsp;<font\n                        size=\"2\">, en date du&nbsp;</font>______&nbsp;<font size=\"2\">&nbsp;et déclare que&nbsp;</font>son état\n                    de santé nécessite un arrêt de travail de ______\n                    <font size=\"2\">.</font>\n                </span>\n            </p>\n            <p class=\"MsoNormal\" style=\"text-align: justify;\">\n                <span style=\"line-height: 107%;\">\n                    <font size=\"2\">Ce certificat est remis en mains propres de l\'intéressé pour servir et faire valoir\n                        ce que de droit.\n                    </font>\n                </span>\n            </p>\n            <p class=\"MsoNormal\">\n                <span style=\"background-color: transparent; font-size: 16pt; text-align: center;\">&nbsp;&nbsp;</span>\n            </p>\n            '),(8,'system','2023-06-25 09:23:12',NULL,NULL,0,'CERTIFICAT MEDICAL DE PNEUMO-PHTISIOLOGIE','\n            <p class=\"MsoNormal\" align=\"center\" style=\"text-align:center\">\n                <b>\n                    <br>\n                </b>\n            </p>\n            <p class=\"MsoNormal\" style=\"text-align: justify;\">\n                <span style=\"line-height: 107%;\"><font size=\"2\">&nbsp; &nbsp; &nbsp;&nbsp;Je soussigné, Dr ______ ,\n                    certifie avoir examiné&nbsp;</font>______&nbsp;<font size=\"2\">&nbsp;âgé de&nbsp;</font>______&nbsp;&nbsp;<font\n                        size=\"2\">, en date du&nbsp;</font>______&nbsp;<font size=\"2\">&nbsp;et déclare&nbsp;</font>qu’il\n                    est indemne de toutes maladies tuberculeuses évolutives\n                    <font size=\"2\">.</font>\n                </span>\n            </p>\n            <p class=\"MsoNormal\" style=\"text-align: justify;\">\n                <span style=\"line-height: 107%;\">\n                    <font size=\"2\">Ce certificat est remis en mains propres de l\'intéressé pour servir et faire valoir\n                        ce que de droit.\n                    </font>\n                </span>\n            </p>\n            <p class=\"MsoNormal\">\n                <span style=\"background-color: transparent; font-size: 16pt; text-align: center;\">&nbsp;&nbsp;</span>\n            </p>\n            '),(9,'system','2023-06-25 09:23:12',NULL,NULL,0,'CERTIFICAT MEDICAL D’APTITUDE SPORTIVE','\n            <p class=\"MsoNormal\" align=\"center\" style=\"text-align:center\">\n                <b>\n                    <br>\n                </b>\n            </p>\n            <p class=\"MsoNormal\" style=\"text-align: justify;\">\n                <span style=\"line-height: 107%;\"><font size=\"2\">&nbsp; &nbsp; &nbsp;&nbsp;Je soussigné, Dr ______ ,\n                    certifie avoir examiné&nbsp;</font>______&nbsp;<font size=\"2\">&nbsp;âgé de&nbsp;</font>______&nbsp;&nbsp;<font\n                        size=\"2\">, en date du&nbsp;</font>______&nbsp;<font size=\"2\">&nbsp;et déclare&nbsp;</font>au\n                    terme de l’examen clinique que son état de santé est compatible avec la pratique d’une\n                    activité physique\n                    <font size=\"2\">.</font>\n                </span>\n            </p>\n            <p class=\"MsoNormal\" style=\"text-align: justify;\">\n                <span style=\"line-height: 107%;\">\n                    <font size=\"2\">Ce certificat est remis en mains propres de l\'intéressé pour servir et faire valoir\n                        ce que de droit.\n                    </font>\n                </span>\n            </p>\n            <p class=\"MsoNormal\">\n                <span style=\"background-color: transparent; font-size: 16pt; text-align: center;\">&nbsp;&nbsp;</span>\n            </p>\n            '),(10,'system','2023-06-25 09:23:12',NULL,NULL,0,'CERTIFICAT MEDICAL DESCRIPTIF INITIAL','\n            <p class=\"MsoNormal\" align=\"center\" style=\"text-align:center\">\n                <b>\n                    <br>\n                </b>\n            </p>\n            <p class=\"MsoNormal\" style=\"text-align: justify;\">\n                <span style=\"line-height: 107%;\"><font size=\"2\">&nbsp; &nbsp; &nbsp;&nbsp;Je soussigné, Dr ______ ,\n                    certifie avoir examiné&nbsp;</font>______&nbsp;<font size=\"2\">&nbsp;âgé de&nbsp;</font>______&nbsp;&nbsp;<font\n                        size=\"2\">, en date du&nbsp;</font>______&nbsp;<font size=\"2\">&nbsp;qui déclare&nbsp;</font>\n                </span>\n                <span style=\"background-color: transparent;\">avoir été victime de ________________, et déclare au terme\n                    de l’examen médical les constatations suivantes:\n                </span>\n            </p>\n            <blockquote style=\"margin: 0 0 0 40px; border: none; padding: 0px;\">\n                <p class=\"MsoNormal\" style=\"text-align: justify;\">\n                    <span style=\"background-color: transparent;\">Le patient rapporte une notion de _________</span>\n                </p>\n                <p class=\"MsoNormal\" style=\"text-align: justify;\">\n                    <span style=\"background-color: transparent;\">À l\'examen clinique\n                        on constate :&nbsp;\n                    </span>\n                </p>\n            </blockquote>\n            <span style=\"background-color: transparent; text-align: justify;\">\n                ______________________________________________________\n            </span>\n            <br>\n            <blockquote style=\"margin: 0 0 0 40px; border: none; padding: 0px;\">\n                <p class=\"MsoNormal\" style=\"text-align: justify;\">\n                    <span style=\"background-color: transparent;\">Une _______________ faite le __________ montre:&nbsp;\n                    </span>\n                </p>\n            </blockquote>\n            <span style=\"background-color: transparent; text-align: justify;\">\n                ______________________________________________________\n            </span>\n            <blockquote style=\"margin: 0 0 0 40px; border: none; padding: 0px;\">\n                <div>\n                    <div style=\"text-align: justify;\">Ces lésions ont nécessité _________________\n                        <br>\n                    </div>\n                </div>\n            </blockquote>\n            <span style=\"text-align: justify; background-color: transparent;\">L’état de santé de l’intéressé justifie\n                une incapacité temporaire totale de ___________\n            </span>\n            <span style=\"text-align: justify; background-color: transparent;\">Il est nécessaire d’évaluer une IPP après\n                consolidation par voie d’expertise.\n            </span>\n            <br>\n            <div>\n                <p class=\"MsoNormal\" style=\"text-align: justify;\">\n                    <span style=\"line-height: 107%;\">\n                        <font size=\"2\">Ce certificat est remis en mains propres de l\'intéressé pour servir et faire\n                            valoir ce que de droit.\n                        </font>\n                    </span>\n                </p>\n                <p class=\"MsoNormal\">\n                    <span style=\"background-color: transparent; font-size: 16pt; text-align: center;\">&nbsp;&nbsp;\n                    </span>\n                </p>\n            </div>\n            ');
/*!40000 ALTER TABLE `certificate_template` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-03 17:36:32
