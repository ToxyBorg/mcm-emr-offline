CREATE DATABASE  IF NOT EXISTS `larbi` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `larbi`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: mcm-prod.chwkfp078t9a.eu-west-3.rds.amazonaws.com    Database: larbi
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `disease`
--

DROP TABLE IF EXISTS `disease`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `disease` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_by` varchar(255) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `last_modified_date` timestamp NULL DEFAULT NULL,
  `version` int DEFAULT NULL,
  `designation` varchar(255) NOT NULL,
  `date` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `note` text,
  `doctor` varchar(255) DEFAULT NULL,
  `patient_id` bigint NOT NULL,
  `visit_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_disease_patient` (`patient_id`),
  KEY `FK_disease_visit` (`visit_id`),
  CONSTRAINT `FK_disease_patient` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`id`),
  CONSTRAINT `FK_disease_visit` FOREIGN KEY (`visit_id`) REFERENCES `visit` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disease`
--

LOCK TABLES `disease` WRITE;
/*!40000 ALTER TABLE `disease` DISABLE KEYS */;
INSERT INTO `disease` VALUES (1,'doctor','2023-05-17 10:41:34','doctor','2023-05-17 10:41:34',0,'gastro-enterite','2023-05-17','ACTIVE',NULL,'larbi khadidja',2,1),(2,'doctor','2023-05-17 14:15:25','doctor','2023-05-17 14:15:25',0,'stéatose hépatiqu ','2023-05-17','ACTIVE',NULL,'larbi khadidja',4,3),(3,'doctor','2023-05-18 09:18:11','doctor','2023-05-18 09:18:11',0,'stéatohepatite','2023-05-18','ACTIVE',NULL,'larbi khadidja',6,4),(4,'doctor','2023-05-29 08:58:26','doctor','2023-05-29 08:58:26',0,'ThyroÏdite du post-partum','2023-05-29','ACTIVE',NULL,'larbi khadidja',23,28),(5,'doctor','2023-06-01 10:05:49','doctor','2023-06-01 10:05:49',0,'Thyroïdite de HASHIMOTO','2023-06-01','ACTIVE',NULL,'larbi khadidja',33,38),(6,'doctor','2023-06-01 14:53:25','doctor','2023-06-01 14:53:25',0,'Thyroïdite de HASHIMOTO','2023-06-01','ACTIVE',NULL,'larbi khadidja',39,41),(7,'doctor','2023-06-03 13:07:44','doctor','2023-06-03 13:07:44',0,'Maladie de Ménière','2023-06-03','ACTIVE',NULL,'larbi khadidja',42,44),(8,'doctor','2023-06-03 13:07:55','doctor','2023-06-03 13:07:55',0,'ThyroÏdite chronique de HASHIMOTO','2023-06-03','ACTIVE',NULL,'larbi khadidja',42,44),(9,'doctor','2023-06-03 13:08:31','doctor','2023-06-03 13:08:31',0,'HTA','2023-06-03','ACTIVE',NULL,'larbi khadidja',42,44),(10,'doctor','2023-06-04 08:19:38','doctor','2023-06-04 08:19:38',0,'valve mecanique aortique','2023-06-04','ACTIVE',NULL,'larbi khadidja',43,45),(11,'doctor','2023-06-04 08:19:49','doctor','2023-06-04 08:19:49',0,'HTA ','2023-06-04','ACTIVE',NULL,'larbi khadidja',43,45),(12,'doctor','2023-06-05 09:01:35','doctor','2023-06-05 09:01:35',0,'ThyroÏdite chronique de HASHIMOTO','2023-06-05','ACTIVE',NULL,'larbi khadidja',52,55),(13,'doctor','2023-06-06 10:16:41','doctor','2023-06-06 10:16:41',0,'ThyroÏdite chronique de HASHIMOTO','2023-06-06','ACTIVE',NULL,'larbi khadidja',59,62),(14,'doctor','2023-06-06 10:16:47','doctor','2023-06-06 10:16:47',0,'HTA','2023-06-06','ACTIVE',NULL,'larbi khadidja',59,62),(15,'doctor','2023-06-10 10:40:24','doctor','2023-06-10 10:40:24',0,'ThyroÏdite chronique de HASHIMOTO','2023-06-10','ACTIVE',NULL,'larbi khadidja',69,75),(16,'doctor','2023-06-13 08:08:15','doctor','2023-06-13 08:08:15',0,'Diabète non insulino-dépendant (Type 2)','2023-06-13','ACTIVE',NULL,'larbi khadidja',74,88),(17,'doctor','2023-06-13 08:08:52','doctor','2023-06-13 08:08:52',0,'hypothyroidie central','2023-06-13','ACTIVE',NULL,'larbi khadidja',74,88),(18,'doctor','2023-06-18 08:59:53','doctor','2023-06-18 08:59:53',0,'Accident ischémique constitué vasculaire cérébral','2023-06-18','ACTIVE',NULL,'larbi khadidja',91,105),(19,'doctor','2023-07-11 08:32:45','doctor','2023-07-11 08:32:45',0,'Diabète non insulino-dépendant (Type 2)','2023-07-11','ACTIVE',NULL,'larbi khadidja',111,187),(20,'doctor','2023-07-20 11:11:58','doctor','2023-07-20 11:11:58',0,'ThyroÏdite chronique de HASHIMOTO','2023-07-20','ACTIVE',NULL,'larbi khadidja',161,205),(21,'doctor','2023-07-24 10:48:00','doctor','2023-07-24 10:48:00',0,'ThyroÏdite chronique de HASHIMOTO','2023-07-24','ACTIVE',NULL,'larbi khadidja',170,220),(22,'doctor','2023-08-08 08:22:51','doctor','2023-09-17 12:21:23',1,'Anémie ferriprive','2023-09-17','ACTIVE',NULL,'larbi khadidja',195,424),(23,'doctor','2023-08-09 07:55:33','doctor','2023-08-09 07:55:33',0,'HTA ESSENTIEL','2023-08-09','ACTIVE',NULL,'larbi khadidja',201,265),(24,'doctor','2023-08-09 07:55:53','doctor','2023-08-09 07:55:53',0,'DIABETE TYPE 2','2023-08-09','ACTIVE',NULL,'larbi khadidja',201,265),(25,'doctor','2023-09-03 08:01:30','doctor','2023-09-03 08:01:30',0,'Maladie de GILBERT','2023-09-03','ACTIVE',NULL,'larbi khadidja',269,362),(26,'doctor','2023-09-13 08:20:45','doctor','2023-09-13 08:20:45',0,'Lupus érythémateux disséminé','2023-09-13','ACTIVE',NULL,'larbi khadidja',296,405),(27,'doctor','2023-09-13 08:55:30','doctor','2023-09-13 08:55:30',0,'colopathie fonctionnel','2023-09-13','ACTIVE',NULL,'larbi khadidja',297,406),(28,'doctor','2023-09-13 11:38:41','doctor','2023-09-13 11:38:41',0,'Diabète non insulino-dépendant (Type 2)','2023-09-13','ACTIVE',NULL,'larbi khadidja',293,409),(29,'doctor','2023-09-14 08:20:44','doctor','2023-09-14 08:20:44',0,'Thyroïdite de HASHIMOTO','2023-09-14','ACTIVE',NULL,'larbi khadidja',298,412),(30,'doctor','2023-09-14 09:01:53','doctor','2023-09-14 09:01:53',0,'Diabète insulino-dépendant (Type 1)','2023-09-14','ACTIVE',NULL,'larbi khadidja',96,413),(31,'doctor','2023-09-14 10:48:50','doctor','2023-09-21 10:25:25',1,'Lupus érythémateux disséminé','2023-09-21','ACTIVE',NULL,'larbi khadidja',57,442),(32,'doctor','2023-09-14 10:49:10','doctor','2023-09-21 10:25:25',1,'Maladie de BASEDOW','2023-09-21','ACTIVE',NULL,'larbi khadidja',57,442),(33,'doctor','2023-09-16 07:50:55','doctor','2023-09-16 07:50:55',0,'DIABETE INSULINO -REQUERENT','2023-09-16','ACTIVE',NULL,'larbi khadidja',300,416),(34,'doctor','2023-09-17 12:05:58','doctor','2023-09-17 12:05:58',0,'Thyroïdite de HASHIMOTO','2023-09-17','ACTIVE',NULL,'larbi khadidja',302,423),(35,'doctor','2023-09-18 07:57:27','doctor','2023-09-18 07:57:27',0,'colopathie fonctionnel','2023-09-18','ACTIVE',NULL,'larbi khadidja',303,425),(36,'doctor','2023-09-18 10:33:32','doctor','2023-09-18 10:33:32',0,'HTA','2023-09-18','ACTIVE',NULL,'larbi khadidja',306,428),(37,'doctor','2023-09-18 10:33:49','doctor','2023-09-18 10:33:49',0,'DIABETE INSULINO -REQUERENT','2023-09-18','ACTIVE',NULL,'larbi khadidja',306,428),(38,'doctor','2023-09-18 10:58:54','doctor','2023-09-18 10:58:54',0,'Maladie de BASEDOW','2023-09-18','ACTIVE',NULL,'larbi khadidja',307,429),(39,'doctor','2023-09-19 09:06:26','doctor','2023-09-19 09:06:26',0,'ThyroÏdite chronique de HASHIMOTO','2023-09-19','ACTIVE',NULL,'larbi khadidja',236,432),(40,'doctor','2023-10-01 11:59:59','doctor','2023-10-01 11:59:59',0,'ThyroÏdite chronique de HASHIMOTO','2023-10-01','ACTIVE',NULL,'larbi khadidja',247,500),(41,'doctor','2023-10-11 09:40:35','doctor','2023-10-11 09:40:35',0,'ThyroÏdite du post-partum','2023-10-11','ACTIVE',NULL,'larbi khadidja',379,567),(42,'doctor','2023-11-29 13:26:45','doctor','2023-11-29 13:26:45',0,'Cystite','2023-11-29','ACTIVE',NULL,'larbi khadidja',398,849),(43,'doctor','2023-12-26 09:21:36','doctor','2023-12-26 09:21:36',0,'ThyroÏdite chronique de HASHIMOTO','2023-12-26','ACTIVE',NULL,'larbi khadidja',529,989);
/*!40000 ALTER TABLE `disease` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-03 17:12:08
