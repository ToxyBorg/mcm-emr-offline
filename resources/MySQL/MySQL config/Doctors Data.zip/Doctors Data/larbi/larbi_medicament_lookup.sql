CREATE DATABASE  IF NOT EXISTS `larbi` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `larbi`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: mcm-prod.chwkfp078t9a.eu-west-3.rds.amazonaws.com    Database: larbi
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `medicament_lookup`
--

DROP TABLE IF EXISTS `medicament_lookup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicament_lookup` (
  `value` varchar(255) NOT NULL,
  `dci` varchar(255) DEFAULT NULL,
  `forms` text,
  `sponsored` bit(1) NOT NULL DEFAULT b'0',
  `points` bigint DEFAULT NULL,
  `lab_id` bigint DEFAULT NULL,
  `dosage_card` mediumtext,
  `notice` mediumtext,
  `specialities` text,
  PRIMARY KEY (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicament_lookup`
--

LOCK TABLES `medicament_lookup` WRITE;
/*!40000 ALTER TABLE `medicament_lookup` DISABLE KEYS */;
INSERT INTO `medicament_lookup` VALUES ('APPETIT KESSAB','APPETIT','[{\"form\":\"sirops\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('ARTHROFLEX','EXTRAIT DE CURCUMA','[{\"form\":\"gel\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('BANDELETTE GLYCEMIQUE','BANDELETTE GLYCEMIQUE','[{\"form\":\"bandelette\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('BANDELETTE GLYCEMIQUE(BIONIME)','BANDELETTE GLYCEMIQUE','[{\"form\":\"bandelette\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('BIOFENAC FAST','DICLOFÉNAC POTASSIQUE','[{\"form\":\"sachet\",\"dosages\":[\"50mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('CALCIOS','CARBONATE DE CALCIUM','[{\"form\":\"comprimé à sucer\",\"dosages\":[\"500mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('CALCIUM D3 WML','CALCIUM-CHOLÉCALCIFEROL','[{\"form\":\"500mg/400ui\",\"dosages\":[]},{\"form\":\"comprimé à croquer\",\"dosages\":[\"500mg/400ui\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('CHONDROFLEX','GLUCOSAMINE','[{\"form\":\"cp\",\"dosages\":[\"1000mg/300mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('DEXILANT','DEXLANSOPRAZOL','[{\"form\":\"capsule\",\"dosages\":[\"60mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('EBASTA','EBASTINE','[{\"form\":\"cp\",\"dosages\":[\"10\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('ESTOGEL','OXYDE ALIMINUM','[{\"form\":\"sch\",\"dosages\":[\"1.2g\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('ETHAMBUTOL 275, ISONIAZID 75, PYRAZINAMIDE 400, RIFAMPIN 150','ETHAMBUTOL 275, ISONIAZID 75, PYRAZINAMIDE 400, RIFAMPIN 150','[{\"form\":\"cmprimé\",\"dosages\":[]},{\"form\":\"cp\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('FERODAL','HYDROXYDE FERRIQUE POLYMALTOSE','[{\"form\":\"sirops\",\"dosages\":[\"50mg/5ml\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('GINKOLOBA','GINKGO BILOBA','[{\"form\":\"gellule\",\"dosages\":[]},{\"form\":\"gelule\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('GLARUS','GLARGINE','[{\"form\":\"inj\",\"dosages\":[\"100ml/ui\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('GLUCOFLEX','GLUCOSAMINE','[{\"form\":\"gel\",\"dosages\":[\"750mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('GLUCPHAGE','METFORMINE','[{\"form\":\"cp\",\"dosages\":[\"850mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('LANCETTE','LANCETTE GLYCEMIE','[{\"form\":\"lancets\",\"dosages\":[]},{\"form\":\"lancettes\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('LANCETTE GLUCEMIE','LANCETTE GLYCEMIE','[]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('LECTEUR GLYCEMIQUE','LECTEUR GLYCEMIQUE','[]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('LECTEUR GLYCEMIQUE BIONIME','LECTEUR GLYCEMIQUE','[{\"form\":\"glucomètre\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('LES-NEUF B','COMPLEX VITAMINIQUE B','[{\"form\":\"gel\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('LORATIDINE','LORATIDINE','[{\"form\":\"cp\",\"dosages\":[\"10 mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('MARILON','DESOGESTREL/ETHYNILOESTRADIOL','[{\"form\":\"cp\",\"dosages\":[\"150ug/20ug\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('MEBO','BETASITOSTEROL','[{\"form\":\"pommade\",\"dosages\":[\"0.25\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('MELAGYN','MELAGYN','[{\"form\":\"gel\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('MODOPAR','LEVODOPA','[{\"form\":\"cp\",\"dosages\":[]},{\"form\":\"cp secable\",\"dosages\":[\"125mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('MYCOPROX','CICLOPIROXOLAMINE','[{\"form\":\"crème dermique\",\"dosages\":[\"1°/\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('NOMEGESTROL','ACETATE DE NOMEGETROL','[{\"form\":\"cp\",\"dosages\":[\"5mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('NUTRIGEST+ MG','BIGLYCENATE DE MAG B1 B6 B12','[{\"form\":\"cp\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('OESINE AQUEUSE','OESINE','[{\"form\":\"solution\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('OMEGA 3','OMEGA 3','[{\"form\":\"capsule\",\"dosages\":[\"1000mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('PEPTIDAC','ALGINATE DE SODIUM','[{\"form\":\"suspension buvable\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('RIMSTAR','ETHAMBUTOL 275, ISONIAZID 75, PYRAZINAMIDE 400, RIFAMPIN 150','[{\"form\":\"cp\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('SMYDIL','DIOSMEDINE','[{\"form\":\"p.sus.buvable\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('SOLVITYL','VITAMINES','[{\"form\":\"sirops\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('SOLYNE MAGNESUIM','MAGNESUIM','[{\"form\":\"cp eff\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('SULFARLEM','SULFARLEM','[{\"form\":\"cp\",\"dosages\":[\"25mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('SUPRADYN BOOST','COMPLEXE VITAMINIQUE','[{\"form\":\"cp effe\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('SUPRADYNE BOOSTER','COMPLEX VITAMINIQUE','[{\"form\":\"cp effe\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('TANAKOR PLUS','MG-GINKJO BILOBA B5 B6 ','[{\"form\":\"Cp\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('TAZOTAX','FUBEXOSTAT','[{\"form\":\"cp\",\"dosages\":[\"80mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('TERBIDAL','CHLORHYDRATE DE TERBINAFINE','[{\"form\":\"spray\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('URILYSE','FTH','[{\"form\":\"cp\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('VACCIN ANTI GRIPPAL','VACCIN','[]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('VALENS','DAPAGLIFOZINE','[{\"form\":\"CP\",\"dosages\":[\"5mg\",\"10mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('VASELINE SALICYLÉ','VASELINE SALICYLÉ','[{\"form\":\"creme\",\"dosages\":[\"5 pour\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('VASELINE SIMPLE','VASELINE','[{\"form\":\"creme\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('VIPIDIA','ALOGLIPTINE','[{\"form\":\"cp\",\"dosages\":[\"25mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('VITAL D3','VITAMINE D3','[{\"form\":\"cp à croquer\",\"dosages\":[\"1000ui\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('VITAMINE C +ZINC','VITAMINE C ET ZINC','[{\"form\":\"gel\",\"dosages\":[\"250mg/10mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('ZOPRA','LANSOPRAZOLE','[{\"form\":\"gel\",\"dosages\":[\"30mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]');
/*!40000 ALTER TABLE `medicament_lookup` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-03 17:11:52
