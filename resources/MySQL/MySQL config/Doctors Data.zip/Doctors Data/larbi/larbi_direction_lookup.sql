CREATE DATABASE  IF NOT EXISTS `larbi` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `larbi`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: mcm-prod.chwkfp078t9a.eu-west-3.rds.amazonaws.com    Database: larbi
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `direction_lookup`
--

DROP TABLE IF EXISTS `direction_lookup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `direction_lookup` (
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `direction_lookup`
--

LOCK TABLES `direction_lookup` WRITE;
/*!40000 ALTER TABLE `direction_lookup` DISABLE KEYS */;
INSERT INTO `direction_lookup` VALUES ('01 bouffé 2 fois /j'),('01 pulvérisation 2 fois /j'),('02 bouffé 2 fois /j'),('02 bouffé 3 fois /j'),('1  bouffé 2fois /j'),('1 app /j'),('1 app /j pdt 21 jour'),('1 app 2fois/j'),('1 app 3 fois /j'),('1 app 6 fois /j'),('1 bains 3 fois /j'),('1 bouffé 2 fois /j'),('1 càs  3fois /j après repas'),('1 càs 3fois /j'),('1 càs 3fois /j avent repas'),('1 càs le matin'),('1 càs le soir'),('1 cp  fois /j en milieu de repas'),('1 cp /j'),('1 cp /j à jeun'),('1 cp /j après repas de soir'),('1 cp /j le soir'),('1 cp 15\'avent repas'),('1 cp 2 fois /j'),('1 cp 2 fois /j à distance des repas'),('1 cp 2 fois /j(le 1er cp 30\' avent petit déjeuné et le 2emme cp 2h après déjeunée)'),('1 cp 2fois /j'),('1 cp 3 fois /j'),('1 cp 3 fois /j avent repas'),('1 cp 4 fois /j'),('1 cp à croqué/j'),('1 cp et 1/2 cp le soir'),('1 cp le soir'),('1 cp/j le soir'),('1 gel  2 fois /j'),('1 gel / le soir'),('1 gel /j'),('1 gel /j le matin'),('1 gel /j le soir'),('1 gel 2 fois /j à distance des repas'),('1 gel 4 fois /j'),('1 gel/j'),('1 gel/j le soir'),('1 inj en IM'),('1 instillation 2fois /j'),('1 instillation 3fois /j'),('1 patch/12h'),('1 pulvérisation /narine/j'),('1 sch  /j en milieu de repas'),('1 sch 3 fois/j'),('1 test  3 fois /j'),('1 test /j'),('1 test /j (diagno check)'),('1 test 5 fois /j'),('1 test 5 fois /j (vital check)'),('1 test 7 fois /j'),('1/2 cp /j'),('1/2 cp /j à jeun pdt 15jours puis 1 cp /j'),('1/2 cp /j à jeun pdt 7jours puis 1cp /j  à jeun'),('1/2 cp /j à jeun pdt 7jours puis 1cp /j à jeun'),('1/2 cp /j à jeun pdt 7jours puis 1cp /j àjeun'),('1/2 cp /semaine'),('1/2 cp 2 fois /j'),('1/2 cp à8h et 1 cp à 12h avent repas'),('1/2 cp avent petit dejeuné'),('1/2 cp avent petit déjeuné et 1/2 cp avent déjeuné'),('1/2cp /j à jeun'),('1/2cp 5j/7'),('10 ui le soir'),('10ml 2 fois /j'),('10ml 2 fois /j 30\'avent repas'),('10ml/j àjeun'),('10ui 2 fois/j'),('10ui 3 fois /j'),('10ui le soir'),('12 ui le soir'),('125ug /j à jeun'),('12ui /j'),('12ui 2 fois /j'),('12ui 2 fois /j avent repas'),('12ui 3 fois /j'),('12ui le soir'),('14ui le soir'),('15\' avent chaque repas'),('150ug /j à jeun'),('15mg /semaine'),('15ui 3 fois /j'),('16 ui 3fois /j'),('16ui 3 fois /j'),('16ui le soir'),('18ui 3 fois /j'),('18ui le soir'),('1amp /j'),('1amp 2fois /j'),('1amp à J0/J15 et J30 puis 1 amp /mois'),('1amp buvable à 10h'),('1amp buvable à J0/J15 et J30 puis 1 amp /mois'),('1amp buvable à J0/J15 et J30 puis 1 amp /mois pdt 3 mois'),('1amp buvable à J0/J15 et J30 puis 1 amp /mois pdt 3mois'),('1amp buvable à J0/J15 et J30 puis 1 amp /mois pdt 4 mois mois'),('1app /'),('1app /j'),('1app /j pdt 21j'),('1app 2 fois /j'),('1app 2fois /semaine'),('1app 3 fois /j'),('1app 4 fois /j'),('1app avent chaque selles'),('1app/j'),('1app/j le soir'),('1c/j'),('1càc/j le soir'),('1càs  le soir'),('1càs /j'),('1càs /j le matin'),('1càs 15\' avent chaque repas'),('1càs 15\' avent repas'),('1càs 15\' avent repas 3fois /j'),('1càs 2 fois /j'),('1càs 3fois /j'),('1càs 3fois /j 15\' avent repas'),('1càs le matin'),('1càs/j'),('1cp  /j en milieu de repas'),('1cp  2fois/j'),('1cp  2fois/j en cas de besoin'),('1cp + 1/2cp /j à jeun'),('1cp /6h'),('1cp /j'),('1cp /j  avent repas de soir'),('1cp /j (non sedatif)'),('1cp /j 10\' avent repas'),('1cp /j à 12h'),('1cp /j à 12h en milieu de repas'),('1cp /j à 12h en milieu de repas pdt 7j puis 1cp 2 fois /j'),('1cp /j à jeun'),('1cp /j à sucer'),('1cp /j après petit déjeunée'),('1cp /j après repas'),('1cp /j après repas de soir'),('1cp /j avent le repas de soir'),('1cp /j avent repas'),('1cp /j avent repas de 12h'),('1cp /j avent repas de soir'),('1cp /j en milieu de repas'),('1cp /j en milieu de repas pdt 7jours puis 1cp 2fois /j'),('1cp /j le avent repas de soir'),('1cp /j le matin'),('1cp /j le soir'),('1cp /j le soir pdt 7jours'),('1cp /j pdt 1 mois puis 1j/2'),('1cp /j pdt 21j'),('1cp /j pdt 3j'),('1cp /j pdt 5j'),('1cp /semaine'),('1cp 2 fois /j'),('1cp 2 fois /j avent repas'),('1cp 2 fois /j en cas de besoin'),('1cp 2 fois /j en milieu de repas'),('1cp 2 fois /j pdt 5jours'),('1cp 2 fois /j pdt 7j puis 1cp /j le matin'),('1cp 2 fois/j'),('1cp 2 fois/j à distance des repas'),('1cp 2fois /j'),('1cp 2fois/j'),('1cp 2fois/j à distance des repas'),('1cp 3 fois /j'),('1cp 3fois/j'),('1cp 4 fois'),('1cp 5j/7'),('1cp à 12h et 2 cp à 20h avent repas'),('1cp à 8h et 2cp à 12h 10\'avent repas'),('1cp a sucé/j'),('1cp à sucer 1cp 2 fois /j'),('1cp a sucer/j'),('1cp à8h et 1cp à 12h avent repas'),('1cp avent petit dejeuner'),('1cp avent repas'),('1cp de 100ug+ 1/2 cp de 25ug/j àjeun'),('1cp de 50 +1/2 cp de 25ug à jeun'),('1cp de 50+1/2cp/j à jeun'),('1cp de 75 +1/2 cp de 25ug à jeun'),('1cp et 1/2 /j à jeun'),('1cp et 1/2 3 fois /j 30\' après repas'),('1cp/j'),('1cp/j en milieu de repas'),('1cp/j le matin'),('1cp/j le soir'),('1cp/j pdt 7 jours puis 2 cp /j à jeun'),('1cp4 fois /j en cas besoin'),('1gel  3 fois/j'),('1gel /12h'),('1gel /j'),('1gel /j avent repas'),('1gel /j le matin'),('1gel /j le soir'),('1gel 2 fois/j'),('1gel 2 fois/j à distance des repas'),('1gel 2 fois/j avent repas'),('1gel 2 fois/j p10j puis 1gel /j'),('1gel 2fois /j'),('1gel 2fois /j à distance des repas'),('1gel 4 fois /j'),('1gel/12h'),('1gel/j en j1 puis 1gel 2 fois /j en j2 puis 1gel 3 fois /j'),('1gel/j le soir'),('1goutte /œil droit et œil gauche'),('1goutte 2 fois /j /oeil'),('1inj en IM'),('1inj en IM à j0 /j14 et j30 puis 1 inj en im chaque mois'),('1inj en im/10j'),('1inj/j en IM pdt 14j puis 1inj 1j/2 pdt 14j puis 1j/mois'),('1lancette avent chaque test'),('1patch /12h'),('1pulvarisation/narine 2fois/j'),('1pulvarisation/narine/j'),('1sch /j'),('1sch /j en milieu de repas'),('1sch 2 fois/j'),('1sch 2fois /j'),('1sch 3 fois /j'),('1sch 3fois/j'),('1sch dilué dans un 1/2 verre d\'eau'),('1sch dilué dans un 1/2 verre d\'eau /5j'),('1sch dilué dans un 1/2 verre d\'eau/7j'),('1sch dilué dans un gros verre d\'eau'),('1sch dilué dans un verre d\'eau'),('1supp en cas de besoin'),('1supp/j'),('1test /j'),('1test /j (diagno-check)'),('1test /j(On.call extra)'),('1test 3 fois /j'),('1test 5 fois /j'),('1test 6 fois /j'),('1utilisation avent chaque test'),('2 cp 2 fois /j'),('2 cp à 8h et 2cp à 12h 10\'avent repas'),('2 cp le soir'),('2 gel 3 xj'),('2 gel/j'),('20 goutte 3 fois /j'),('20 goutte/jour'),('20 ui le soir'),('200ug/j à jeun'),('20gtte'),('20gtte 2fois/j'),('20gtte/j pdt 10 jours'),('20ml/j  2h après petit déjeuné'),('20ui 2 fois/j'),('20ui le soir'),('22 ui le soir'),('28ui le soir'),('2amp en IM matin et soir'),('2bouffée 3fois /j'),('2cp /j à 8h'),('2cp /j le matin pdt 4jours'),('2cp /j pdt 5 jours'),('2cp 2 fois/j'),('2cp 3 fois /j'),('2cp 48h apres methotrext'),('2cp à 8h 10\' avent petit dejeuner'),('2cp à 8h et 2cp à 12 10\'avent repas'),('2cp à 8h et 2cp à 12 pdt 1 mois'),('2cp à 8h et 2cp à 12 pdt 1 mois puis 2cp à 8h et 1 cp à 12h pdt 1 mois puis 2 cp à 8h'),('2cp à 8h et 2cp à 12h'),('2cp en monoprise 10\'avent le petit dejeuné'),('2cp en monoprise 10\'avent repas de 12'),('2cp en monoprise 10\'avent repas de 12h'),('2cp/j à 8h'),('2gel 3 fois /j'),('2gel 3 fois /j(tout les 8h)'),('2sch 2 fois /j pdt 48h puis 1sch 2 fois /j sans depassé 10jours'),('3 cp en monoprise  /semaine'),('30gtte/j'),('30ui 3 fois /j'),('32ui le soir'),('34ui le soir'),('35ui le soir'),('3cp /j'),('3cp /j 10\'avent petit dejeuner'),('3cp 3 fois /j'),('3cp 48h après la prise de methotrexat'),('3cp en monoprise /semaine'),('3cp en monoprise 10\'avent repas de 12h'),('3gel en monoprise/semaine'),('4 cp /j à jeun'),('44 ui le soir'),('4cp /j'),('4cp /j à jeun'),('4goutte le soir'),('5 cp /semaine'),('50ui le soir'),('54ui le soir'),('5cp /j'),('6 cp /semaine'),('6cp /semaine'),('6ui 3 fois /j'),('7 cp /semaine'),('8ui 2 fois /j'),('8ui 3 fois /j'),('càs /j'),('en alternance 1cp de 50ug et 1cp de 75ug 1j /2'),('en melangant avec clotasol'),('en melange avec clotasol'),('i inj/j');
/*!40000 ALTER TABLE `direction_lookup` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-03 17:09:32
