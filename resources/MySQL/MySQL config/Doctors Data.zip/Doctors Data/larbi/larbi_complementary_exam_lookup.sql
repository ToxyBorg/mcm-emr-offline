CREATE DATABASE  IF NOT EXISTS `larbi` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `larbi`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: mcm-prod.chwkfp078t9a.eu-west-3.rds.amazonaws.com    Database: larbi
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `complementary_exam_lookup`
--

DROP TABLE IF EXISTS `complementary_exam_lookup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `complementary_exam_lookup` (
  `value` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `complementary_exam_lookup`
--

LOCK TABLES `complementary_exam_lookup` WRITE;
/*!40000 ALTER TABLE `complementary_exam_lookup` DISABLE KEYS */;
INSERT INTO `complementary_exam_lookup` VALUES ('AC anti CCP','SEROLOGY'),('Ac anti DNA','SEROLOGY'),('AC anti facteur intrinsèque','SEROLOGY'),('AC anti gliadine','SEROLOGY'),('Ac Anti LKM1','SEROLOGY'),('Ac Anti mitochondrie','SEROLOGY'),('Ac Anti muscle lisse','SEROLOGY'),('Ac anti recepteur de TSH (TRAK)','SEROLOGY'),('Ac anti TG','SEROLOGY'),('Ac anti TPO','SEROLOGY'),('AC anti transglutaminase','SEROLOGY'),('AC TPO','SEROLOGY'),('Acide folique','SEROLOGY'),('Ag HBs','SEROLOGY'),('Albuminemie','SEROLOGY'),('AMH','SEROLOGY'),('ANCA anti MPO','SEROLOGY'),('ASLO','SEROLOGY'),('bilirubine totale , directe et indirecte','SEROLOGY'),('C R P','SEROLOGY'),('c-ANCA','SEROLOGY'),('calcémie, phosphorémie','SEROLOGY'),('Cholesteol hdl ldl trig','SEROLOGY'),('Cholesteol total , HDL, LDL , TRIGLYCERIDE','SEROLOGY'),('Cholesteol total /HDL/LDL/TRIGLYCERIDE','SEROLOGY'),('Cholesterol total , HDL , LDL , TRIGLYCERIDE','SEROLOGY'),('cholesterol total, HDL  , LDL, TRIGLYCERIDE','SEROLOGY'),('Coefficient de saturation de la transferrine','SEROLOGY'),('compte d\'addis','SEROLOGY'),('Cortisolémie à8h','SEROLOGY'),('creatinemie','SEROLOGY'),('créatinémie sanguine','SEROLOGY'),('CUPREMIE','SEROLOGY'),('D dimeres','SEROLOGY'),('échographie de l\'épaule droit','IMAGERY'),('échographie de l\'épaule gauche','IMAGERY'),('électrophorèse des protéine sériques','SEROLOGY'),('Électrophorèse des protéines seriques','SEROLOGY'),('etude cytologique des urines','ANATOMOPATHOLOGY'),('F N S','SEROLOGY'),('F N S complete','SEROLOGY'),('F NS','SEROLOGY'),('Facteur anti nucléaire','SEROLOGY'),('Facteur anti nucléaire avec ciblage antigénique','SEROLOGY'),('Feritinémie','SEROLOGY'),('FNS complete','SEROLOGY'),('FOND D\'OEIL','OTHER'),('FOND D\'OEIL+AV(bilan de retentissement de DT2)','OTHER'),('FT4','SEROLOGY'),('gamma GT','SEROLOGY'),('glycem à jeun','SEROLOGY'),('H B A 1c','SEROLOGY'),('HBA 1c','SEROLOGY'),('HBA1 c','SEROLOGY'),('HBA1C h','SEROLOGY'),('hemoccult  selles','SEROLOGY'),('HGPO','SEROLOGY'),('IGE serique','SEROLOGY'),('IgE spécifique à une allergie alimentaire','SEROLOGY'),('microalbuminurie','SEROLOGY'),('microalbuminurie ACR','SEROLOGY'),('natrémie et kaliémie','SEROLOGY'),('p-ANCA','SEROLOGY'),('phosphatase alcaline','SEROLOGY'),('Prélèvement mycologique','SEROLOGY'),('Prolactinemie','SEROLOGY'),('protéinurie des 24h','SEROLOGY'),('PSA total et le rapport','SEROLOGY'),('radio de l\'avent pied droit face','IMAGERY'),('RX 02 CHEVILLE PROFIL','IMAGERY'),('Rx de  genou droit face et profil','IMAGERY'),('Rx de 2 genoux face et profil','IMAGERY'),('rx de bassin','IMAGERY'),('rx de cheville gauche profil','IMAGERY'),('rx de l\'avent pied droit face','SEROLOGY'),('rx de l\'épaule droite face','IMAGERY'),('rx de l\'épaule gauche face','IMAGERY'),('Rx de rachis cervical face et profil','IMAGERY'),('rx de rachis lombo-sacré','IMAGERY'),('rx de rachis lombo-sacré face et profil','IMAGERY'),('RX de rl','IMAGERY'),('Rx DES 02 POIGNE FACE ET PROFILE','IMAGERY'),('RX DU BRAS GAUCHE','IMAGERY'),('rx du poigné droit','IMAGERY'),('rx du rachis cervical face et profil','IMAGERY'),('RX DU RACHIS DORSAL FACE + PROFIL','IMAGERY'),('rx du rachis dorso-lombaire avec la charnière lombo-sacré face et profil','IMAGERY'),('Rx du rachis lombo-sacré face et profil','IMAGERY'),('serologie de l\'hépatite C','SEROLOGY'),('Sérologie HIV','SEROLOGY'),('T S H','SEROLOGY'),('T S H us','SEROLOGY'),('T S Hus','SEROLOGY'),('taux  de reticulocyte','SEROLOGY'),('Téléthorax de face','IMAGERY'),('test  au syncthene','SEROLOGY'),('test respiratoire à l\'uréase (HP)','SEROLOGY'),('test respiratoire à l\'urée (HP)','SEROLOGY'),('TGO , TGP','SEROLOGY'),('TGO /TGP','SEROLOGY'),('TP,INR','SEROLOGY'),('TS','SEROLOGY'),('TSHus','SEROLOGY'),('une gril costal','IMAGERY'),('urée','SEROLOGY'),('Urée - Créatinémie','SEROLOGY'),('urée, creatinemie','SEROLOGY'),('V S','SEROLOGY'),('Vitamine B 9','SEROLOGY'),('vitamine D3','SEROLOGY'),('VS, CRP','SEROLOGY');
/*!40000 ALTER TABLE `complementary_exam_lookup` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-03 17:12:54
