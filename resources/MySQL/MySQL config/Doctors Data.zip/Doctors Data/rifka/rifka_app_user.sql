CREATE DATABASE  IF NOT EXISTS `rifka` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `rifka`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: mcm-prod.chwkfp078t9a.eu-west-3.rds.amazonaws.com    Database: rifka
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `app_user`
--

DROP TABLE IF EXISTS `app_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_by` varchar(255) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `last_modified_date` timestamp NULL DEFAULT NULL,
  `version` int DEFAULT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT '0',
  `photo` mediumtext,
  `role` varchar(255) NOT NULL,
  `theme` varchar(255) NOT NULL DEFAULT 'DEFAULT',
  `language` varchar(255) NOT NULL DEFAULT 'fr',
  `layout` varchar(255) NOT NULL DEFAULT 'SIDE_MENU',
  `welcome_page` varchar(255) NOT NULL DEFAULT 'DASHBOARD',
  `provider` bit(1) NOT NULL DEFAULT b'0',
  `immutable` bit(1) NOT NULL DEFAULT b'0',
  `patient_tabs_config` text,
  `office_id` bigint DEFAULT NULL,
  `points` int DEFAULT '0',
  `lab_id` bigint DEFAULT NULL,
  `accordions_config` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ct_username_unique` (`username`),
  KEY `FK_user_office` (`office_id`),
  CONSTRAINT `FK_user_office` FOREIGN KEY (`office_id`) REFERENCES `office` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_user`
--

LOCK TABLES `app_user` WRITE;
/*!40000 ALTER TABLE `app_user` DISABLE KEYS */;
INSERT INTO `app_user` VALUES (1,'system','2022-06-28 16:35:01','rifka','2023-05-06 10:44:47',17,'Rifka','Tourab','$2a$10$pJuAVJ/8LxTTToKU/.soe.yuXEjIkmeURkIPGYIP3ANtv2qzIKSAq','rifka','0',NULL,'DOCTOR','DEFAULT','fr','SIDE_MENU','DASHBOARD',_binary '',_binary '','{\"GENERAL\":true,\"VISITS\":true,\"ORDONNANCES\":true,\"VITAL_SIGNS\":true,\"VISIT_MEDICAMENTS\":true,\"COMPLEMENTARY_EXAMS\":true,\"ALLERGIES\":true,\"CLINICAL_INFORMATIONS\":true,\"PATHOLOGICAL_ANTECEDENTS\":true,\"IMMUNISATIONS\":true,\"DISEASES\":true,\"CERTIFICATES\":true,\"PAYMENTS\":true,\"REMARKS\":false}',1,20000,NULL,NULL),(2,'system','2022-06-28 16:35:01','assistant','2022-12-28 14:56:38',2,'Wided','Bouchema','$2a$10$cet1n0fd8j6QLH21rjmJq.mGkvaQfXXh0uI4wNV2PNpeFlVsgVQGO','wided','0',NULL,'ASSISTANT','DEFAULT','fr','SIDE_MENU','DIGITAL_ASSISTANT',_binary '\0',_binary '\0','{\"GENERAL\":true,\"VISITS\":true,\"ORDONNANCES\":true,\"VITAL_SIGNS\":true,\"VISIT_MEDICAMENTS\":true,\"COMPLEMENTARY_EXAMS\":true,\"ALLERGIES\":true,\"CLINICAL_INFORMATIONS\":true,\"PATHOLOGICAL_ANTECEDENTS\":true,\"IMMUNISATIONS\":true,\"DISEASES\":true,\"CERTIFICATES\":true,\"PAYMENTS\":true}',1,0,NULL,NULL);
/*!40000 ALTER TABLE `app_user` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-03 17:31:36
