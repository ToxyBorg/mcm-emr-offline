CREATE DATABASE  IF NOT EXISTS `rifka` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `rifka`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: mcm-prod.chwkfp078t9a.eu-west-3.rds.amazonaws.com    Database: rifka
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `medicament_lookup`
--

DROP TABLE IF EXISTS `medicament_lookup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicament_lookup` (
  `value` varchar(255) NOT NULL,
  `dci` varchar(255) DEFAULT NULL,
  `forms` text,
  `sponsored` bit(1) NOT NULL DEFAULT b'0',
  `points` bigint DEFAULT NULL,
  `lab_id` bigint DEFAULT NULL,
  `dosage_card` mediumtext,
  `notice` mediumtext,
  `specialities` text,
  PRIMARY KEY (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicament_lookup`
--

LOCK TABLES `medicament_lookup` WRITE;
/*!40000 ALTER TABLE `medicament_lookup` DISABLE KEYS */;
INSERT INTO `medicament_lookup` VALUES ('ACEPRAL CARDIO','ACIDE ACÉTYLSALICYLIQUE','[{\"form\":\"cp\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('ACEROLA','ACEROLA','[]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('ACIDE ALPHA LIPOIQUE','ACIDE ALPHA LIPOIQUE','[{\"form\":\"gélule\",\"dosages\":[\"200mg.\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('ASHWAGANDHA','ASHWAGANDHA','[{\"form\":\"gélules\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('ASIRINE CARDIO','ACIDE ACÉTYLSALICYLIQUE','[{\"form\":\"acide acétylsalicylique\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('ASPEGIC CARDIO','ASPEGIC','[{\"form\":\"cp.\",\"dosages\":[\"100\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('ASPERINE CARDIO','ACIDE ACÉTYLESALICYLIQUE','[{\"form\":\"cp\",\"dosages\":[\"100mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('ASWHAGANDA','ASHWAGHANDA','[{\"form\":\"gelulles\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('BENERGIE','COMPLEXE B','[{\"form\":\"CP\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('BERBERINE','BERBERINE','[{\"form\":\"cp.\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('BIOPEXA','APIXABAN','[{\"form\":\"cp.\",\"dosages\":[\"5mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('CALCIUM-D3','CALCIUM-D3','[]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('CALIGON','CALIGON','[{\"form\":\"magnésium\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('CALMAZEN','CALMAZEN','[{\"form\":\"cp\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('CHROMIUM DE PICOLINATE','CHROME','[{\"form\":\"cp.\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('CHROMIUM DE PICOLINATE NUTRAXIN','CHROME','[{\"form\":\"cp.\",\"dosages\":[\"200mcg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('CO ENZYME','COENZYME Q10','[]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('CO IRBVEL','IRBESARTAN/HYDRCHLOROTHIAZIDE','[]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('COAPROVEL','COAPROVEL MG150MG/12,5MG','[{\"form\":\"cp pellic\",\"dosages\":[\"150mg/12,5mg\",\"300mg/25mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('COBAVIT','CYANOCOBALAMINE','[{\"form\":\"amp\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('COENZYM Q10','COENZYM Q10','[{\"form\":\"gelule\",\"dosages\":[\"100mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('COMPLEXE B','COMPLEXE B','[{\"form\":\"cp.\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('COMPLEXE B DOPPELHERTZ','','[{\"form\":\"cp\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('COMPLEXE VITAMINE B NUTRAXIN','COMPLEXE B','[{\"form\":\"CP.\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('DAPAGLIFLOZINE','PROPANEDIOL','[{\"form\":\"cp.\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('DEMOX CREME','DEMOX CREME','[{\"form\":\"pommade\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('DI DOLEX','TRAMADOL/PARACETAMOL','[]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('DIABETIKER','DIABETIKER','[{\"form\":\"cp\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('DIAMOX','DIAMOX','[{\"form\":\"CP\",\"dosages\":[\"250mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('DIGERME','DIGERME','[{\"form\":\"cp\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('DIOVAN','VALSARTAN','[{\"form\":\"cp\",\"dosages\":[\"80mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('DOLPINA GINKGO BILOBA','GINKGO BILOBA','[{\"form\":\"gouttes\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('DOLPINA NEURO','ADENOSINE MONO PHOSFOTE','[]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('DYNAVIT','DYNAVIT','[{\"form\":\"capsules\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('EBASTA','EBASTINE','[{\"form\":\"cp\",\"dosages\":[\"10mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('EPIXX','EPIXX','[{\"form\":\"750m\",\"dosages\":[]},{\"form\":\"cp\",\"dosages\":[\"750/1000\"]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('ESOPROTON','ESOPROTON','[]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('EVOXYZINE','HYDROXYZINE','[]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('FADIAMONE D3','VITAMINE D3','[{\"form\":\"capsules\",\"dosages\":[\"1000UI\",\"2000UI\"]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('FEBOREX','FEBUXOSTAT','[{\"form\":\"cp\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('FEROSANOL','FER2','[{\"form\":\"gellule\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('FERROSANOL GYN','FER FERREUX','[{\"form\":\"cp\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('FERSANG','FER','[{\"form\":\"gélules\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('FIROZAL','FIROZAL','[]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('GANTANIL','ACÉTYLLEUCINE','[{\"form\":\"cp.\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('GARCINIA GAMBODIA','GARCINIA GOMBODJIA','[{\"form\":\"cp.\",\"dosages\":[\"500mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('GIZLAN-PLUS','IRBESARTAN','[{\"form\":\"cp.\",\"dosages\":[\"300mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('GLUCOFLEX','GLUCOSAMINE','[]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('GLUTATHION','GLUTATHION','[{\"form\":\"cp\",\"dosages\":[\"500mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('GROSSI VIT PLUS','GROSSI VIT PLUS','[{\"form\":\"gélule\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('GROSSIVIT','GROSSIVIT','[{\"form\":\"cp\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('HUILE DE PARAFINE','HUILE DE PARAFINE','[{\"form\":\"solution buvable\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('IMMUDION','IMMUDION','[{\"form\":\"capsule\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('INOFOLIC','INOFOLIC','[{\"form\":\"sachet\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('JUVAMINE MÉMOIR ET CONCENTRATION','','[{\"form\":\"gélules\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('KOBEKTAL','LOSARTANPOTASSIQUE/HYDROCHLOROTHIAZIDE','[{\"form\":\"cp\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('LEPENTIL','LEPENTIL','[]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('LUTEROL','ACÉTATE DE NOMÉGESTROL','[{\"form\":\"cp.\",\"dosages\":[\"05mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('LUTUNIL','LUTUNIL','[{\"form\":\"cp\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('MAG3+D3','MAGNÉSIUM/VITD','[{\"form\":\"sachet\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('MAG3B','MAGNESIUM','[{\"form\":\"cp\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('MAGNÉSIUM BISGYCINATE BPN','MAGNÉSIUM','[{\"form\":\"gélule\",\"dosages\":[\"500mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('MAGNESIUM MARIN','MAGNÉSIUM','[]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('METROL','METROL','[{\"form\":\"cp\",\"dosages\":[\"5mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('METROTREXATE','METROTREXATE','[{\"form\":\"cp\",\"dosages\":[\"5mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('NAC','N ACETYLCYSTEINE','[{\"form\":\"cp\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('NADROLIC','NADROLIC ','[]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('NEUROPLEX','GABAPENTIN 300MG','[]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('NICARDIPINE BIOCARE','NICARDIPINE LP','[{\"form\":\"cp lp \",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('NORMOCARDIL','PROPRANOLOL','[{\"form\":\"40 mg\",\"dosages\":[]},{\"form\":\"cp.\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('NUTRAXIN SÉLÉNIUM','SÉLÉNIUM','[{\"form\":\"sélénium\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('NUTRI D','VITAMINE D','[{\"form\":\"gel\",\"dosages\":[\"50000UI\",\"2000UI\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('OMEGA 3','OMEGA 3','[{\"form\":\"CP\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('OPTIFOLATES','ACIDE FOLIQUE','[{\"form\":\"cp\",\"dosages\":[\"5mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('PHARMABIO ZINC','PHARMABIO','[{\"form\":\"CP\",\"dosages\":[\"14mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('PHI FER','BISGYCINATE DE FER','[{\"form\":\"bisgycinate\",\"dosages\":[\"24mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('PHIFER','BISGYCINATE DE FER','[]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('PHINOSITOL   PHI INDUSTRIES','MYO-INOSITOL 4G/ ACIDE FOLIQUE 200MG','[{\"form\":\"sachet\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('PHYLAT','PHYLAT','[{\"form\":\"gélule\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('QUERCETINE','QUERCITINE','[{\"form\":\"cp\",\"dosages\":[\"500mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('RAPIDRA','INSULINE','[{\"form\":\"inj\",\"dosages\":[\"100UI\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('RHINOSITOL','RHINOSITOL','[{\"form\":\"cp\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('RIVALTO','RIVAROXABAN','[{\"form\":\"cp.\",\"dosages\":[\"20mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('ROMEGA3','OMEGA 3','[]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('ROSUTAB','ROSUTAB','[]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('SÉLÉNIUM','','[{\"form\":\"cp\",\"dosages\":[\"100ng\",\"100\"]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('SOLYNE ENERGIE','MULTIVITAMINE','[]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('TAMAREL','TAMAREL','[{\"form\":\"cp\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('THYLIDIEM','DUIRITIQUE','[{\"form\":\"diuritique\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('TRI B','TRI B','[{\"form\":\"tri b\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('UNIZIA','CANDESARTAN CILEXETIL/AMLODIPINE BESILATE','[{\"form\":\"cp.\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('VIATMINE D AMPOULE','VIT D3','[{\"form\":\"d3\",\"dosages\":[]},{\"form\":\"AMPOULE \",\"dosages\":[\"200000\"]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('VIT APPETIT+','','[{\"form\":\"gélules\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('VIT D','','[{\"form\":\"gélules\",\"dosages\":[\"50000 UI\",\"1000 UI\"]},{\"form\":\"AMPOULE\",\"dosages\":[\"200000\",\"200000 UI\"]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('VITAMINE 12','VIATMINE B12','[]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('VITAMINE COMPLEXE B NUTRAXIN','VITAMINE B','[{\"form\":\"cp.\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('VITAMINE D','','[{\"form\":\"gélules\",\"dosages\":[\"1000\",\"1000 UI\",\"50000\",\"50000 UI\"]},{\"form\":\"ampoule\",\"dosages\":[\"200000UI\",\"50000UI\",\"800\"]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('VITAMINE E','VITAMINE E','[]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('VITAPPÉTIE+','','[{\"form\":\"gélules\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('VITONIC','COMPLEMENT ALIMENTAIRE','[{\"form\":\"mul\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL),('ZINC','','[{\"form\":\"cp\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `medicament_lookup` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-03 17:32:00
