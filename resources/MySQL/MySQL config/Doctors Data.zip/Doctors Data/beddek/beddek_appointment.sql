CREATE DATABASE  IF NOT EXISTS `beddek` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `beddek`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: mcm-prod.chwkfp078t9a.eu-west-3.rds.amazonaws.com    Database: beddek
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `appointment`
--

DROP TABLE IF EXISTS `appointment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `appointment` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_by` varchar(255) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `last_modified_date` timestamp NULL DEFAULT NULL,
  `version` int DEFAULT NULL,
  `cancelation_reason` varchar(255) DEFAULT NULL,
  `appointment_date` datetime DEFAULT NULL,
  `appointment_period` varchar(255) NOT NULL,
  `note` text,
  `status` int DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `type_id` bigint DEFAULT NULL,
  `patient_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_appointment_patient` (`patient_id`),
  KEY `FK_appointment_type` (`type_id`),
  KEY `FK_appointment_user` (`user_id`),
  CONSTRAINT `FK_appointment_patient` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`id`),
  CONSTRAINT `FK_appointment_type` FOREIGN KEY (`type_id`) REFERENCES `appointment_type` (`id`),
  CONSTRAINT `FK_appointment_user` FOREIGN KEY (`user_id`) REFERENCES `app_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointment`
--

LOCK TABLES `appointment` WRITE;
/*!40000 ALTER TABLE `appointment` DISABLE KEYS */;
INSERT INTO `appointment` VALUES (1,'doctor','2023-02-27 20:21:07','doctor','2023-02-27 20:29:35',3,NULL,'2023-02-27 20:21:07','15:20','Name : Tarek Sahalia, Contact : ',3,NULL,1,1,1),(2,'doctor','2023-02-27 20:29:57','doctor','2023-02-27 20:32:11',3,NULL,'2023-02-27 20:29:57','15:30','Name : Tarek Sahalia, Contact : ',3,NULL,3,1,1),(3,'doctor','2023-02-27 20:32:34','doctor','2023-02-27 20:34:16',3,NULL,'2023-02-27 20:32:34','15:40','Name : Amir Sahalia, Contact : ',3,NULL,1,2,1),(4,'doctor','2023-02-27 20:34:41','doctor','2023-02-27 20:35:41',3,NULL,'2023-02-27 20:34:41','15:50','Name : Amir Sahalia, Contact : ',3,NULL,2,2,1),(5,'doctor','2023-02-27 20:35:04','doctor','2023-02-27 20:35:38',4,NULL,'2023-02-27 20:35:04','16:00','Name : Tarek Sahalia, Contact : ',3,NULL,2,1,1),(6,'assistant','2023-02-27 20:52:30','doctor','2023-02-27 20:54:48',3,NULL,'2023-02-27 17:00:00','16:10','Name : Tarek Sahalia, Contact : ',3,NULL,1,1,1),(7,'doctor','2023-03-04 18:18:01','doctor','2023-03-05 09:46:31',3,NULL,'2023-03-04 18:18:01','19:20','Name : Fahima Amzal, Contact : ',3,NULL,1,11,1),(8,'doctor','2023-03-05 15:32:19','doctor','2023-03-05 16:24:09',3,NULL,'2023-03-05 15:32:19','16:20','Name : Lina HALIMI, Contact : ',3,NULL,1,12,1),(9,'doctor','2023-03-05 16:31:48','doctor','2023-03-05 16:34:16',3,NULL,'2023-03-05 16:31:48','17:40','Name : Lina HALIMI, Contact : ',3,NULL,3,12,1),(10,'doctor','2023-03-05 18:45:12','doctor','2023-03-05 18:54:18',3,NULL,'2023-03-05 18:45:12','19:50','Name : Adem TALZAZIT, Contact : ',3,NULL,1,13,1),(11,'doctor','2023-03-05 18:55:47','doctor','2023-03-05 19:00:30',3,NULL,'2023-03-05 18:55:47','20:00','Name : Anas BAHRI, Contact : ',3,NULL,1,14,1),(12,'doctor','2023-03-05 19:02:26','doctor','2023-03-05 19:08:41',3,NULL,'2023-03-05 19:02:26','20:10','Name : Abdelmalek BEDDAL, Contact : ',3,NULL,1,15,1),(13,'doctor','2023-03-05 19:09:16','doctor','2023-03-05 19:10:01',3,NULL,'2023-03-05 19:09:16','20:20','Name : Adem TALZAZIT, Contact : ',3,NULL,3,13,1),(14,'doctor','2023-03-05 19:10:28','doctor','2023-03-06 12:06:49',3,NULL,'2023-03-05 19:10:28','20:30','Name : Adem TALZAZIT, Contact : ',3,NULL,3,13,1),(15,'doctor','2023-03-06 12:09:04','doctor','2023-03-06 12:13:46',3,NULL,'2023-03-06 12:09:04','13:10','Name : Abderrahim SAHI, Contact : ',3,NULL,1,16,1),(16,'doctor','2023-03-06 12:18:42','doctor','2023-03-06 12:22:03',3,NULL,'2023-03-06 12:18:42','13:20','Name : Miloud LASSAG, Contact : ',3,NULL,1,17,1),(17,'doctor','2023-03-06 14:39:12','doctor','2023-03-06 14:41:53',3,NULL,'2023-03-06 14:39:12','15:30','Name : Sara BOULAHLIB, Contact : ',3,NULL,1,18,1),(18,'doctor','2023-03-06 14:51:55','doctor','2023-03-06 14:52:45',3,NULL,'2023-03-06 14:51:55','15:50','Name : Sara BOULAHLIB, Contact : ',3,NULL,1,18,1),(19,'doctor','2023-03-07 08:56:35','doctor','2023-03-07 15:58:00',3,NULL,'2023-03-07 08:56:35','10:00','Name : Abderrahmane MOUSSAOUI, Contact : ',3,NULL,1,19,1),(20,'doctor','2023-03-07 16:00:27','doctor','2023-03-07 16:03:06',3,NULL,'2023-03-07 16:00:27','17:00','Name : Khalil Ibrahim LAYAICHA, Contact : ',3,NULL,1,20,1),(21,'doctor','2023-03-07 16:07:21','doctor','2023-03-07 16:20:16',3,NULL,'2023-03-07 16:07:21','17:10','Name : Zineb FELKOUNE, Contact : ',3,NULL,1,21,1),(22,'doctor','2023-03-08 08:01:46','doctor','2023-03-08 08:18:52',3,NULL,'2023-03-08 08:01:46','9:00','Name : Ishak MESSIOURI, Contact : ',3,NULL,1,22,1),(23,'doctor','2023-03-08 08:20:36','doctor','2023-03-08 08:23:39',3,NULL,'2023-03-08 08:20:36','9:20','Name : Walid LEKSIR, Contact : ',3,NULL,1,23,1),(24,'doctor','2023-03-08 09:04:12','doctor','2023-03-08 09:06:53',3,NULL,'2023-03-08 09:04:12','10:10','Name : Salim TAGUENIT, Contact : ',3,NULL,1,24,1),(25,'doctor','2023-03-09 09:36:41','doctor','2023-03-09 12:22:48',3,NULL,'2023-03-09 09:36:41','10:40','Name : Houdaifa MOKADEM, Contact : ',3,NULL,1,25,1),(26,'doctor','2023-03-09 10:29:33','doctor','2023-03-09 10:34:08',3,NULL,'2023-03-09 10:29:33','11:30','Name : Abderrahmane CHOUAL, Contact : ',3,NULL,1,26,1),(27,'doctor','2023-03-14 07:14:53','doctor','2023-03-14 07:16:13',3,NULL,'2023-03-14 07:14:53','8:20','Name : Nedjmeddine SBAHI, Contact : ',3,NULL,1,27,1),(28,'doctor','2023-03-14 07:17:13','doctor','2023-03-14 07:19:32',3,NULL,'2023-03-14 07:17:13','8:30','Name : Houssem KAMEL, Contact : ',3,NULL,1,28,1),(29,'doctor','2023-03-14 15:47:57','doctor','2023-03-14 15:49:46',3,NULL,'2023-03-14 15:47:57','16:50','Name : Mohamed yacine BENADASSI, Contact : ',3,NULL,1,29,1),(30,'doctor','2023-03-14 15:51:40','doctor','2023-03-14 15:54:22',3,NULL,'2023-03-14 15:51:40','17:00','Name : Abdessamad SEFRANI, Contact : 0542880186',3,NULL,1,30,1),(31,'doctor','2023-03-14 15:55:29','doctor','2023-03-14 15:57:06',3,NULL,'2023-03-14 15:55:29','17:10','Name : Haithem AMINI, Contact : ',3,NULL,1,31,1),(32,'doctor','2023-03-14 15:58:09','doctor','2023-03-14 16:03:17',3,NULL,'2023-03-14 15:58:09','17:20','Name : Samir BOUHMED, Contact : ',3,NULL,1,32,1),(33,'doctor','2023-03-14 16:05:22','doctor','2023-03-14 16:09:50',3,NULL,'2023-03-14 16:05:22','17:30','Name : Faysel KAOUAR , Contact : ',3,NULL,1,33,1),(34,'doctor','2023-03-14 16:11:04','doctor','2023-03-14 16:13:28',3,NULL,'2023-03-14 16:11:04','17:40','Name : Abderrahmane BELLARNEB, Contact : ',3,NULL,1,34,1),(35,'doctor','2023-03-16 08:58:14','doctor','2023-03-16 08:59:18',3,NULL,'2023-03-16 08:58:14','10:00','Name : Walid HAMEL, Contact : ',3,NULL,1,35,1),(36,'doctor','2023-03-16 09:00:10','doctor','2023-03-16 09:01:16',3,NULL,'2023-03-16 09:00:10','10:10','Name : Alaa MOKHTARI, Contact : ',3,NULL,1,36,1),(37,'doctor','2023-03-16 09:02:08','doctor','2023-03-16 09:03:23',3,NULL,'2023-03-16 09:02:08','10:20','Name : Dania MOKHTARI, Contact : ',3,NULL,1,37,1),(38,'doctor','2023-03-16 09:11:20','doctor','2023-03-16 10:45:46',3,NULL,'2023-03-16 09:11:20','10:30','Name : Zineb FELKOUNE, Contact : 0665797401',3,NULL,1,21,1),(39,'doctor','2023-03-16 10:46:22','doctor','2023-03-21 08:31:52',3,NULL,'2023-03-16 10:46:22','11:50','Name : Abdelmalek BEDDAL, Contact : ',3,NULL,1,15,1),(40,'doctor','2023-03-21 08:29:18','doctor','2023-03-21 10:40:52',3,NULL,'2023-03-21 08:29:18','9:30','Name : Lina ZOUATEN, Contact : ',3,NULL,1,38,1),(41,'doctor','2023-03-21 10:42:28','doctor','2023-03-21 10:44:20',3,NULL,'2023-03-21 10:42:28','11:40','Name : Mustapha RECHOUM, Contact : ',3,NULL,1,39,1),(42,'doctor','2023-03-21 10:45:17','doctor','2023-03-21 10:46:15',3,NULL,'2023-03-21 10:45:17','11:50','Name : Adem BELKADI, Contact : ',3,NULL,1,40,1),(43,'doctor','2023-03-21 11:03:45','doctor','2023-03-21 11:05:35',3,NULL,'2023-03-21 11:03:45','12:00','Name : Mohamed Islem MENSRIA, Contact : ',3,NULL,1,41,1),(44,'doctor','2023-03-21 15:58:17','doctor','2023-03-21 15:59:43',3,NULL,'2023-03-21 15:58:17','17:00','Name : Abdelbasset ACHOUI, Contact : ',3,NULL,1,42,1),(45,'doctor','2023-03-21 16:00:52','doctor','2023-03-21 16:02:04',3,NULL,'2023-03-21 16:00:52','17:10','Name : Med Yacine KERIKECHE , Contact : ',3,NULL,1,43,1),(46,'doctor','2023-03-21 16:03:05','doctor','2023-03-21 16:05:30',3,NULL,'2023-03-21 16:03:05','17:20','Name : Noreddine KHALOUFI, Contact : ',3,NULL,1,44,1),(47,'doctor','2023-03-21 16:06:35','doctor','2023-03-21 16:08:07',3,NULL,'2023-03-21 16:06:35','17:30','Name : Med Houcine MEHSAS, Contact : ',3,NULL,1,45,1),(48,'doctor','2023-03-21 16:10:07','doctor','2023-03-21 16:11:25',3,NULL,'2023-03-21 16:10:07','17:40','Name : Rouaia ZEGAR, Contact : ',3,NULL,1,47,1),(49,'doctor','2023-03-21 16:12:44','doctor','2023-03-21 16:15:48',3,NULL,'2023-03-21 16:12:44','17:50','Name : Sohaib Abderraouf SAIDI, Contact : ',3,NULL,1,48,1),(50,'doctor','2023-03-21 16:17:40','doctor','2023-03-21 16:21:12',3,NULL,'2023-03-21 16:17:40','18:00','Name : Adem CHORFA, Contact : ',3,NULL,1,49,1),(51,'doctor','2023-03-21 16:22:20','doctor','2023-03-21 16:24:22',3,NULL,'2023-03-21 16:22:20','18:10','Name : Med OSMANI, Contact : ',3,NULL,1,50,1),(52,'doctor','2023-03-21 16:25:23','doctor','2023-03-21 16:27:49',3,NULL,'2023-03-21 16:25:23','18:20','Name : Iyad GRIBICI, Contact : ',3,NULL,1,51,1),(53,'doctor','2023-03-22 15:05:38','doctor','2023-03-22 15:09:10',3,NULL,'2023-03-22 15:05:38','16:10','Name : Ali HADJ AOUDIA, Contact : ',3,NULL,1,52,1),(54,'doctor','2023-03-22 15:20:11','doctor','2023-03-23 14:30:49',3,NULL,'2023-03-22 15:20:11','16:20','Name : Youcef MOUDRIS , Contact : ',3,NULL,1,53,1),(55,'doctor','2023-03-23 14:28:38','doctor','2023-03-23 14:33:40',3,NULL,'2023-03-23 14:28:38','15:30','Name : Younes LAKSIR, Contact : ',3,NULL,1,54,1),(56,'doctor','2023-03-25 09:36:01','doctor','2023-03-25 09:38:00',3,NULL,'2023-03-25 09:36:01','10:40','Name : Anas MEZLIOUI, Contact : ',3,NULL,1,55,1),(57,'doctor','2023-03-25 13:28:43','doctor','2023-03-25 14:46:19',3,NULL,'2023-03-25 13:28:43','10:50','Name : Marouane ZIDI ALLAL, Contact : ',3,NULL,1,56,1),(58,'doctor','2023-03-25 14:47:11','doctor','2023-03-25 14:49:58',3,NULL,'2023-03-25 14:47:11','15:50','Name : Maroua ZIDI ALLAL, Contact : ',3,NULL,1,57,1),(59,'doctor','2023-03-25 14:51:14','doctor','2023-03-25 14:52:19',3,NULL,'2023-03-25 14:51:14','16:00','Name : Wail BOUCHTEB, Contact : ',3,NULL,1,58,1),(60,'doctor','2023-03-25 14:53:13','doctor','2023-03-25 14:53:54',3,NULL,'2023-03-25 14:53:13','16:10','Name : Akram DJEMAI, Contact : ',3,NULL,1,59,1),(61,'doctor','2023-03-29 08:10:18','doctor','2023-03-29 08:12:22',3,NULL,'2023-03-29 08:10:18','9:10','Name : Younes CHIKH, Contact : ',3,NULL,1,60,1);
/*!40000 ALTER TABLE `appointment` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-03 18:09:07
