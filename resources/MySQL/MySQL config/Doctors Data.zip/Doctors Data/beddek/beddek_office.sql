CREATE DATABASE  IF NOT EXISTS `beddek` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `beddek`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: mcm-prod.chwkfp078t9a.eu-west-3.rds.amazonaws.com    Database: beddek
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `office`
--

DROP TABLE IF EXISTS `office`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `office` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_by` varchar(255) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `last_modified_date` timestamp NULL DEFAULT NULL,
  `version` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `logo` mediumtext,
  `fax` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `include_header_image` bit(1) NOT NULL DEFAULT b'0',
  `header_include_office_logo` bit(1) NOT NULL DEFAULT b'0',
  `header_image` mediumtext,
  `header_include_office_name` bit(1) NOT NULL DEFAULT b'0',
  `header_include_office_address` bit(1) NOT NULL DEFAULT b'0',
  `header_include_office_email` bit(1) NOT NULL DEFAULT b'0',
  `header_include_office_phone` bit(1) NOT NULL DEFAULT b'0',
  `header_include_office_fax` bit(1) NOT NULL DEFAULT b'0',
  `header_customize_text` bit(1) NOT NULL DEFAULT b'0',
  `include_footer_image` bit(1) NOT NULL DEFAULT b'0',
  `footer_include_office_logo` bit(1) NOT NULL DEFAULT b'0',
  `footer_image` mediumtext,
  `footer_include_office_name` bit(1) NOT NULL DEFAULT b'0',
  `footer_include_office_address` bit(1) NOT NULL DEFAULT b'0',
  `footer_include_office_email` bit(1) NOT NULL DEFAULT b'0',
  `footer_include_office_phone` bit(1) NOT NULL DEFAULT b'0',
  `footer_include_office_fax` bit(1) NOT NULL DEFAULT b'0',
  `footer_customize_text` bit(1) NOT NULL DEFAULT b'0',
  `enable_digital_signature` bit(1) NOT NULL DEFAULT b'0',
  `generate_barcode` bit(1) NOT NULL DEFAULT b'0',
  `use_initial_checkup` bit(1) NOT NULL DEFAULT b'0',
  `use_cat` bit(1) NOT NULL DEFAULT b'1',
  `use_exam` bit(1) NOT NULL DEFAULT b'0',
  `auto_add_exam_as_article` bit(1) NOT NULL DEFAULT b'0',
  `date_format` varchar(255) DEFAULT NULL,
  `time_format` varchar(255) DEFAULT NULL,
  `file_extensions` varchar(255) DEFAULT NULL,
  `file_path` varchar(255) DEFAULT 'c:/MCM/',
  `pin_authentication_activated` bit(1) NOT NULL DEFAULT b'0',
  `db_export_ability` bit(1) NOT NULL DEFAULT b'0',
  `session_expiration_duration` bit(1) NOT NULL DEFAULT b'0',
  `start_time` varchar(255) DEFAULT NULL,
  `appointment_period` bigint NOT NULL DEFAULT '0',
  `end_time` varchar(255) DEFAULT NULL,
  `last_update` datetime NOT NULL,
  `updated_by` varchar(255) NOT NULL,
  `use_fever` bit(1) NOT NULL DEFAULT b'0',
  `use_pulse` bit(1) NOT NULL DEFAULT b'0',
  `use_blood_pressure` bit(1) NOT NULL DEFAULT b'1',
  `use_respiratory_rate` bit(1) NOT NULL DEFAULT b'0',
  `use_oxygen_saturation` bit(1) NOT NULL DEFAULT b'0',
  `use_weight` bit(1) NOT NULL DEFAULT b'1',
  `use_height` bit(1) NOT NULL DEFAULT b'1',
  `use_bmi` bit(1) NOT NULL DEFAULT b'1',
  `use_pain` bit(1) NOT NULL DEFAULT b'0',
  `use_pregnancy_month` bit(1) NOT NULL DEFAULT b'0',
  `use_other` bit(1) NOT NULL DEFAULT b'0',
  `use_rth` bit(1) NOT NULL DEFAULT b'0',
  `use_cranial_circumference` bit(1) NOT NULL DEFAULT b'0',
  `use_shoe_size` bit(1) NOT NULL DEFAULT b'0',
  `display_title` bit(1) NOT NULL DEFAULT b'0',
  `display_patient_infos` bit(1) NOT NULL DEFAULT b'0',
  `header_height` int DEFAULT NULL,
  `footer_height` int DEFAULT NULL,
  `use_payment` bit(1) NOT NULL DEFAULT b'1',
  `speciality` varchar(255) DEFAULT NULL,
  `commune` varchar(255) DEFAULT NULL,
  `wilaya` varchar(255) DEFAULT NULL,
  `show_divider` bit(1) NOT NULL DEFAULT b'1',
  `use_auto_terminate_visits` bit(1) NOT NULL DEFAULT b'0',
  `use_appointment_time` bit(1) NOT NULL DEFAULT b'1',
  `use_lite_mode` bit(1) NOT NULL DEFAULT b'0',
  `use_glycemia` bit(1) NOT NULL DEFAULT b'0',
  `only_lite_mode` bit(1) NOT NULL DEFAULT b'0',
  `use_growth_charts` bit(1) NOT NULL DEFAULT b'0',
  `use_flexible_payment` bit(1) NOT NULL DEFAULT b'0',
  `dynamic_vital_signs` longtext,
  `display_date` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `office`
--

LOCK TABLES `office` WRITE;
/*!40000 ALTER TABLE `office` DISABLE KEYS */;
INSERT INTO `office` VALUES (1,NULL,NULL,'doctor','2023-03-05 12:59:39',12,'Cabinet BEDDEK Zahir','zahirbeddek@gmail.com','0550036510','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsQAAA7EAZUrDhsAAAdKSURBVFhHlVcJT1RXFJ4f0LhgEGZgEFNTa1VQQYFh01rRuoFYjUJBBcGFgWF3idVoSF2qWK02thorNXFBRUGIEmVxIVIldV+IiKbiglgUZREZ+HrOffOY99ikh5zcN+/de853z46mDcDN+4+xfMUWuH1rhHZcJPqNioSdpxFOfolwHp+CQeOT4eRPzOvXKdD7J2Kg+2I4eyzAnyeKSQLQ1taG1tZW8Xz0XiVCss7ju5wLCMq91CNrzHRIOkZAHtXgp305CDFth2dQKnTu4eg7fA76u4TAxjVUcB/67eS5EIGRG5BTfAstdI5UEwCWwE/A/cZmmHIKMTu7EIF5lyVleZ2VM2v4WEdqImG3Kp4iu6gUuw4VYt2ObKRsOoxVWzOxbf9Z5BWX4VVdg9gr31omMyFhUCcfVGLekTzMzilGMCkKzr2MWcwESMmaDbuzsHlvHvYcvYjj5+/g6oPXeGdmEVb6SNxMoHhVkrnFbHkiYgsIK9B74rfEmXcrsfREPuacLMRM4uk5RZh++gKtxKeKMfVUETQ6jyXQeUZD77UEzt5LMMQ3EuOmGRG37necLbmFfxs+CKGtrZIyXs1mM60WbTLJABQg2EY365uw5+9yrD5fgoT8SzCeuYhY4qRzJVhZUAKNo088HH1McPCJg4N3HHTesbA3xMB2XBRsx4RhbsxWXLv7WBJKimXioOuJ+Cs7h0/wcz1x1YcWPHzfiEoC9Yo+NtE7jYNPAilXciJ0volw8EuiyE+CrdtCjAow4kzJbdoOtCjNrqAe4VgyRB0tEnUBQM2cgnZjI+EVlIhbj56LQx0Dj4kBCBBdWIYzTaZGerxZ8RL7jhVg9ZY/Pg2AeTDl/mdfzUfaruNCiNIVMnUHQN5bQ6bPyL6KiSFr4ewTBT3Fm9YjqhcAvMkK/inoPyYKi1fuxnvyI1PHGOh8b6u7rj98gSlha2A7OpQKXAy0JFNLrnYgV6sAONIH5vZ3tEFPGwf5JcOGACxM2oG3Dc1CaE9ByF9ksz9++QbewamwGRUO5wnJcPRVyCdWACBEig8OlB0OIjsSqBynos/IcKzcfFAIbW3jyicpkEpwmwoQP/IvttWKTRno5xIm3KiWn0AZF987AI6UooN9lyG7oEwoYL8yADYxqRbvmFpaWgQQGUzlixoYAkmOwUg3T1LItrLGnhQLf3TxkVlP5h/oFomwhHQ08s1IsWReSQlXyKfVteQaa500myXrVD5/Bc8ZJugMsQQgUWV+nWXVyA9q5ttTgaJDWoMJQ/yW4tyVe0LoR0tgvXjXiu0HziAkLh3TFm1AcPRG/EhlvbqOy4tEVa/fYEroGuqwy+kikgV0BEKps5ssYNPHi3bMNWDVtqOSTy2BlVN0gwIrGfZULfu4LqKquYyyJBo2Lt9jXswWPK2pE/sYatovWeg7IkzEEcvWMgCFJboGQMHBvd/WPQKTQlbjdSP7WqLfjhTgc18q0zQP6P1oH80JfDsnSlVnOtOPWndy2gF8sLjhrztPMPwbcoNXTLsVlNwlACcaQmzdI+ESEINr958JQQyAlTt5RJBPWRilVKeziQSEbjh6Hq7clvoHn1u/87joKxIAdbypAHCQONG0M2B0BMbOSEDpnadCCNOx/DI4e7FyIwmShIi6QavSpyxDOzYKsesz2mv/u+YWzI/bSn0lgs5a9zK3A2Cheko329HhCJi/CuXPJD8y3X5cC5fJsdB6LqW4UJvR2k2t77SGODK7kYrQe4sEypTaRkxduJZARAq3ydYTAHjus6e5wNmwGGt/zkSdJaM+Ur7XUzUJi9+GgRSMeuqOOpEhPQNgi+gN0dibWSDJsWROVW0TZkakYYBrGF2ErUWleBCZvL/rAoyYHI9DuaViI5Ncx389XAT7sWQ6UsLRa6+I4O6Yiw4DDjVtFDK4Lsgd9OWbBixesZOyS4oljd49FBGpu3G94pXYIBUaKeafVHMdT4Gdx3KBllOzowWsbA0uBsBZ4j93BWqpdYhRlUTK/YG7ye5D5zDMPwKajKxi0aOZ5NbJJZVp1ZaDGEhNhH0mCbeW584sA+AClgS7cdEwBK1EeZUUB22WSylng9Lb/1inYrl8yuuNiudwD6TYoMBTVjEuJGrFnZmtZe+xDG7TknH1fuchRjQwS7/Q0K/25sEkA9i+/zT6jAgVxUUWzMGlrGKSRZS/JRYl3Gs5RgQkoOBahZDX5RBDelX/F8goH1VVw2smzYZccHyS1DOCimmQ7QKE1ENiMGyiCbmX7gqZrZaLdSSNfHte5R5/MLcMNiPn0jyorlpsAbULpJ6h3MPMABj80AkmnCq8KWTKlu1I7QBkqqf0m70sXdQFR1+18P8HwIgvJsQh6/wNIbdbAJaVQ0HQ9fJnsHNbIIR05+NPsQxgKAE4WdBLAHJU/pB+CDqPpTQPKvp3LyJfybILvpwYh9MXpP8nPm0B+quj9PeeFU8DhBUAm7w3qadkBqCl9jt8Ujzyr5QL+V0HIfAfZhbj9gHqF6oAAAAASUVORK5CYII=',NULL,'OULED MOUSSA EN FACE DE LAGENDARMERIE WILAYA DE BOUMERDES',NULL,_binary '\0',_binary '',NULL,_binary '',_binary '\0',_binary '',_binary '',_binary '\0',_binary '\0',_binary '\0',_binary '\0',NULL,_binary '\0',_binary '\0',_binary '\0',_binary '\0',_binary '\0',_binary '\0',_binary '\0',_binary '\0',_binary '',_binary '',_binary '\0',_binary '\0',NULL,NULL,NULL,'c:/MCM/',_binary '\0',_binary '\0',_binary '\0','2021-02-19T07:00:00.000Z',10,'2021-02-21T21:40:00.000Z','2023-03-05 12:59:38','Zahir Beddek',_binary '\0',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '',_binary '',_binary '',_binary '\0',_binary '\0',_binary '\0',_binary '\0',_binary '\0',_binary '\0',_binary '',_binary '',NULL,NULL,_binary '\0','ORL','35020','35',_binary '',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0',_binary '\0',_binary '\0',NULL,_binary '\0');
/*!40000 ALTER TABLE `office` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-03 18:07:57
