CREATE DATABASE  IF NOT EXISTS `beddek` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `beddek`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: mcm-prod.chwkfp078t9a.eu-west-3.rds.amazonaws.com    Database: beddek
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `visit_history`
--

DROP TABLE IF EXISTS `visit_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `visit_history` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_by` varchar(255) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `last_modified_date` timestamp NULL DEFAULT NULL,
  `version` int DEFAULT NULL,
  `diseases` longtext,
  `complementary_exams` longtext,
  `visit_medicaments` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visit_history`
--

LOCK TABLES `visit_history` WRITE;
/*!40000 ALTER TABLE `visit_history` DISABLE KEYS */;
INSERT INTO `visit_history` VALUES (1,'doctor','2023-02-27 20:29:57','doctor','2023-02-27 20:29:57',0,'[{\"version\":0,\"createdBy\":\"doctor\",\"creationDate\":\"2023-02-27T20:23:00\",\"lastModifiedBy\":\"doctor\",\"lastModifiedDate\":\"2023-02-27T20:23:00\",\"id\":1,\"designation\":\"Angine\",\"date\":\"2023-02-27\",\"status\":\"ACTIVE\",\"note\":null,\"doctor\":\"Beddek Zahir\"}]','[{\"version\":0,\"createdBy\":\"doctor\",\"creationDate\":\"2023-02-27T20:23:29\",\"lastModifiedBy\":\"doctor\",\"lastModifiedDate\":\"2023-02-27T20:23:29\",\"id\":1,\"type\":\"SEROLOGY\",\"designation\":\"FNS\",\"normalRange\":null,\"unit\":null,\"results\":null,\"date\":\"2023-02-27\",\"approved\":false,\"status\":\"ACTIVE\",\"note\":null,\"attachment\":null,\"doctor\":\"Beddek Zahir\"}]','[{\"version\":0,\"createdBy\":\"doctor\",\"creationDate\":\"2023-02-27T20:24:54\",\"lastModifiedBy\":\"doctor\",\"lastModifiedDate\":\"2023-02-27T20:24:54\",\"id\":2,\"medicament\":\"MAXILASE\",\"quantity\":1,\"dosage\":\"200 U.CEIP/ ML\",\"note\":\"\",\"date\":\"2023-02-27\",\"form\":\"Sirop\",\"compact\":\"\",\"direction\":\"1/2 /J\",\"duration\":\"\",\"sponsored\":true,\"status\":\"ACTIVE\",\"doctor\":\"Beddek Zahir\"},{\"version\":0,\"createdBy\":\"doctor\",\"creationDate\":\"2023-02-27T20:26:03\",\"lastModifiedBy\":\"doctor\",\"lastModifiedDate\":\"2023-02-27T20:26:03\",\"id\":3,\"medicament\":\"EXTENCILLINE\",\"quantity\":1,\"dosage\":\"1 200 000UI\",\"note\":\"\",\"date\":\"2023-02-27\",\"form\":\"Pdre. Inj.\",\"compact\":\"\",\"direction\":\"1/2 /J\",\"duration\":\"\",\"sponsored\":false,\"status\":\"ACTIVE\",\"doctor\":\"Beddek Zahir\"}]'),(2,'doctor','2023-02-27 20:34:41','doctor','2023-02-27 20:34:41',0,'[{\"version\":0,\"createdBy\":\"doctor\",\"creationDate\":\"2023-02-27T20:32:57\",\"lastModifiedBy\":\"doctor\",\"lastModifiedDate\":\"2023-02-27T20:32:57\",\"id\":3,\"designation\":\"Angine\",\"date\":\"2023-02-27\",\"status\":\"ACTIVE\",\"note\":null,\"doctor\":\"Beddek Zahir\"},{\"version\":0,\"createdBy\":\"doctor\",\"creationDate\":\"2023-02-27T20:32:57\",\"lastModifiedBy\":\"doctor\",\"lastModifiedDate\":\"2023-02-27T20:32:57\",\"id\":4,\"designation\":\"Adénocarcinome peu différencié du cæcum\",\"date\":\"2023-02-27\",\"status\":\"ACTIVE\",\"note\":null,\"doctor\":\"Beddek Zahir\"}]','[{\"version\":0,\"createdBy\":\"doctor\",\"creationDate\":\"2023-02-27T20:32:58\",\"lastModifiedBy\":\"doctor\",\"lastModifiedDate\":\"2023-02-27T20:32:58\",\"id\":3,\"type\":\"IMAGERY\",\"designation\":\"Radiographie de face de la hanche droite\",\"normalRange\":null,\"unit\":null,\"results\":null,\"date\":\"2023-02-27\",\"approved\":false,\"status\":\"ACTIVE\",\"note\":null,\"attachment\":null,\"doctor\":\"Beddek Zahir\"},{\"version\":0,\"createdBy\":\"doctor\",\"creationDate\":\"2023-02-27T20:33:18\",\"lastModifiedBy\":\"doctor\",\"lastModifiedDate\":\"2023-02-27T20:33:18\",\"id\":5,\"type\":\"SEROLOGY\",\"designation\":\"Acide urique\",\"normalRange\":null,\"unit\":null,\"results\":null,\"date\":\"2023-02-27\",\"approved\":false,\"status\":\"ACTIVE\",\"note\":null,\"attachment\":null,\"doctor\":\"Beddek Zahir\"}]','[{\"version\":0,\"createdBy\":\"doctor\",\"creationDate\":\"2023-02-27T20:32:58\",\"lastModifiedBy\":\"doctor\",\"lastModifiedDate\":\"2023-02-27T20:32:58\",\"id\":5,\"medicament\":\"MAXILASE\",\"quantity\":1,\"dosage\":\"200 U.CEIP/ ML\",\"note\":\"\",\"date\":\"2023-02-27\",\"form\":\"Sirop\",\"compact\":\"\",\"direction\":\"1/2 /J\",\"duration\":\"\",\"sponsored\":true,\"status\":\"ACTIVE\",\"doctor\":\"Beddek Zahir\"},{\"version\":0,\"createdBy\":\"doctor\",\"creationDate\":\"2023-02-27T20:32:58\",\"lastModifiedBy\":\"doctor\",\"lastModifiedDate\":\"2023-02-27T20:32:58\",\"id\":6,\"medicament\":\"EXTENCILLINE\",\"quantity\":1,\"dosage\":\"1 200 000UI\",\"note\":\"\",\"date\":\"2023-02-27\",\"form\":\"Pdre. Inj.\",\"compact\":\"\",\"direction\":\"1/2 /J\",\"duration\":\"\",\"sponsored\":false,\"status\":\"ACTIVE\",\"doctor\":\"Beddek Zahir\"},{\"version\":0,\"createdBy\":\"doctor\",\"creationDate\":\"2023-02-27T20:32:58\",\"lastModifiedBy\":\"doctor\",\"lastModifiedDate\":\"2023-02-27T20:32:58\",\"id\":7,\"medicament\":\"CATAFLAM\",\"quantity\":1,\"dosage\":\"50 MG\",\"note\":\"\",\"date\":\"2023-02-27\",\"form\":\"Cp.\",\"compact\":\"\",\"direction\":\"1/2 /J\",\"duration\":\"\",\"sponsored\":false,\"status\":\"ACTIVE\",\"doctor\":\"Beddek Zahir\"}]'),(3,'doctor','2023-02-27 20:35:25','doctor','2023-02-27 20:35:25',0,'[{\"version\":1,\"createdBy\":\"doctor\",\"creationDate\":\"2023-02-27T20:23:00\",\"lastModifiedBy\":\"doctor\",\"lastModifiedDate\":\"2023-02-27T20:29:57\",\"id\":1,\"designation\":\"Angine\",\"date\":\"2023-02-27\",\"status\":\"ACTIVE\",\"note\":null,\"doctor\":\"Beddek Zahir\"},{\"version\":0,\"createdBy\":\"doctor\",\"creationDate\":\"2023-02-27T20:30:33\",\"lastModifiedBy\":\"doctor\",\"lastModifiedDate\":\"2023-02-27T20:30:33\",\"id\":2,\"designation\":\"Adénocarcinome peu différencié du cæcum\",\"date\":\"2023-02-27\",\"status\":\"ACTIVE\",\"note\":null,\"doctor\":\"Beddek Zahir\"}]','[{\"version\":1,\"createdBy\":\"doctor\",\"creationDate\":\"2023-02-27T20:23:29\",\"lastModifiedBy\":\"doctor\",\"lastModifiedDate\":\"2023-02-27T20:29:57\",\"id\":1,\"type\":\"SEROLOGY\",\"designation\":\"FNS\",\"normalRange\":null,\"unit\":null,\"results\":null,\"date\":\"2023-02-27\",\"approved\":false,\"status\":\"ACTIVE\",\"note\":null,\"attachment\":null,\"doctor\":\"Beddek Zahir\"},{\"version\":0,\"createdBy\":\"doctor\",\"creationDate\":\"2023-02-27T20:30:44\",\"lastModifiedBy\":\"doctor\",\"lastModifiedDate\":\"2023-02-27T20:30:44\",\"id\":2,\"type\":\"IMAGERY\",\"designation\":\"Radiographie de face de la hanche droite\",\"normalRange\":null,\"unit\":null,\"results\":null,\"date\":\"2023-02-27\",\"approved\":false,\"status\":\"ACTIVE\",\"note\":null,\"attachment\":null,\"doctor\":\"Beddek Zahir\"}]','[{\"version\":1,\"createdBy\":\"doctor\",\"creationDate\":\"2023-02-27T20:24:54\",\"lastModifiedBy\":\"doctor\",\"lastModifiedDate\":\"2023-02-27T20:29:57\",\"id\":2,\"medicament\":\"MAXILASE\",\"quantity\":1,\"dosage\":\"200 U.CEIP/ ML\",\"note\":\"\",\"date\":\"2023-02-27\",\"form\":\"Sirop\",\"compact\":\"\",\"direction\":\"1/2 /J\",\"duration\":\"\",\"sponsored\":true,\"status\":\"ACTIVE\",\"doctor\":\"Beddek Zahir\"},{\"version\":1,\"createdBy\":\"doctor\",\"creationDate\":\"2023-02-27T20:26:03\",\"lastModifiedBy\":\"doctor\",\"lastModifiedDate\":\"2023-02-27T20:29:57\",\"id\":3,\"medicament\":\"EXTENCILLINE\",\"quantity\":1,\"dosage\":\"1 200 000UI\",\"note\":\"\",\"date\":\"2023-02-27\",\"form\":\"Pdre. Inj.\",\"compact\":\"\",\"direction\":\"1/2 /J\",\"duration\":\"\",\"sponsored\":false,\"status\":\"ACTIVE\",\"doctor\":\"Beddek Zahir\"},{\"version\":0,\"createdBy\":\"doctor\",\"creationDate\":\"2023-02-27T20:30:59\",\"lastModifiedBy\":\"doctor\",\"lastModifiedDate\":\"2023-02-27T20:30:59\",\"id\":4,\"medicament\":\"CATAFLAM\",\"quantity\":1,\"dosage\":\"50 MG\",\"note\":\"\",\"date\":\"2023-02-27\",\"form\":\"Cp.\",\"compact\":\"\",\"direction\":\"1/2 /J\",\"duration\":\"\",\"sponsored\":false,\"status\":\"ACTIVE\",\"doctor\":\"Beddek Zahir\"}]'),(4,'doctor','2023-03-05 16:31:49','doctor','2023-03-05 16:31:49',0,'[{\"version\":0,\"createdBy\":\"doctor\",\"creationDate\":\"2023-03-05T15:35:55\",\"lastModifiedBy\":\"doctor\",\"lastModifiedDate\":\"2023-03-05T15:35:55\",\"id\":9,\"designation\":\"Hypertrophie des végétations adénoïdes\",\"date\":\"2023-03-05\",\"status\":\"ACTIVE\",\"note\":null,\"doctor\":\"Beddek Zahir\"}]','[]','[]'),(5,'doctor','2023-03-05 19:09:16','doctor','2023-03-05 19:09:16',0,'[{\"version\":0,\"createdBy\":\"doctor\",\"creationDate\":\"2023-03-05T18:53:08\",\"lastModifiedBy\":\"doctor\",\"lastModifiedDate\":\"2023-03-05T18:53:08\",\"id\":11,\"designation\":\"VG 27\",\"date\":\"2023-03-05\",\"status\":\"ACTIVE\",\"note\":null,\"doctor\":\"Beddek Zahir\"}]','[{\"version\":0,\"createdBy\":\"doctor\",\"creationDate\":\"2023-03-05T18:53:58\",\"lastModifiedBy\":\"doctor\",\"lastModifiedDate\":\"2023-03-05T18:53:58\",\"id\":8,\"type\":\"IMAGERY\",\"designation\":\"nasofibroscopie\",\"normalRange\":null,\"unit\":null,\"results\":null,\"date\":\"2023-03-05\",\"approved\":false,\"status\":\"ACTIVE\",\"note\":null,\"attachment\":null,\"doctor\":\"Beddek Zahir\"}]','[]'),(6,'doctor','2023-03-05 19:10:28','doctor','2023-03-05 19:10:28',0,'[{\"version\":1,\"createdBy\":\"doctor\",\"creationDate\":\"2023-03-05T18:53:08\",\"lastModifiedBy\":\"doctor\",\"lastModifiedDate\":\"2023-03-05T19:09:16\",\"id\":11,\"designation\":\"VG 27\",\"date\":\"2023-03-05\",\"status\":\"ACTIVE\",\"note\":null,\"doctor\":\"Beddek Zahir\"}]','[{\"version\":1,\"createdBy\":\"doctor\",\"creationDate\":\"2023-03-05T18:53:58\",\"lastModifiedBy\":\"doctor\",\"lastModifiedDate\":\"2023-03-05T19:09:16\",\"id\":8,\"type\":\"IMAGERY\",\"designation\":\"nasofibroscopie\",\"normalRange\":null,\"unit\":null,\"results\":null,\"date\":\"2023-03-05\",\"approved\":false,\"status\":\"ACTIVE\",\"note\":null,\"attachment\":null,\"doctor\":\"Beddek Zahir\"}]','[]');
/*!40000 ALTER TABLE `visit_history` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-03 18:09:34
