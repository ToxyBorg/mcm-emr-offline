CREATE DATABASE  IF NOT EXISTS `beddek` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `beddek`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: mcm-prod.chwkfp078t9a.eu-west-3.rds.amazonaws.com    Database: beddek
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `complementary_exam`
--

DROP TABLE IF EXISTS `complementary_exam`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `complementary_exam` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_by` varchar(255) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `last_modified_date` timestamp NULL DEFAULT NULL,
  `version` int DEFAULT NULL,
  `designation` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `normal_range` varchar(255) DEFAULT NULL,
  `unit` varchar(255) DEFAULT NULL,
  `results` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `approved` bit(1) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `note` text,
  `doctor` varchar(255) DEFAULT NULL,
  `attachment` mediumtext,
  `patient_id` bigint NOT NULL,
  `visit_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_complementary_exam_patient` (`patient_id`),
  KEY `FK_complementary_exam_visit` (`visit_id`),
  CONSTRAINT `FK_complementary_exam_patient` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`id`),
  CONSTRAINT `FK_complementary_exam_visit` FOREIGN KEY (`visit_id`) REFERENCES `visit` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `complementary_exam`
--

LOCK TABLES `complementary_exam` WRITE;
/*!40000 ALTER TABLE `complementary_exam` DISABLE KEYS */;
INSERT INTO `complementary_exam` VALUES (3,'doctor','2023-02-27 20:32:58','doctor','2023-02-27 20:34:41',1,'Radiographie de face de la hanche droite','IMAGERY',NULL,NULL,NULL,'2023-02-27',_binary '\0','ACTIVE',NULL,'Beddek Zahir',NULL,2,4),(5,'doctor','2023-02-27 20:33:18','doctor','2023-02-27 20:40:35',3,'Acide urique','SEROLOGY','12','12','12','2023-02-27',_binary '','ACTIVE',NULL,'Beddek Zahir',NULL,2,4),(6,'doctor','2023-02-27 20:54:22','doctor','2023-02-27 20:54:22',0,'Radiographie de face de la hanche droite','IMAGERY',NULL,NULL,NULL,'2023-02-27',_binary '\0','ACTIVE',NULL,'Beddek Zahir',NULL,1,6),(7,'doctor','2023-02-27 20:54:22','doctor','2023-02-27 20:54:22',0,'FNS','SEROLOGY',NULL,NULL,NULL,'2023-02-27',_binary '\0','ACTIVE',NULL,'Beddek Zahir',NULL,1,6),(8,'doctor','2023-03-05 18:53:58','doctor','2023-03-05 19:10:29',2,'nasofibroscopie','IMAGERY',NULL,NULL,NULL,'2023-03-05',_binary '\0','ACTIVE',NULL,'Beddek Zahir',NULL,13,14),(9,'doctor','2023-03-05 19:00:10','doctor','2023-03-05 19:00:10',0,'nasofibroscopie','IMAGERY',NULL,NULL,NULL,'2023-03-05',_binary '\0','ACTIVE',NULL,'Beddek Zahir',NULL,14,11),(10,'doctor','2023-03-05 19:04:38','doctor','2023-03-05 19:04:38',0,'nasofibroscopie','IMAGERY',NULL,NULL,NULL,'2023-03-05',_binary '\0','ACTIVE',NULL,'Beddek Zahir',NULL,15,12),(11,'doctor','2023-03-07 16:02:29','doctor','2023-03-07 16:02:29',0,'nasofibroscopie','IMAGERY',NULL,NULL,NULL,'2023-03-07',_binary '\0','ACTIVE',NULL,'Beddek Zahir',NULL,20,20),(12,'doctor','2023-03-07 16:14:51','doctor','2023-03-07 16:14:51',0,'nasofibroscopie Dr BOUTER','IMAGERY',NULL,NULL,NULL,'2023-03-07',_binary '\0','ACTIVE',NULL,'Beddek Zahir',NULL,21,21),(13,'doctor','2023-03-14 15:53:40','doctor','2023-03-14 15:53:40',0,'Radio du cavum','IMAGERY',NULL,NULL,NULL,'2023-03-14',_binary '\0','ACTIVE',NULL,'Beddek Zahir',NULL,30,30),(14,'doctor','2023-03-14 15:56:36','doctor','2023-03-14 15:56:36',0,'nasofibroscopie','IMAGERY',NULL,NULL,NULL,'2023-03-14',_binary '\0','ACTIVE',NULL,'Beddek Zahir',NULL,31,31),(15,'doctor','2023-03-14 15:59:06','doctor','2023-03-14 15:59:06',0,'nasofibroscopie','IMAGERY',NULL,NULL,NULL,'2023-03-14',_binary '\0','ACTIVE',NULL,'Beddek Zahir',NULL,32,32),(16,'doctor','2023-03-14 16:12:42','doctor','2023-03-14 16:12:42',0,'nasofibroscopie Dr ZEFFANE','IMAGERY',NULL,NULL,NULL,'2023-03-14',_binary '\0','ACTIVE',NULL,'Beddek Zahir',NULL,34,34),(17,'doctor','2023-03-16 09:01:08','doctor','2023-03-16 09:01:08',0,'nasofibroscopie','IMAGERY',NULL,NULL,NULL,'2023-03-16',_binary '\0','ACTIVE',NULL,'Beddek Zahir',NULL,36,36),(18,'doctor','2023-03-16 09:03:17','doctor','2023-03-16 09:03:17',0,'nasofibroscopie','IMAGERY',NULL,NULL,NULL,'2023-03-16',_binary '\0','ACTIVE',NULL,'Beddek Zahir',NULL,37,37),(19,'doctor','2023-03-21 10:40:46','doctor','2023-03-21 10:40:46',0,'nasofibroscopie','IMAGERY',NULL,NULL,NULL,'2023-03-21',_binary '\0','ACTIVE',NULL,'Beddek Zahir',NULL,38,40),(20,'doctor','2023-03-21 10:42:43','doctor','2023-03-21 10:42:43',0,'nasofibroscopie','IMAGERY',NULL,NULL,NULL,'2023-03-21',_binary '\0','ACTIVE',NULL,'Beddek Zahir',NULL,39,41),(21,'doctor','2023-03-21 10:45:48','doctor','2023-03-21 10:45:48',0,'nasofibroscopie','IMAGERY',NULL,NULL,NULL,'2023-03-21',_binary '\0','ACTIVE',NULL,'Beddek Zahir',NULL,40,42),(22,'doctor','2023-03-21 11:04:41','doctor','2023-03-21 11:04:41',0,'nasofibroscopie','IMAGERY',NULL,NULL,NULL,'2023-03-21',_binary '\0','ACTIVE',NULL,'Beddek Zahir',NULL,41,43),(23,'doctor','2023-03-21 16:02:00','doctor','2023-03-21 16:02:00',0,'nasofibroscopie','IMAGERY',NULL,NULL,NULL,'2023-03-21',_binary '\0','ACTIVE',NULL,'Beddek Zahir',NULL,43,45),(24,'doctor','2023-03-21 16:04:38','doctor','2023-03-21 16:04:38',0,'IMPEDANCEMETRIE','IMAGERY',NULL,NULL,NULL,'2023-03-21',_binary '\0','ACTIVE',NULL,'Beddek Zahir',NULL,44,46),(25,'doctor','2023-03-21 16:06:58','doctor','2023-03-21 16:06:58',0,'nasofibroscopie','IMAGERY',NULL,NULL,NULL,'2023-03-21',_binary '\0','ACTIVE',NULL,'Beddek Zahir',NULL,45,47),(26,'doctor','2023-03-21 16:15:34','doctor','2023-03-21 16:15:34',0,'nasofibroscopie Dr GHIAR','IMAGERY',NULL,NULL,NULL,'2023-03-21',_binary '\0','ACTIVE',NULL,'Beddek Zahir',NULL,48,49),(27,'doctor','2023-03-21 16:17:59','doctor','2023-03-21 16:17:59',0,'nasofibroscopie','IMAGERY',NULL,NULL,NULL,'2023-03-21',_binary '\0','ACTIVE',NULL,'Beddek Zahir',NULL,49,50),(28,'doctor','2023-03-21 16:22:45','doctor','2023-03-21 16:22:45',0,'nasofibroscopie','IMAGERY',NULL,NULL,NULL,'2023-03-21',_binary '\0','ACTIVE',NULL,'Beddek Zahir',NULL,50,51),(29,'doctor','2023-03-22 15:08:55','doctor','2023-03-22 15:08:55',0,'Endoscopie rigide','IMAGERY',NULL,NULL,NULL,'2023-03-22',_binary '\0','ACTIVE',NULL,'Beddek Zahir',NULL,52,53),(30,'doctor','2023-03-23 14:33:31','doctor','2023-03-23 14:33:31',0,'nasofibroscopie','IMAGERY',NULL,NULL,NULL,'2023-03-23',_binary '\0','ACTIVE',NULL,'Beddek Zahir',NULL,54,55),(31,'doctor','2023-03-25 09:37:50','doctor','2023-03-25 09:37:50',0,'Radio du cavum','IMAGERY',NULL,NULL,NULL,'2023-03-25',_binary '\0','ACTIVE',NULL,'Beddek Zahir',NULL,55,56),(32,'doctor','2023-03-25 14:49:51','doctor','2023-03-25 14:49:51',0,'nasofibroscopie','IMAGERY',NULL,NULL,NULL,'2023-03-25',_binary '\0','ACTIVE',NULL,'Beddek Zahir',NULL,57,58),(33,'doctor','2023-03-25 14:51:31','doctor','2023-03-25 14:51:31',0,'nasofibroscopie','IMAGERY',NULL,NULL,NULL,'2023-03-25',_binary '\0','ACTIVE',NULL,'Beddek Zahir',NULL,58,59);
/*!40000 ALTER TABLE `complementary_exam` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-03 18:07:42
