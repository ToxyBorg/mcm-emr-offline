CREATE DATABASE  IF NOT EXISTS `beddek` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `beddek`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: mcm-prod.chwkfp078t9a.eu-west-3.rds.amazonaws.com    Database: beddek
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `prescription`
--

DROP TABLE IF EXISTS `prescription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prescription` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `last_modified_date` timestamp NULL DEFAULT NULL,
  `version` int DEFAULT NULL,
  `active` bit(1) NOT NULL,
  `general_note` varchar(255) DEFAULT NULL,
  `template` bit(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prescription`
--

LOCK TABLES `prescription` WRITE;
/*!40000 ALTER TABLE `prescription` DISABLE KEYS */;
INSERT INTO `prescription` VALUES (1,'OR0053-000001','doctor','2023-02-27 20:21:07','doctor','2023-02-27 20:25:08',2,_binary '','pharmacien note',_binary '\0'),(2,'OR0053-000002','doctor','2023-02-27 20:29:57','doctor','2023-02-27 20:29:57',1,_binary '',NULL,_binary '\0'),(3,'OR0053-000003','doctor','2023-02-27 20:32:34','doctor','2023-02-27 20:32:34',1,_binary '',NULL,_binary '\0'),(4,'OR0053-000004','doctor','2023-02-27 20:34:41','doctor','2023-02-27 20:34:41',1,_binary '',NULL,_binary '\0'),(5,'OR0053-000005','doctor','2023-02-27 20:35:04','doctor','2023-02-27 20:35:04',1,_binary '',NULL,_binary '\0'),(6,NULL,'doctor','2023-02-27 20:35:25','doctor','2023-02-27 20:35:25',0,_binary '',NULL,_binary '\0'),(7,'OR0053-000007','assistant','2023-02-27 20:53:02','assistant','2023-02-27 20:53:02',1,_binary '',NULL,_binary '\0'),(8,'OR0053-000008','doctor','2023-03-04 18:18:01','doctor','2023-03-04 18:18:01',1,_binary '',NULL,_binary '\0'),(9,'OR0053-000009','doctor','2023-03-05 15:32:19','doctor','2023-03-05 15:32:19',1,_binary '',NULL,_binary '\0'),(10,'OR0053-000010','doctor','2023-03-05 16:31:49','doctor','2023-03-05 16:31:49',1,_binary '',NULL,_binary '\0'),(11,'OR0053-000011','doctor','2023-03-05 18:45:12','doctor','2023-03-05 18:45:12',1,_binary '',NULL,_binary '\0'),(12,'OR0053-000012','doctor','2023-03-05 18:55:47','doctor','2023-03-05 18:55:47',1,_binary '',NULL,_binary '\0'),(13,'OR0053-000013','doctor','2023-03-05 19:02:26','doctor','2023-03-05 19:02:26',1,_binary '',NULL,_binary '\0'),(14,'OR0053-000014','doctor','2023-03-05 19:09:16','doctor','2023-03-05 19:09:16',1,_binary '',NULL,_binary '\0'),(15,'OR0053-000015','doctor','2023-03-05 19:10:28','doctor','2023-03-05 19:10:29',1,_binary '',NULL,_binary '\0'),(16,'OR0053-000016','doctor','2023-03-06 12:09:04','doctor','2023-03-06 12:09:04',1,_binary '',NULL,_binary '\0'),(17,'OR0053-000017','doctor','2023-03-06 12:18:42','doctor','2023-03-06 12:18:42',1,_binary '',NULL,_binary '\0'),(18,'OR0053-000018','doctor','2023-03-06 14:39:12','doctor','2023-03-06 14:39:12',1,_binary '',NULL,_binary '\0'),(19,'OR0053-000019','doctor','2023-03-06 14:51:55','doctor','2023-03-06 14:51:55',1,_binary '',NULL,_binary '\0'),(20,'OR0053-000020','doctor','2023-03-07 08:56:35','doctor','2023-03-07 08:56:35',1,_binary '',NULL,_binary '\0'),(21,'OR0053-000021','doctor','2023-03-07 16:00:27','doctor','2023-03-07 16:00:27',1,_binary '',NULL,_binary '\0'),(22,'OR0053-000022','doctor','2023-03-07 16:07:21','doctor','2023-03-07 16:07:21',1,_binary '',NULL,_binary '\0'),(23,'OR0053-000023','doctor','2023-03-08 08:01:46','doctor','2023-03-08 08:01:46',1,_binary '',NULL,_binary '\0'),(24,'OR0053-000024','doctor','2023-03-08 08:20:36','doctor','2023-03-08 08:20:36',1,_binary '',NULL,_binary '\0'),(25,'OR0053-000025','doctor','2023-03-08 09:04:12','doctor','2023-03-08 09:04:12',1,_binary '',NULL,_binary '\0'),(26,'OR0053-000026','doctor','2023-03-09 09:36:41','doctor','2023-03-09 09:36:41',1,_binary '',NULL,_binary '\0'),(27,'OR0053-000027','doctor','2023-03-09 10:29:33','doctor','2023-03-09 10:29:33',1,_binary '',NULL,_binary '\0'),(28,'OR0053-000028','doctor','2023-03-14 07:14:53','doctor','2023-03-14 07:14:53',1,_binary '',NULL,_binary '\0'),(29,'OR0053-000029','doctor','2023-03-14 07:17:13','doctor','2023-03-14 07:17:13',1,_binary '',NULL,_binary '\0'),(30,'OR0053-000030','doctor','2023-03-14 15:47:57','doctor','2023-03-14 15:47:57',1,_binary '',NULL,_binary '\0'),(31,'OR0053-000031','doctor','2023-03-14 15:51:40','doctor','2023-03-14 15:51:40',1,_binary '',NULL,_binary '\0'),(32,'OR0053-000032','doctor','2023-03-14 15:55:29','doctor','2023-03-14 15:55:29',1,_binary '',NULL,_binary '\0'),(33,'OR0053-000033','doctor','2023-03-14 15:58:09','doctor','2023-03-14 15:58:09',1,_binary '',NULL,_binary '\0'),(34,'OR0053-000034','doctor','2023-03-14 16:05:22','doctor','2023-03-14 16:05:22',1,_binary '',NULL,_binary '\0'),(35,'OR0053-000035','doctor','2023-03-14 16:11:04','doctor','2023-03-14 16:11:04',1,_binary '',NULL,_binary '\0'),(36,'OR0053-000036','doctor','2023-03-16 08:58:14','doctor','2023-03-16 08:58:14',1,_binary '',NULL,_binary '\0'),(37,'OR0053-000037','doctor','2023-03-16 09:00:10','doctor','2023-03-16 09:00:10',1,_binary '',NULL,_binary '\0'),(38,'OR0053-000038','doctor','2023-03-16 09:02:08','doctor','2023-03-16 09:02:08',1,_binary '',NULL,_binary '\0'),(39,'OR0053-000039','doctor','2023-03-16 09:11:20','doctor','2023-03-16 09:11:20',1,_binary '',NULL,_binary '\0'),(40,'OR0053-000040','doctor','2023-03-16 10:46:22','doctor','2023-03-16 10:46:22',1,_binary '',NULL,_binary '\0'),(41,'OR0053-000041','doctor','2023-03-21 08:29:18','doctor','2023-03-21 08:29:18',1,_binary '',NULL,_binary '\0'),(42,'OR0053-000042','doctor','2023-03-21 10:42:28','doctor','2023-03-21 10:42:28',1,_binary '',NULL,_binary '\0'),(43,'OR0053-000043','doctor','2023-03-21 10:45:17','doctor','2023-03-21 10:45:17',1,_binary '',NULL,_binary '\0'),(44,'OR0053-000044','doctor','2023-03-21 11:03:45','doctor','2023-03-21 11:03:45',1,_binary '',NULL,_binary '\0'),(45,'OR0053-000045','doctor','2023-03-21 15:58:17','doctor','2023-03-21 15:58:17',1,_binary '',NULL,_binary '\0'),(46,'OR0053-000046','doctor','2023-03-21 16:00:52','doctor','2023-03-21 16:00:52',1,_binary '',NULL,_binary '\0'),(47,'OR0053-000047','doctor','2023-03-21 16:03:05','doctor','2023-03-21 16:03:05',1,_binary '',NULL,_binary '\0'),(48,'OR0053-000048','doctor','2023-03-21 16:06:35','doctor','2023-03-21 16:06:35',1,_binary '',NULL,_binary '\0'),(49,'OR0053-000049','doctor','2023-03-21 16:10:07','doctor','2023-03-21 16:10:07',1,_binary '',NULL,_binary '\0'),(50,'OR0053-000050','doctor','2023-03-21 16:12:44','doctor','2023-03-21 16:12:44',1,_binary '',NULL,_binary '\0'),(51,'OR0053-000051','doctor','2023-03-21 16:17:40','doctor','2023-03-21 16:17:40',1,_binary '',NULL,_binary '\0'),(52,'OR0053-000052','doctor','2023-03-21 16:22:20','doctor','2023-03-21 16:22:20',1,_binary '',NULL,_binary '\0'),(53,'OR0053-000053','doctor','2023-03-21 16:25:24','doctor','2023-03-21 16:25:24',1,_binary '',NULL,_binary '\0'),(54,'OR0053-000054','doctor','2023-03-22 15:05:38','doctor','2023-03-22 15:05:38',1,_binary '',NULL,_binary '\0'),(55,'OR0053-000055','doctor','2023-03-22 15:20:11','doctor','2023-03-22 15:20:11',1,_binary '',NULL,_binary '\0'),(56,'OR0053-000056','doctor','2023-03-23 14:28:38','doctor','2023-03-23 14:28:38',1,_binary '',NULL,_binary '\0'),(57,'OR0053-000057','doctor','2023-03-25 09:36:01','doctor','2023-03-25 09:36:01',1,_binary '',NULL,_binary '\0'),(58,'OR0053-000058','doctor','2023-03-25 13:28:43','doctor','2023-03-25 13:28:43',1,_binary '',NULL,_binary '\0'),(59,'OR0053-000059','doctor','2023-03-25 14:47:11','doctor','2023-03-25 14:47:11',1,_binary '',NULL,_binary '\0'),(60,'OR0053-000060','doctor','2023-03-25 14:51:14','doctor','2023-03-25 14:51:14',1,_binary '',NULL,_binary '\0'),(61,'OR0053-000061','doctor','2023-03-25 14:53:13','doctor','2023-03-25 14:53:13',1,_binary '',NULL,_binary '\0'),(62,'OR0053-000062','doctor','2023-03-29 08:10:18','doctor','2023-03-29 08:10:19',1,_binary '',NULL,_binary '\0');
/*!40000 ALTER TABLE `prescription` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-03 18:10:06
