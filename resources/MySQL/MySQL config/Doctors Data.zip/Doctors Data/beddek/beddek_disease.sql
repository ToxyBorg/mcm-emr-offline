CREATE DATABASE  IF NOT EXISTS `beddek` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `beddek`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: mcm-prod.chwkfp078t9a.eu-west-3.rds.amazonaws.com    Database: beddek
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `disease`
--

DROP TABLE IF EXISTS `disease`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `disease` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_by` varchar(255) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `last_modified_date` timestamp NULL DEFAULT NULL,
  `version` int DEFAULT NULL,
  `designation` varchar(255) NOT NULL,
  `date` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `note` text,
  `doctor` varchar(255) DEFAULT NULL,
  `patient_id` bigint NOT NULL,
  `visit_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_disease_patient` (`patient_id`),
  KEY `FK_disease_visit` (`visit_id`),
  CONSTRAINT `FK_disease_patient` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`id`),
  CONSTRAINT `FK_disease_visit` FOREIGN KEY (`visit_id`) REFERENCES `visit` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disease`
--

LOCK TABLES `disease` WRITE;
/*!40000 ALTER TABLE `disease` DISABLE KEYS */;
INSERT INTO `disease` VALUES (3,'doctor','2023-02-27 20:32:57','doctor','2023-02-27 20:34:41',1,'Angine','2023-02-27','ACTIVE',NULL,'Beddek Zahir',2,4),(4,'doctor','2023-02-27 20:32:57','doctor','2023-02-27 20:34:41',1,'Adénocarcinome peu différencié du cæcum','2023-02-27','ACTIVE',NULL,'Beddek Zahir',2,4),(5,'doctor','2023-02-27 20:54:21','doctor','2023-02-27 20:54:21',0,'Angine','2023-02-27','ACTIVE',NULL,'Beddek Zahir',1,6),(6,'doctor','2023-02-27 20:54:21','doctor','2023-02-27 20:54:21',0,'Adénocarcinome peu différencié du cæcum','2023-02-27','ACTIVE',NULL,'Beddek Zahir',1,6),(7,'doctor','2023-03-04 20:27:25','doctor','2023-03-04 20:27:25',0,'SINUSITE FRONTALE','2023-03-04','ACTIVE',NULL,'Beddek Zahir',11,7),(9,'doctor','2023-03-05 15:35:55','doctor','2023-03-05 16:31:49',1,'Hypertrophie des végétations adénoïdes','2023-03-05','ACTIVE',NULL,'Beddek Zahir',12,9),(10,'doctor','2023-03-05 16:33:55','doctor','2023-03-05 16:33:55',0,'VG a operer','2023-03-05','ACTIVE',NULL,'Beddek Zahir',12,9),(11,'doctor','2023-03-05 18:53:08','doctor','2023-03-05 19:10:29',2,'VG 27','2023-03-05','ACTIVE',NULL,'Beddek Zahir',13,14),(12,'doctor','2023-03-05 18:59:39','doctor','2023-03-05 18:59:39',0,'AVG 40','2023-03-05','ACTIVE',NULL,'Beddek Zahir',14,11),(13,'doctor','2023-03-05 19:05:35','doctor','2023-03-05 19:05:35',0,'VG 28','2023-03-05','ACTIVE',NULL,'Beddek Zahir',15,12),(14,'doctor','2023-03-06 12:12:17','doctor','2023-03-06 12:12:17',0,'AVG 40 si parent VG30','2023-03-06','ACTIVE',NULL,'Beddek Zahir',16,15),(15,'doctor','2023-03-06 12:12:47','doctor','2023-03-06 12:12:47',0,'GROSSE AMG','2023-03-06','ACTIVE',NULL,'Beddek Zahir',16,15),(16,'doctor','2023-03-06 12:21:08','doctor','2023-03-06 12:21:08',0,'perforation tympanique antero inf gch','2023-03-06','ACTIVE',NULL,'Beddek Zahir',17,16),(17,'doctor','2023-03-06 12:21:52','doctor','2023-03-06 12:21:52',0,'A op 80','2023-03-06','ACTIVE',NULL,'Beddek Zahir',17,16),(18,'doctor','2023-03-06 14:41:44','doctor','2023-03-06 14:41:44',0,'VG 30','2023-03-06','ACTIVE',NULL,'Beddek Zahir',18,17),(19,'doctor','2023-03-07 09:01:13','doctor','2023-03-07 09:01:13',0,'OMA gch','2023-03-07','ACTIVE',NULL,'Beddek Zahir',19,19),(20,'doctor','2023-03-07 12:10:11','doctor','2023-03-07 12:10:11',0,'+/- AVG apres resultat NASO','2023-03-07','ACTIVE',NULL,'Beddek Zahir',19,19),(21,'doctor','2023-03-07 16:02:12','doctor','2023-03-07 16:02:12',0,'VG 30','2023-03-07','ACTIVE',NULL,'Beddek Zahir',20,20),(22,'doctor','2023-03-07 16:18:12','doctor','2023-03-07 16:18:12',0,'VG 28','2023-03-07','ACTIVE',NULL,'Beddek Zahir',21,21),(23,'doctor','2023-03-07 16:19:56','doctor','2023-03-07 16:19:56',0,'A op apres les examens','2023-03-07','ACTIVE',NULL,'Beddek Zahir',21,21),(24,'doctor','2023-03-08 08:16:47','doctor','2023-03-08 08:16:47',0,'AVG 33 op 4/2/2023','2023-03-08','ACTIVE',NULL,'Beddek Zahir',22,22),(25,'doctor','2023-03-08 08:18:38','doctor','2023-03-08 08:18:38',0,'OSM imp en dome + otites a rep ( ref imp apres 1mois)','2023-03-08','ACTIVE',NULL,'Beddek Zahir',22,22),(26,'doctor','2023-03-08 08:22:23','doctor','2023-03-08 08:23:29',1,'DCN post tr 15j a op','2023-03-08','ACTIVE',NULL,NULL,23,23),(27,'doctor','2023-03-08 09:06:37','doctor','2023-03-08 09:06:37',0,'DCN+ANS prev naso puis DCN +/- CI RF','2023-03-08','ACTIVE',NULL,'Beddek Zahir',24,24),(28,'doctor','2023-03-09 09:37:17','doctor','2023-03-09 09:37:17',0,'FDL 3','2023-03-09','ACTIVE',NULL,'Beddek Zahir',25,25),(29,'doctor','2023-03-09 10:32:42','doctor','2023-03-09 10:32:42',0,'OMA gch PTgch','2023-03-09','ACTIVE',NULL,'Beddek Zahir',26,26),(30,'doctor','2023-03-14 07:16:05','doctor','2023-03-14 07:16:05',0,'VG','2023-03-14','ACTIVE',NULL,'Beddek Zahir',27,27),(31,'doctor','2023-03-14 07:19:07','doctor','2023-03-14 07:19:07',0,'OSM bil ATT+VG','2023-03-14','ACTIVE',NULL,'Beddek Zahir',28,28),(32,'doctor','2023-03-14 15:49:37','doctor','2023-03-14 15:49:37',0,'AVG 40','2023-03-14','ACTIVE',NULL,'Beddek Zahir',29,29),(33,'doctor','2023-03-14 15:54:11','doctor','2023-03-14 15:54:11',0,'AVG 40','2023-03-14','ACTIVE',NULL,'Beddek Zahir',30,30),(34,'doctor','2023-03-14 15:56:55','doctor','2023-03-14 15:56:55',0,'AVG 40','2023-03-14','ACTIVE',NULL,'Beddek Zahir',31,31),(35,'doctor','2023-03-14 16:01:50','doctor','2023-03-14 16:01:50',0,'DCN 80-','2023-03-14','ACTIVE',NULL,'Beddek Zahir',32,32),(36,'doctor','2023-03-14 16:08:09','doctor','2023-03-14 16:08:09',0,'Rhino-septoplastie 12','2023-03-14','ACTIVE',NULL,'Beddek Zahir',33,33),(37,'doctor','2023-03-14 16:13:16','doctor','2023-03-14 16:13:16',0,'VG 27','2023-03-14','ACTIVE',NULL,'Beddek Zahir',34,34),(38,'doctor','2023-03-16 08:59:02','doctor','2023-03-16 08:59:02',0,'AVG 38','2023-03-16','ACTIVE',NULL,'Beddek Zahir',35,35),(39,'doctor','2023-03-16 09:00:42','doctor','2023-03-16 09:00:42',0,'VG 30','2023-03-16','ACTIVE',NULL,'Beddek Zahir',36,36),(40,'doctor','2023-03-16 09:03:03','doctor','2023-03-16 09:03:03',0,'VG 30','2023-03-16','ACTIVE',NULL,'Beddek Zahir',37,37),(41,'doctor','2023-03-16 10:45:21','doctor','2023-03-16 10:45:21',0,'VG 28 15/3/23','2023-03-16','ACTIVE',NULL,'Beddek Zahir',21,38),(42,'doctor','2023-03-21 10:40:20','doctor','2023-03-21 10:40:20',0,'VG 30','2023-03-21','ACTIVE',NULL,'Beddek Zahir',38,40),(43,'doctor','2023-03-21 10:43:53','doctor','2023-03-21 10:43:53',0,'DCN CI RF 80','2023-03-21','ACTIVE',NULL,'Beddek Zahir',39,41),(44,'doctor','2023-03-21 10:46:04','doctor','2023-03-21 10:46:04',0,'VG','2023-03-21','ACTIVE',NULL,'Beddek Zahir',40,42),(45,'doctor','2023-03-21 11:05:12','doctor','2023-03-21 11:05:12',0,'AVG 40','2023-03-21','ACTIVE',NULL,'Beddek Zahir',41,43),(46,'doctor','2023-03-21 15:58:55','doctor','2023-03-21 15:58:55',0,'VG 30','2023-03-21','ACTIVE',NULL,'Beddek Zahir',42,44),(47,'doctor','2023-03-21 16:01:31','doctor','2023-03-21 16:01:31',0,'VG 30','2023-03-21','ACTIVE',NULL,'Beddek Zahir',43,45),(48,'doctor','2023-03-21 16:05:16','doctor','2023-03-21 16:05:16',0,'ATT VG 45','2023-03-21','ACTIVE',NULL,'Beddek Zahir',44,46),(49,'doctor','2023-03-21 16:07:14','doctor','2023-03-21 16:07:14',0,'VG 30','2023-03-21','ACTIVE',NULL,'Beddek Zahir',45,47),(50,'doctor','2023-03-21 16:11:19','doctor','2023-03-21 16:11:19',0,'VG 28','2023-03-21','ACTIVE',NULL,'Beddek Zahir',47,48),(51,'doctor','2023-03-21 16:14:20','doctor','2023-03-21 16:14:20',0,'AVG','2023-03-21','ACTIVE',NULL,'Beddek Zahir',48,49),(52,'doctor','2023-03-21 16:21:00','doctor','2023-03-21 16:21:00',0,'VG circ 23','2023-03-21','ACTIVE',NULL,'Beddek Zahir',49,50),(53,'doctor','2023-03-21 16:24:11','doctor','2023-03-21 16:24:11',0,'DCN VG +/- CI RF','2023-03-21','ACTIVE',NULL,'Beddek Zahir',50,51),(54,'doctor','2023-03-21 16:26:40','doctor','2023-03-21 16:26:40',0,'VG 30 +/- AMG Apres','2023-03-21','ACTIVE',NULL,'Beddek Zahir',51,52),(55,'doctor','2023-03-22 15:07:39','doctor','2023-03-22 15:07:39',0,'DCR 60','2023-03-22','ACTIVE',NULL,'Beddek Zahir',52,53),(56,'doctor','2023-03-23 14:30:37','doctor','2023-03-23 14:30:37',0,'AMG 50 S3','2023-03-23','ACTIVE',NULL,'Beddek Zahir',53,54),(57,'doctor','2023-03-23 14:33:11','doctor','2023-03-23 14:33:11',0,'AVG 40 si parent VG30  GAO ','2023-03-23','ACTIVE',NULL,'Beddek Zahir',54,55),(58,'doctor','2023-03-25 09:37:19','doctor','2023-03-25 09:37:19',0,'VG 30 ANS','2023-03-25','ACTIVE',NULL,'Beddek Zahir',55,56),(59,'doctor','2023-03-25 14:47:52','doctor','2023-03-25 14:47:52',0,'VG 27','2023-03-25','ACTIVE',NULL,'Beddek Zahir',57,58),(60,'doctor','2023-03-25 14:52:11','doctor','2023-03-25 14:52:11',0,'VG 30','2023-03-25','ACTIVE',NULL,'Beddek Zahir',58,59),(61,'doctor','2023-03-25 14:53:43','doctor','2023-03-25 14:53:43',0,'VG 30','2023-03-25','ACTIVE',NULL,'Beddek Zahir',59,60),(62,'doctor','2023-03-29 08:11:46','doctor','2023-03-29 08:11:46',0,'AVG 40 GAO','2023-03-29','ACTIVE',NULL,'Beddek Zahir',60,61);
/*!40000 ALTER TABLE `disease` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-03 18:10:14
