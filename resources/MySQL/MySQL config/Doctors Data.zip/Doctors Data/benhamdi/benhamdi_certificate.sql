CREATE DATABASE  IF NOT EXISTS `benhamdi` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `benhamdi`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: mcm-prod.chwkfp078t9a.eu-west-3.rds.amazonaws.com    Database: benhamdi
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `certificate`
--

DROP TABLE IF EXISTS `certificate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `certificate` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_by` varchar(255) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `last_modified_date` timestamp NULL DEFAULT NULL,
  `version` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `content` text,
  `date` date DEFAULT NULL,
  `doctor` varchar(255) DEFAULT NULL,
  `patient_id` bigint NOT NULL,
  `visit_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_certificate_patient` (`patient_id`),
  KEY `FK_certificate_visit` (`visit_id`),
  CONSTRAINT `FK_certificate_patient` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`id`),
  CONSTRAINT `FK_certificate_visit` FOREIGN KEY (`visit_id`) REFERENCES `visit` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `certificate`
--

LOCK TABLES `certificate` WRITE;
/*!40000 ALTER TABLE `certificate` DISABLE KEYS */;
INSERT INTO `certificate` VALUES (1,'doctor','2023-05-22 10:10:01','doctor','2023-05-22 10:10:01',0,'cher confrer ','permettez moi de vous adressez le patent susmonee qui suit a notre niveau pour des lombosciatalgie suit a une hernie discale l4/l5 pour une reeducation fonctionnel&nbsp;<div><br></div>','2023-05-22','Doctor Doctor',1,106),(2,'doctor','2023-06-14 13:30:07','doctor','2023-06-14 13:30:07',0,'RAPPORT MEDICAL','il sagit du patient susnommee&nbsp;','2023-06-14','Doctor Doctor',113,205),(3,'doctor','2023-07-10 18:39:22','doctor','2023-07-10 18:39:22',0,'CERTIFICAT D’ARRET DE TRAVAIL','\n            <p class=\"MsoNormal\" align=\"center\" style=\"text-align:center\">\n                <span style=\"background-color: transparent;\">\n                    <b>\n                        <br>\n                    </b>\n                </span>\n            </p>\n            <p class=\"MsoNormal\" style=\"text-align: justify;\">\n                <span style=\"line-height: 107%;\"><font size=\"2\">&nbsp; &nbsp; &nbsp;&nbsp;Je soussigné, Dr ______ ,\n                    certifie avoir examiné&nbsp;</font>______&nbsp;<font size=\"2\">&nbsp;âgé de&nbsp;</font>______&nbsp;&nbsp;<font\n                        size=\"2\">, en date du&nbsp;</font>______&nbsp;<font size=\"2\">&nbsp;et déclare que&nbsp;</font>son état\n                    de santé nécessite un arrêt de travail de ______\n                    <font size=\"2\">.</font>\n                </span>\n            </p>\n            <p class=\"MsoNormal\" style=\"text-align: justify;\">\n                <span style=\"line-height: 107%;\">\n                    <font size=\"2\">Ce certificat est remis en mains propres de l\'intéressé pour servir et faire valoir\n                        ce que de droit.\n                    </font>\n                </span>\n            </p>\n            <p class=\"MsoNormal\">\n                <span style=\"background-color: transparent; font-size: 16pt; text-align: center;\">&nbsp;&nbsp;</span>\n            </p>\n            ','2023-07-10','Doctor Doctor',266,290),(4,'doctor','2023-07-11 09:15:43','doctor','2023-07-11 09:15:43',0,'cher  confrere ','peremettez moi de vous adresser la patiente sus nommee operee pour une maladie d\'haglund de pied droit benifiçiant d\'une resection de la grosse tuburosite calcanienne il y 45 jrs pour une reeducaton fonctionnel (antalgique+ renforcement musculaire )','2023-07-11','Doctor Doctor',87,294),(5,'doctor','2023-09-04 16:39:48','doctor','2023-09-04 16:39:48',0,'facture','geste : traitement chirurgicale d\'un angle incarnee bilaterale&nbsp;<div><br></div><div>montant globale : 10000 da&nbsp;</div><div><br></div>','2023-09-04','Doctor Doctor',374,415),(6,'doctor','2024-03-26 00:02:21','doctor','2024-03-26 00:09:48',2,'Rapport medical ','<h2><div style=\"text-align: left;\"><span style=\"background-color: transparent;\">il s\'agit du patiente susnomé agé de 66 ans diabetique, hypertendue&nbsp; qui suit à notre niveau pour des gonalgies invalidante ,</span></div><font size=\"7\"><div style=\"text-align: left;\"><span style=\"background-color: transparent;\">des lombosciatalgie chronique rebelle aux traitement et dont l\'examen rx clinique en faveurs de gonarthrose stade avancée ,</span></div></font><font size=\"7\"><div style=\"text-align: left;\"><span style=\"background-color: transparent;\">spondylolesthesis avec conflit disco radiculaire&nbsp;</span></div></font><font size=\"7\"><div style=\"text-align: left;\"><span style=\"background-color: transparent;\">l\'état de santé actuel du patiente necessite un tiers personne pour ces besoins quotidien</span></div></font><font size=\"7\"><div style=\"text-align: left;\"><span style=\"background-color: transparent;\">d\'ou ce rapport est delivré.</span></div></font></h2><div style=\"text-align: left;\"><br></div>','2024-03-26','Doctor Doctor',922,1023);
/*!40000 ALTER TABLE `certificate` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-03 18:02:21
