CREATE DATABASE  IF NOT EXISTS `benhamdi` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `benhamdi`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: mcm-prod.chwkfp078t9a.eu-west-3.rds.amazonaws.com    Database: benhamdi
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `disease`
--

DROP TABLE IF EXISTS `disease`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `disease` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_by` varchar(255) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `last_modified_date` timestamp NULL DEFAULT NULL,
  `version` int DEFAULT NULL,
  `designation` varchar(255) NOT NULL,
  `date` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `note` text,
  `doctor` varchar(255) DEFAULT NULL,
  `patient_id` bigint NOT NULL,
  `visit_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_disease_patient` (`patient_id`),
  KEY `FK_disease_visit` (`visit_id`),
  CONSTRAINT `FK_disease_patient` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`id`),
  CONSTRAINT `FK_disease_visit` FOREIGN KEY (`visit_id`) REFERENCES `visit` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disease`
--

LOCK TABLES `disease` WRITE;
/*!40000 ALTER TABLE `disease` DISABLE KEYS */;
INSERT INTO `disease` VALUES (1,'doctor','2023-04-29 08:44:59','doctor','2023-04-29 08:44:59',0,'plaie zone 7 extenseur avec fracture base M2m3M4et m5','2023-04-29','ACTIVE',NULL,'Doctor Doctor',5,5),(2,'doctor','2023-04-29 08:49:00','doctor','2023-04-29 08:49:00',0,'Phlegmon de la gaine des fléchisseurs D3','2023-04-29','ACTIVE',NULL,'Doctor Doctor',6,6),(3,'doctor','2023-04-29 08:56:45','doctor','2023-04-29 08:56:45',0,'Pseudarthrose aseptique humerus','2023-04-29','ACTIVE',NULL,'Doctor Doctor',7,7),(4,'doctor','2023-04-29 09:01:14','doctor','2023-04-29 09:01:14',0,'ablation materiel d\'osteosynthese ','2023-04-29','ACTIVE',NULL,'Doctor Doctor',8,8),(5,'doctor','2023-04-29 09:20:57','doctor','2023-04-29 09:20:57',0,'fracture palette humeral type 1','2023-04-29','ACTIVE',NULL,'Doctor Doctor',9,9),(6,'doctor','2023-04-30 08:37:16','doctor','2023-04-30 08:37:16',0,'avp fracture fcv +femur +jambe','2023-04-30','ACTIVE',NULL,'Doctor Doctor',14,13),(7,'doctor','2023-05-02 08:52:03','doctor','2023-05-02 08:52:03',0,'Gonarthrose','2023-05-02','ACTIVE',NULL,'Doctor Doctor',17,18),(8,'doctor','2023-05-02 10:02:58','doctor','2023-05-02 10:02:58',0,'Fracture per-trochantérienne','2023-05-02','ACTIVE',NULL,'Doctor Doctor',21,23);
/*!40000 ALTER TABLE `disease` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-03 18:02:25
