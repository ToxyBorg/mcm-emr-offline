CREATE DATABASE  IF NOT EXISTS `benhamdi` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `benhamdi`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: mcm-prod.chwkfp078t9a.eu-west-3.rds.amazonaws.com    Database: benhamdi
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `medicament_lookup`
--

DROP TABLE IF EXISTS `medicament_lookup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicament_lookup` (
  `value` varchar(255) NOT NULL,
  `dci` varchar(255) DEFAULT NULL,
  `forms` text,
  `sponsored` bit(1) NOT NULL DEFAULT b'0',
  `points` bigint DEFAULT NULL,
  `lab_id` bigint DEFAULT NULL,
  `dosage_card` mediumtext,
  `notice` mediumtext,
  `specialities` text,
  PRIMARY KEY (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicament_lookup`
--

LOCK TABLES `medicament_lookup` WRITE;
/*!40000 ALTER TABLE `medicament_lookup` DISABLE KEYS */;
INSERT INTO `medicament_lookup` VALUES ('AMOXICILLINE','AMOXICILLINE','[{\"form\":\"cp\",\"dosages\":[\"1 g\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('ANCEFAL','CEFAZOLINE ','[{\"form\":\"cp\",\"dosages\":[\"500 mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('ARTHRO','ARTHRO CURCUMA','[]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('ARTHRO BIO','ATHRO CURCUMA','[{\"form\":\"cp\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('ARTHRUM HCS','SODIUM HYLARUNATE +CHDROITINE ','[{\"form\":\"40 mg/40/mg/2ml\",\"dosages\":[]},{\"form\":\"inj\",\"dosages\":[\"40 mg/40/mg/2ml40 mg/40/mg/2ml\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('ARTHRUM VISC 75','SODIUM HYALURONATE ','[{\"form\":\"inj\",\"dosages\":[\"75mg/3ml\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('BACTRIM','SULFAMETHOXAZOLE+TRIM','[{\"form\":\"cp\",\"dosages\":[\"800/160 mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('BENERGIE','VITAMINE B','[{\"form\":\"gellule\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('BIOFENAC FAST','DECLOFENAC','[{\"form\":\"sch\",\"dosages\":[\"50 mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('BIOPROSTENE','BETHAMETASONE ','[{\"form\":\"5mg/ml+2mg/ml\",\"dosages\":[]},{\"form\":\"inj\",\"dosages\":[\"5mg/ml+2mg/ml\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('CALCIUM D3 WML','CALCIUM D3 WML','[{\"form\":\"cp \",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('CEFALIZOL','CEFAZOLINE','[{\"form\":\"cp\",\"dosages\":[\"1 g\"]},{\"form\":\"inj\",\"dosages\":[\"1 g\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('CHONDROFLEX','CHONDROFLEX','[{\"form\":\"gel\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('CODOLYC','CODOLYC','[{\"form\":\"cp\",\"dosages\":[\"500mg/30mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('DECRAMPE','DECRAMPE ','[{\"form\":\"cp\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('DIPRONAD','DIPRONATE DE BETAMETHASONE 5 MG','[{\"form\":\"inj\",\"dosages\":[\"5 mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('DIPRONAD OU KENACORTYL','DIPRONAD  OU KENACORTYL','[{\"form\":\"inj\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('DOXYCYCLINE SANDOZ','DOXYCYCLINE ','[{\"form\":\"cp\",\"dosages\":[\"100 mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('EBASTA','EBASTA','[{\"form\":\"10 mg\",\"dosages\":[]},{\"form\":\"cp\",\"dosages\":[\"10 mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('EDUCTYL','TARTRATE ACIDE DE POTASSIUM','[{\"form\":\"supp\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('ESOPROTON','LANZOPRAZOL','[{\"form\":\"cp\",\"dosages\":[\"30 mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('GAMCET','GAMCET','[{\"form\":\"cp\",\"dosages\":[\"0.4\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('GLUCOFLEX','GLUCOSAMINE ','[{\"form\":\"cp\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('GLUCOFLEX BAUME','GLUCOFLEX BAUME','[{\"form\":\"gel\",\"dosages\":[]},{\"form\":\"pommade\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('IBUPROFENE LDM','IBUPROFENE ','[{\"form\":\"GEL\",\"dosages\":[\"5 %\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('KEFALEX','CEFALEXINE ','[{\"form\":\"1 g\",\"dosages\":[\"1 g\"]},{\"form\":\"cp\",\"dosages\":[\"1 g\"]},{\"form\":\"INJ \",\"dosages\":[\"1 G\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('KELOCOTE','KELOCOTE ','[{\"form\":\"gel \",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('KENACORTYL','KENACORTYL','[{\"form\":\"inj\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('LANSOMED','LANSOPRAZOLE','[{\"form\":\"cp\",\"dosages\":[\"30 mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('MAGNESIUM 400','MG+B6+B12+ACIDE FOLIQUE','[]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('MAGNO STRESS','MG','[{\"form\":\"cp\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('MEBO','MEBO','[{\"form\":\"pommade\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('MYORELAX','MYORELAX ','[{\"form\":\"cp\",\"dosages\":[\"150 mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('MYOXYDOL','METHOCARBAMOL/IBUPROFENE','[{\"form\":\"cp\",\"dosages\":[\"500/200 mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('NEUF B','NEUF B MULTIVITAMINE B ','[{\"form\":\"cp\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('NEUROPLEX','NEUROPLEX','[{\"form\":\"cp\",\"dosages\":[\"400 mg\",\"300 mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('OSMAX','ACIDE ALENDRONIQUE ','[{\"form\":\"70 mg\",\"dosages\":[]},{\"form\":\"cp\",\"dosages\":[\"70 mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('SIMEXANE','SIMETICONE ','[{\"form\":\"gelule\",\"dosages\":[\"125/80 mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('SINOVIAL','ACIDE HYALURONIQUE ','[{\"form\":\"inj\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('SULPIDE','SULPIRIDE ','[{\"form\":\"sirop\",\"dosages\":[\"5 mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('SUPRADYN','SUPRADYN','[{\"form\":\"cp eff\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('SUPRADYN MG','SUPRADYN MG','[{\"form\":\"cp\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('TAZOTAX','FEBUXOSTAT','[{\"form\":\"cp \",\"dosages\":[\"80 mg\",\"80 mg\",\"80 mg\",\"80 mg\",\"80 mg\",\"80 mg\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('TETANOREINE','TITANORÉÏNE ','[]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('THERANOX','ENOXAPARINE SODIQUE','[{\"form\":\"inj \",\"dosages\":[\"4000 ui\",\"4000 ui\",\"4000 ui\",\"4000 ui\",\"4000 ui\"]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('VITAGLOBIN','VITAGLOBIN','[{\"form\":\"cp\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('VITAMINE D EVEXIA','VITAMINE D','[{\"form\":\"gelule\",\"dosages\":[\"1000 u.i\"]},{\"form\":\"cp\",\"dosages\":[]}]',_binary '\0',NULL,NULL,NULL,NULL,'[]'),('ZECUF','ZECUF','[]',_binary '\0',NULL,NULL,NULL,NULL,'[]');
/*!40000 ALTER TABLE `medicament_lookup` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-03 18:02:11
