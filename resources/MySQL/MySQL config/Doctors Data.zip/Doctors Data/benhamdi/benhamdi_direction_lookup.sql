CREATE DATABASE  IF NOT EXISTS `benhamdi` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `benhamdi`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: mcm-prod.chwkfp078t9a.eu-west-3.rds.amazonaws.com    Database: benhamdi
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `direction_lookup`
--

DROP TABLE IF EXISTS `direction_lookup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `direction_lookup` (
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `direction_lookup`
--

LOCK TABLES `direction_lookup` WRITE;
/*!40000 ALTER TABLE `direction_lookup` DISABLE KEYS */;
INSERT INTO `direction_lookup` VALUES ('01'),('1 amp cha'),('1 amp chaque 15 jrs'),('1 AMP/JR'),('1 app 2 x jr'),('1 app par pst'),('1 caf 2 x jr'),('1 cam  x jr'),('1 cam 2 x jr'),('1 cam 3 x jr'),('1 cam le soir'),('1 cp'),('1 cp / jr'),('1 cp / jr le 1 jr'),('1 cp / jr le 1 jr puis 1 cp 2/jr'),('1 cp /semaine'),('1 cp 2'),('1 cp 2 x jr'),('1 cp 2 x jr (matin et midi)'),('1 cp 2 x jr au milieu des repas'),('1 cp 2 x jr au milieu des repas pdt 3 jrs puis 1 cp /jr'),('1 cp 2 x jr pdt 5 jrs'),('1 cp 21'),('1 cp 3 x jr'),('1 CP AU'),('1 cp au milieu des repas'),('1 cp au milieu des repas pdt 3 jrs'),('1 cp chaque semaine'),('1 cp le 1 jrs puis 1 cp 2 /jrs'),('1 cp le matin'),('1 cp le matin PDT 10 jrs'),('1 cp le matin pdt 3 jrs'),('1 cp le soir'),('1 cp2'),('1 gel / jrs'),('1 inj  en im / jr'),('1 inj en im  / 10 jrs'),('1 inj en im  / 15 jrs'),('1 inj en im  / 21 jrs'),('1 inj en s/c'),('1 inj en s/c / jr'),('1 inj po7'),('1 inj pour infiltration'),('1 inj pour infiltration / 15 jrs'),('1 inj pour infiltration/semaine'),('1 patch/ jr'),('1 sch / jr'),('1 sch / jr au milieu des repas'),('1 sch / jr au milieu des repas pdt 3 jr'),('1 sch 2/ jr'),('1 sch 2/ jr au milieu des repas'),('1 sch 3 / jr'),('1 supp le soir'),('1 supp x 3 jrs'),('2 cp / jrs'),('2 cp 2 x jr'),('2 cp 3 fois jrs'),('2 cp le matin pdt 3 jr'),('2 cp le matin pdt 3 jr puis 1 cp / jr'),('2 cp le matin pdt 5 jr'),('2 cp le matin pdt 5 jr puis 1 cp pdt 3 jrs'),('2 GEL/ 2 FOIS JR');
/*!40000 ALTER TABLE `direction_lookup` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-03 17:58:49
