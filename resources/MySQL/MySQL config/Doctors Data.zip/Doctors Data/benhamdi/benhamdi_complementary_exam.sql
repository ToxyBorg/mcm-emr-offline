CREATE DATABASE  IF NOT EXISTS `benhamdi` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `benhamdi`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: mcm-prod.chwkfp078t9a.eu-west-3.rds.amazonaws.com    Database: benhamdi
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `complementary_exam`
--

DROP TABLE IF EXISTS `complementary_exam`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `complementary_exam` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_by` varchar(255) DEFAULT NULL,
  `creation_date` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(255) DEFAULT NULL,
  `last_modified_date` timestamp NULL DEFAULT NULL,
  `version` int DEFAULT NULL,
  `designation` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `normal_range` varchar(255) DEFAULT NULL,
  `unit` varchar(255) DEFAULT NULL,
  `results` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `approved` bit(1) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `note` text,
  `doctor` varchar(255) DEFAULT NULL,
  `attachment` mediumtext,
  `patient_id` bigint NOT NULL,
  `visit_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_complementary_exam_patient` (`patient_id`),
  KEY `FK_complementary_exam_visit` (`visit_id`),
  CONSTRAINT `FK_complementary_exam_patient` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`id`),
  CONSTRAINT `FK_complementary_exam_visit` FOREIGN KEY (`visit_id`) REFERENCES `visit` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `complementary_exam`
--

LOCK TABLES `complementary_exam` WRITE;
/*!40000 ALTER TABLE `complementary_exam` DISABLE KEYS */;
INSERT INTO `complementary_exam` VALUES (1,'doctor','2023-09-20 09:32:59','doctor','2023-09-20 09:32:59',0,'Arthro-IRM de la cheville droite','IMAGERY',NULL,NULL,NULL,'2023-09-20',_binary '\0','ACTIVE',NULL,'Doctor Doctor',NULL,423,465),(2,'doctor','2023-09-30 11:17:24','doctor','2023-09-30 11:17:24',0,'FNS','SEROLOGY',NULL,NULL,NULL,'2023-09-30',_binary '\0','ACTIVE',NULL,'Doctor Doctor',NULL,457,503),(3,'doctor','2023-09-30 11:17:31','doctor','2023-09-30 11:17:31',0,'VS','SEROLOGY',NULL,NULL,NULL,'2023-09-30',_binary '\0','ACTIVE',NULL,'Doctor Doctor',NULL,457,503),(4,'doctor','2023-09-30 11:17:36','doctor','2023-09-30 11:17:53',1,'ASLO - LATEX','SEROLOGY',NULL,NULL,NULL,'2023-09-30',_binary '','ACTIVE',NULL,'Doctor Doctor',NULL,457,503),(5,'doctor','2023-09-30 11:22:23','doctor','2023-09-30 11:22:23',0,'FNS','SEROLOGY',NULL,NULL,NULL,'2023-09-30',_binary '\0','ACTIVE',NULL,'Doctor Doctor',NULL,458,504),(6,'doctor','2023-09-30 11:22:27','doctor','2023-09-30 11:22:27',0,'VS','SEROLOGY',NULL,NULL,NULL,'2023-09-30',_binary '\0','ACTIVE',NULL,'Doctor Doctor',NULL,458,504),(7,'doctor','2023-09-30 11:22:54','doctor','2023-09-30 11:22:54',0,'waler rose-latex','SEROLOGY',NULL,NULL,NULL,'2023-09-30',_binary '\0','ACTIVE',NULL,'Doctor Doctor',NULL,458,504),(8,'doctor','2023-09-30 11:23:26','doctor','2023-09-30 11:23:26',0,'vitamine D','SEROLOGY',NULL,NULL,NULL,'2023-09-30',_binary '\0','ACTIVE',NULL,'Doctor Doctor',NULL,458,504),(9,'doctor','2024-02-05 09:13:14','doctor','2024-02-05 09:13:14',0,'FNS','SEROLOGY',NULL,NULL,NULL,'2024-02-05',_binary '\0','ACTIVE',NULL,'Doctor Doctor',NULL,809,895),(10,'doctor','2024-02-05 09:13:23','doctor','2024-02-05 09:13:23',0,'waler rose-latex','SEROLOGY',NULL,NULL,NULL,'2024-02-05',_binary '\0','ACTIVE',NULL,'Doctor Doctor',NULL,809,895),(11,'doctor','2024-02-05 09:13:31','doctor','2024-02-05 09:13:31',0,'Urée - Créatininémie','SEROLOGY',NULL,NULL,NULL,'2024-02-05',_binary '\0','ACTIVE',NULL,'Doctor Doctor',NULL,809,895),(12,'doctor','2024-02-05 09:13:50','doctor','2024-02-05 09:13:50',0,'vitamine D','SEROLOGY',NULL,NULL,NULL,'2024-02-05',_binary '\0','ACTIVE',NULL,'Doctor Doctor',NULL,809,895),(13,'doctor','2024-02-05 09:14:00','doctor','2024-02-05 09:14:00',0,'SGOT (ASAT)','SEROLOGY',NULL,NULL,NULL,'2024-02-05',_binary '\0','ACTIVE',NULL,'Doctor Doctor',NULL,809,895),(14,'doctor','2024-02-05 09:14:14','doctor','2024-02-05 09:14:14',0,'SGPT (ALAT)','SEROLOGY',NULL,NULL,NULL,'2024-02-05',_binary '\0','ACTIVE',NULL,'Doctor Doctor',NULL,809,895),(15,'doctor','2024-02-07 09:49:54','doctor','2024-02-07 09:49:54',0,'FNS','SEROLOGY',NULL,NULL,NULL,'2024-02-07',_binary '\0','ACTIVE',NULL,'Doctor Doctor',NULL,813,901),(16,'doctor','2024-02-07 09:50:03','doctor','2024-02-07 09:50:03',0,'waler rose-latex','SEROLOGY',NULL,NULL,NULL,'2024-02-07',_binary '\0','ACTIVE',NULL,'Doctor Doctor',NULL,813,901),(17,'doctor','2024-02-07 09:50:08','doctor','2024-02-07 09:50:08',0,'Acide urique','SEROLOGY',NULL,NULL,NULL,'2024-02-07',_binary '\0','ACTIVE',NULL,'Doctor Doctor',NULL,813,901),(18,'doctor','2024-02-07 09:50:28','doctor','2024-02-07 09:50:28',0,'ASLO - LATEX','SEROLOGY',NULL,NULL,NULL,'2024-02-07',_binary '\0','ACTIVE',NULL,'Doctor Doctor',NULL,813,901),(19,'doctor','2024-02-07 09:50:39','doctor','2024-02-07 09:50:39',0,'vitamine D','SEROLOGY',NULL,NULL,NULL,'2024-02-07',_binary '\0','ACTIVE',NULL,'Doctor Doctor',NULL,813,901),(20,'doctor','2024-02-11 08:37:39','doctor','2024-02-11 08:37:39',0,'FNS','SEROLOGY',NULL,NULL,NULL,'2024-02-11',_binary '\0','ACTIVE',NULL,'Doctor Doctor',NULL,817,905),(21,'doctor','2024-02-11 08:37:48','doctor','2024-02-11 08:37:48',0,'Facteur rhumatoïde','SEROLOGY',NULL,NULL,NULL,'2024-02-11',_binary '\0','ACTIVE',NULL,'Doctor Doctor',NULL,817,905),(22,'doctor','2024-02-11 08:37:55','doctor','2024-02-11 08:37:55',0,'VS','SEROLOGY',NULL,NULL,NULL,'2024-02-11',_binary '\0','ACTIVE',NULL,'Doctor Doctor',NULL,817,905),(23,'doctor','2024-02-11 08:38:01','doctor','2024-02-11 08:38:01',0,'vitamine D','SEROLOGY',NULL,NULL,NULL,'2024-02-11',_binary '\0','ACTIVE',NULL,'Doctor Doctor',NULL,817,905),(24,'doctor','2024-02-11 08:38:09','doctor','2024-02-11 08:38:09',0,'ASLO - LATEX','SEROLOGY',NULL,NULL,NULL,'2024-02-11',_binary '\0','ACTIVE',NULL,'Doctor Doctor',NULL,817,905),(25,'doctor','2024-02-12 09:38:08','doctor','2024-02-12 09:38:08',0,'Radiographie de face du bassin','IMAGERY',NULL,NULL,NULL,'2024-02-12',_binary '\0','ACTIVE',NULL,'Doctor Doctor',NULL,825,915),(26,'doctor','2024-02-12 09:38:38','doctor','2024-02-12 09:38:38',0,'Radiographie  du rachis dorso-lombaire face+ profil','IMAGERY',NULL,NULL,NULL,'2024-02-12',_binary '\0','ACTIVE',NULL,'Doctor Doctor',NULL,825,915),(27,'doctor','2024-02-12 09:38:41','doctor','2024-02-12 09:38:41',0,'Radiographie  du rachis dorso-lombaire face+ profil','IMAGERY',NULL,NULL,NULL,'2024-02-12',_binary '\0','ACTIVE',NULL,'Doctor Doctor',NULL,825,915),(28,'doctor','2024-02-12 09:38:46','doctor','2024-02-12 09:38:46',0,'Radiographie  du rachis dorso-lombaire face+ profil','IMAGERY',NULL,NULL,NULL,'2024-02-12',_binary '\0','ACTIVE',NULL,'Doctor Doctor',NULL,825,915),(29,'doctor','2024-02-12 09:38:47','doctor','2024-02-12 09:38:47',0,'Radiographie  du rachis dorso-lombaire face+ profil','IMAGERY',NULL,NULL,NULL,'2024-02-12',_binary '\0','ACTIVE',NULL,'Doctor Doctor',NULL,825,915),(30,'doctor','2024-02-12 09:38:55','doctor','2024-02-12 09:38:55',0,'Radiographie  du rachis dorso-lombaire face+ profil','IMAGERY',NULL,NULL,NULL,'2024-02-12',_binary '\0','ACTIVE',NULL,'Doctor Doctor',NULL,825,915);
/*!40000 ALTER TABLE `complementary_exam` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-03 17:58:45
